package com.globalminds.admission;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.*;import android.graphics.pdf.PdfDocument;import android.net.Uri;import android.provider.Settings;import android.view.*;import android.widget.*;import java.io.*;import java.util.*;import org.json.*;

public class MainActivity extends Activity {
    LinearLayout root, content; ArrayList<JSONObject> programs=new ArrayList<>(); TextView title; StudentDb studentDb;
    int purple=Color.rgb(91,42,134); int bg=Color.rgb(247,247,250);
    public void onCreate(Bundle b){super.onCreate(b); studentDb=new StudentDb(this); migrateLegacyStudents(); loadPrograms(); dashboard();}
    void base(String t){ root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg); title=new TextView(this); title.setText(t);title.setTextSize(22);title.setTextColor(Color.WHITE);title.setTypeface(null,1);title.setPadding(24,24,16,24);title.setBackgroundColor(purple);root.addView(title,new LinearLayout.LayoutParams(-1,-2)); content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(18,18,18,18); ScrollView s=new ScrollView(this);s.addView(content);root.addView(s,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);}
    Button btn(String t){Button b=new Button(this);b.setText(t);b.setAllCaps(false);return b;}
    void dashboard(){base("GlobalMinds Admission Officer"); addText("Offline-first programme guidance and student confirmation",18,Color.DKGRAY); addGap(); Button n=btn("➕ New Student");n.setOnClickListener(v->newStudent());content.addView(n); Button p=btn("📚 Browse 323 LPU Programmes");p.setOnClickListener(v->programs());content.addView(p); Button s=btn("👥 Search / Manage Students");s.setOnClickListener(v->students());content.addView(s); addGap(); addText("Programme library: LPU International Programme Guide 2026",14,Color.GRAY); addText("The guide contains 323 expanded programme entries. Detailed subjects/skills/practical/career descriptions are academic expansions and should not be treated as an official 2026 module list.",13,Color.GRAY);}
    void addText(String x,float z,int c){TextView t=new TextView(this);t.setText(x);t.setTextSize(z);t.setTextColor(c);t.setPadding(4,8,4,8);content.addView(t);}
    void addGap(){Space s=new Space(this);content.addView(s,new LinearLayout.LayoutParams(1,18));}
    void loadPrograms(){try{InputStream in=getAssets().open("programs.json");BufferedReader r=new BufferedReader(new InputStreamReader(in));StringBuilder s=new StringBuilder();String l;while((l=r.readLine())!=null)s.append(l);JSONArray a=new JSONArray(s.toString());for(int i=0;i<a.length();i++)programs.add(a.getJSONObject(i));}catch(Exception e){}}
    void migrateLegacyStudents(){
        android.content.SharedPreferences prefs=getPreferences(0);
        if(prefs.getBoolean("students_migrated_to_database",false))return;
        String old=prefs.getString("students","");
        if(!old.isEmpty()){
            for(String row:old.split("\\n")){
                String[] parts=row.split(" \\| ",4);
                if(parts.length>=4)studentDb.insertLegacy(parts[0],parts[1],parts[2],parts[3]);
            }
        }
        prefs.edit().putBoolean("students_migrated_to_database",true).apply();
    }
    void newStudent(){base("New Student"); EditText name=field("Student full name");EditText phone=field("Phone / WhatsApp (optional)");content.addView(name);content.addView(phone);addText("A unique student reference number will be generated automatically when you save the student.",13,Color.GRAY);Button choose=btn("Select Programme");content.addView(choose);choose.setOnClickListener(v->chooseForStudent(name,phone));}
    EditText field(String h){EditText e=new EditText(this);e.setHint(h);e.setSingleLine();e.setTextSize(16);return e;}
    void chooseForStudent(EditText name,EditText phone){if(name.getText().toString().trim().isEmpty()){toast("Student name is required");return;} programPicker(p->{try{long id=studentDb.insert(name.getText().toString().trim(),phone.getText().toString().trim(),p);String rid=studentDb.getReference(id);documentScreen(name.getText().toString().trim(),phone.getText().toString().trim(),rid,p);}catch(Exception e){toast("Could not save student: "+e.getMessage());}});}
    interface Pick{void go(JSONObject p);}
    void programs(){programPicker(null);}
    void programPicker(Pick pick){base("Programme Library");EditText q=field("Search programmes...");content.addView(q);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);Runnable refresh=()->{list.removeAllViews();String term=q.getText().toString().toLowerCase();int c=0;for(JSONObject p:programs){String n=p.optString("name");if(term.isEmpty()||n.toLowerCase().contains(term)){Button b=btn(n+"\n"+p.optString("type")+" • "+p.optString("duration"));list.addView(b);b.setOnClickListener(v->{if(pick==null)detail(p);else pick.go(p);});if(++c>=80)break;}}};q.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){}public void onTextChanged(CharSequence s,int a,int b,int c){refresh.run();}public void afterTextChanged(android.text.Editable e){}});refresh.run();}
    void detail(JSONObject p){base(p.optString("name")); addText(p.optString("type"),15,purple);addText("Duration: "+p.optString("duration"),15,Color.DKGRAY);addText("Entry: "+p.optString("entryPoint"),15,Color.DKGRAY);String[] fs={"about","study","skills","practical","specialisation","careers","industries","jobs","furtherStudy","demand"};String[] hs={"What it is about","What students study","Skills developed","Practical / technical component","Specialisation / emphasis","Potential career paths","Relevant industries","Possible job roles","Further study options","Study expectations"};for(int i=0;i<fs.length;i++){addText(hs[i],16,purple);addText(p.optString(fs[i]),14,Color.DKGRAY);}Button back=btn("← Back to programmes");content.addView(back);back.setOnClickListener(v->programs());}
    void documentScreen(String name,String phone,String ref,JSONObject p){base("Student Programme Guidance");addText("Student: "+name,16,Color.DKGRAY);addText("Reference: "+ref,14,Color.GRAY);addText("Programme: "+p.optString("name"),16,purple);addText("Review the programme explanation before generating the PDF. The final page records the student's decision.",14,Color.DKGRAY);Button pdf=btn("📄 Generate PDF");content.addView(pdf);pdf.setOnClickListener(v->makePdf(name,phone,ref,p));}
    int pdfPageNo;
    PdfDocument pdfDoc;
    PdfDocument.Page pdfPage;
    Canvas pdfCanvas;
    Paint pdfPaint;
    float pdfY;
    final int pdfPurple=Color.rgb(74,35,110), pdfInk=Color.rgb(42,45,52), pdfMuted=Color.rgb(105,110,120), pdfLight=Color.rgb(245,241,249);
    void startPdfPage(){
        pdfPageNo++;
        pdfPage=pdfDoc.startPage(new PdfDocument.PageInfo.Builder(595,842,pdfPageNo).create());
        pdfCanvas=pdfPage.getCanvas();
        pdfCanvas.drawColor(Color.WHITE);
        Paint p=new Paint(3);p.setColor(pdfPurple);pdfCanvas.drawRect(0,0,595,12,p);
        p.setColor(pdfMuted);p.setTextSize(8);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
        pdfCanvas.drawText("GLOBALMINDS EDUCATION  •  PROGRAMME GUIDANCE",42,815,p);
        pdfCanvas.drawText("Page "+pdfPageNo,510,815,p);
        pdfY=48;
    }
    void finishPdfPage(){if(pdfPage!=null){pdfDoc.finishPage(pdfPage);pdfPage=null;}}
    void ensurePdfSpace(float needed){if(pdfY+needed>785){finishPdfPage();startPdfPage();}}
    void pdfText(String text,float x,float y,float size,int color,boolean bold){
        pdfPaint.setColor(color);pdfPaint.setTextSize(size);pdfPaint.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
        pdfCanvas.drawText(text,x,y,pdfPaint);
    }
    float drawPdfParagraph(String text,float x,float y,float maxWidth,float size,int color,boolean bold,float leading){
        pdfPaint.setColor(color);pdfPaint.setTextSize(size);pdfPaint.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
        String[] words=text.trim().split("\\s+");String line="";
        for(String word:words){
            String candidate=line.isEmpty()?word:line+" "+word;
            if(pdfPaint.measureText(candidate)>maxWidth && !line.isEmpty()){
                ensurePdfSpace(leading);pdfText(line,x,pdfY,size,color,bold);pdfY+=leading;line=word;
            }else line=candidate;
        }
        if(!line.isEmpty()){ensurePdfSpace(leading);pdfText(line,x,pdfY,size,color,bold);pdfY+=leading;}
        return pdfY;
    }
    String expandedSection(String key,JSONObject p){
        String value=p.optString(key,"").trim();
        String name=p.optString("name","this programme");
        if(value.isEmpty())return "";
        if(key.equals("about"))return value+" This programme is intended to build a foundation in the field and help students connect classroom learning with the kinds of tasks and responsibilities they may encounter in further study or employment. The precise curriculum, facilities and learning outcomes should be confirmed with the university for the intake concerned.";
        if(key.equals("study"))return "Students may encounter the following subject areas: "+value+" These areas are typically developed progressively through lectures, guided reading, assignments and assessments. The balance between introductory concepts and advanced topics depends on the university's approved curriculum and the student's year of study.";
        if(key.equals("skills"))return "Through coursework and guided practice, students can work towards developing the following skills: "+value+" These skills usually improve through repeated practice, feedback, teamwork and the completion of assignments or projects; the level achieved will depend on the course requirements and each student's engagement.";
        if(key.equals("practical"))return value+" Practical activities are intended to help students apply theory, build confidence with relevant methods or equipment, and learn to document their work. The exact availability and format of laboratories, placements, workshops or internships must be confirmed with the institution.";
        if(key.equals("careers")||key.equals("jobs"))return "Career pathways related to this field may include: "+value+" Students can build towards these opportunities through their academic work, practical experience and continued professional development.";
        if(key.equals("industries"))return "Knowledge from this field may be relevant to organisations in areas such as: "+value+" The most suitable sector will depend on the student's interests, chosen specialisation, practical experience and local employment conditions.";
        if(key.equals("furtherStudy"))return value+" Eligibility for any next qualification depends on admission criteria, academic results, prerequisite subjects and the rules of the receiving institution.";
        if(key.equals("licensing"))return "";
        if(key.equals("demand"))return value+" Applicants should be prepared for regular attendance, independent study, timely completion of assignments and active participation in assessments and any required practical components.";
        if(key.equals("entryNote"))return "";
        if(key.equals("specialisation"))return value+" Students can discuss available electives, project options and any formal specialisation routes with the university before choosing their academic plan.";
        return value;
    }
    void pdfSection(String heading,String body){
        if(body==null||body.trim().isEmpty())return;
        ensurePdfSpace(42);
        pdfCanvas.drawRect(42,pdfY-13,553,pdfY+7,new Paint(3){{setColor(pdfLight);}});
        pdfText(heading,50,pdfY,11,pdfPurple,true);pdfY+=20;
        drawPdfParagraph(body,50,pdfY,495,9.5f,pdfInk,false,14);
        pdfY+=10;
    }
    void makePdf(String name,String phone,String ref,JSONObject p){
        try{
            pdfDoc=new PdfDocument();pdfPaint=new Paint(3);pdfPageNo=0;startPdfPage();
            // Branded title block
            pdfCanvas.drawRect(0,12,595,155,new Paint(3){{setColor(pdfPurple);}});
            pdfText("GLOBALMINDS",42,48,12,Color.rgb(226,211,240),true);
            pdfText("STUDENT PROGRAMME",42,79,22,Color.WHITE,true);
            pdfText("GUIDANCE REPORT",42,106,22,Color.WHITE,true);
            pdfText("A clear overview to support an informed study decision",42,132,9,Color.WHITE,false);
            pdfY=180;
            pdfText("STUDENT DETAILS",42,pdfY,10,pdfPurple,true);pdfY+=18;
            pdfCanvas.drawRoundRect(42,pdfY-8,553,pdfY+86,8,8,new Paint(3){{setColor(pdfLight);}});
            pdfText("Student",54,pdfY+12,8,pdfMuted,true);
            drawPdfParagraph(name,54,pdfY+29,220,11,pdfInk,true,14);
            pdfText("Reference ID",320,pdfY+12,8,pdfMuted,true);
            drawPdfParagraph(ref,320,pdfY+29,210,10,pdfInk,true,14);
            pdfText("Phone / WhatsApp",54,pdfY+57,8,pdfMuted,true);
            drawPdfParagraph(phone==null||phone.trim().isEmpty()?"Not provided":phone,54,pdfY+74,470,9.5f,pdfInk,false,13);
            pdfY+=110;
            pdfText("PROGRAMME OVERVIEW",42,pdfY,10,pdfPurple,true);pdfY+=20;
            pdfCanvas.drawRoundRect(42,pdfY-10,553,pdfY+58,8,8,new Paint(3){{setColor(Color.rgb(250,249,252));}});
            drawPdfParagraph(p.optString("name"),54,pdfY+8,480,13,pdfPurple,true,17);
            pdfText("Qualification type",54,pdfY+30,8,pdfMuted,true);
            pdfText(p.optString("type","Not specified"),54,pdfY+45,9,pdfInk,false);
            pdfText("Typical duration",320,pdfY+30,8,pdfMuted,true);
            pdfText(p.optString("duration","Confirm with university"),320,pdfY+45,9,pdfInk,false);
            pdfText("Listed entry point",54,pdfY+65,8,pdfMuted,true);
            pdfText(p.optString("entryPoint","Confirm with university"),150,pdfY+65,9,pdfInk,false);
            pdfY+=91;
            String[] fs={"about","study","skills","practical","specialisation","careers","industries","jobs","furtherStudy","demand"};
            String[] hs={"Programme overview","Areas of study","Skills students can develop","Practical learning","Specialisation and focus","Potential career pathways","Relevant employment sectors","Examples of job roles","Further study options","Study expectations"};
            for(int i=0;i<fs.length;i++)pdfSection(hs[i],expandedSection(fs[i],p));
            ensurePdfSpace(145);
            pdfText("STUDENT DECISION",42,pdfY,11,pdfPurple,true);pdfY+=23;
            String[] dec={"[  ] I understand the programme overview and would like to proceed.","[  ] I would like to compare this programme with other options.","[  ] I would like further clarification or career guidance.","Questions / comments:"};
            for(String line:dec){drawPdfParagraph(line,50,pdfY,490,9.5f,pdfInk,false,16);pdfY+=5;}
            pdfY+=10;pdfCanvas.drawLine(50,pdfY,545,pdfY,new Paint(1){{setColor(Color.LTGRAY);setStrokeWidth(1);}});
            pdfY+=24;pdfText("Important note",42,pdfY,9,pdfPurple,true);pdfY+=15;
            drawPdfParagraph("This report is an educational guidance document, not an offer of admission or a guarantee of employment. Programme details, entry requirements, curriculum, practical opportunities and professional recognition should be verified with the university and relevant authorities before a final decision.",42,pdfY,510,8.5f,pdfMuted,false,12);
            finishPdfPage();
            File f=new File(getCacheDir(),"GME_"+safe(ref)+"_Programme_Guidance.pdf");
            FileOutputStream o=new FileOutputStream(f);pdfDoc.writeTo(o);o.close();pdfDoc.close();share(f);
        }catch(Exception e){try{finishPdfPage();if(pdfDoc!=null)pdfDoc.close();}catch(Exception ignored){}toast(e.toString());}
    }
    String safe(String s){return s.replaceAll("[^A-Za-z0-9_-]","_");}
    void share(File f){Uri u=Uri.parse("content://com.globalminds.admission.pdfprovider/"+f.getName());Intent i=new Intent(Intent.ACTION_SEND);i.setType("application/pdf");i.putExtra(Intent.EXTRA_STREAM,u);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Share programme guidance"));}
    void students(){
        base("Search / Manage Students");
        EditText query=field("Search by name, reference number, phone or programme");content.addView(query);
        TextView count=new TextView(this);count.setTextColor(Color.GRAY);count.setPadding(4,8,4,8);content.addView(count);
        LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);content.addView(results);
        Runnable refresh=()->{
            results.removeAllViews();String term=query.getText().toString().trim();ArrayList<JSONObject> found=studentDb.search(term);count.setText(found.size()+" student record"+(found.size()==1?"":"s")+" found");
            if(found.isEmpty()){addResultMessage(results,term.isEmpty()?"No students saved yet.":"No matching students. Try another name or reference number.");return;}
            for(JSONObject st:found){String n=st.optString("name"),r=st.optString("ref"),ph=st.optString("phone"),pr=st.optString("programme");Button b=btn(n+"\n"+r+"  •  "+pr+(ph.isEmpty()?"":"\n"+ph));b.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);results.addView(b);b.setOnClickListener(v->savedStudentDetails(st));}
        };
        query.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){}public void onTextChanged(CharSequence s,int a,int b,int c){refresh.run();}public void afterTextChanged(android.text.Editable e){}});refresh.run();
    }
    void addResultMessage(LinearLayout list,String message){TextView t=new TextView(this);t.setText(message);t.setTextColor(Color.GRAY);t.setPadding(4,16,4,16);list.addView(t);}
    void savedStudentDetails(JSONObject st){
        base("Student Record");String name=st.optString("name"),phone=st.optString("phone"),ref=st.optString("ref");
        addText("Student name",13,Color.GRAY);addText(name,19,Color.DKGRAY);addText("Reference number: "+ref,15,purple);addText("Phone / WhatsApp: "+(phone.isEmpty()?"Not provided":phone),14,Color.DKGRAY);addText("Programme: "+st.optString("programme"),16,purple);
        Button pdf=btn("Generate Programme Guidance PDF");content.addView(pdf);pdf.setOnClickListener(v->{try{JSONObject p=new JSONObject(st.optString("program_json","{}"));if(!p.has("name")){String target=st.optString("programme");for(JSONObject candidate:programs){if(candidate.optString("name").equalsIgnoreCase(target)){p=candidate;break;}}}documentScreen(name,phone,ref,p);}catch(Exception e){toast("Could not open this programme record.");}});
        Button back=btn("← Back to student search");content.addView(back);back.setOnClickListener(v->students());
    }
    class StudentDb extends android.database.sqlite.SQLiteOpenHelper{
        StudentDb(Context c){super(c,"globalminds_students.db",null,1);}
        public void onCreate(android.database.sqlite.SQLiteDatabase db){db.execSQL("CREATE TABLE students (id INTEGER PRIMARY KEY AUTOINCREMENT, ref TEXT UNIQUE, name TEXT NOT NULL, phone TEXT, programme TEXT, program_json TEXT, created_at INTEGER NOT NULL)");}
        public void onUpgrade(android.database.sqlite.SQLiteDatabase db,int oldVersion,int newVersion){}
        long insert(String name,String phone,JSONObject p){android.database.sqlite.SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{android.content.ContentValues v=new android.content.ContentValues();v.put("name",name);v.put("phone",phone);v.put("programme",p.optString("name"));v.put("program_json",p.toString());v.put("created_at",System.currentTimeMillis());long id=db.insertOrThrow("students",null,v);String ref=nextUniqueReference(db,id);android.content.ContentValues u=new android.content.ContentValues();u.put("ref",ref);db.update("students",u,"id=?",new String[]{String.valueOf(id)});db.setTransactionSuccessful();return id;}finally{db.endTransaction();}}
        String nextUniqueReference(android.database.sqlite.SQLiteDatabase db,long id){long max=id-1;android.database.Cursor c=db.rawQuery("SELECT ref FROM students WHERE ref IS NOT NULL",null);try{while(c.moveToNext()){String r=c.getString(0);if(r!=null&&r.matches("GME-[0-9]+")){try{max=Math.max(max,Long.parseLong(r.substring(4)));}catch(Exception ignored){}}}}finally{c.close();}long candidate=Math.max(id,max+1);String ref;boolean used;do{ref="GME-"+String.format(java.util.Locale.US,"%06d",candidate++);android.database.Cursor check=db.query("students",new String[]{"id"},"ref=?",new String[]{ref},null,null,null);try{used=check.moveToFirst();}finally{check.close();}}while(used);return ref;}
        String getReference(long id){android.database.Cursor c=getReadableDatabase().query("students",new String[]{"ref"},"id=?",new String[]{String.valueOf(id)},null,null,null);try{return c.moveToFirst()?c.getString(0):"";}finally{c.close();}}
        void insertLegacy(String name,String phone,String oldRef,String programme){android.database.sqlite.SQLiteDatabase db=getWritableDatabase();android.database.Cursor c=db.query("students",new String[]{"id"},"ref=?",new String[]{oldRef},null,null,null);boolean exists=c.moveToFirst();c.close();if(exists)return;android.content.ContentValues v=new android.content.ContentValues();v.put("ref",oldRef);v.put("name",name);v.put("phone",phone);v.put("programme",programme);v.put("program_json","{}");v.put("created_at",System.currentTimeMillis());try{db.insertOrThrow("students",null,v);}catch(Exception ignored){}}
        ArrayList<JSONObject> search(String term){ArrayList<JSONObject> out=new ArrayList<>();android.database.sqlite.SQLiteDatabase db=getReadableDatabase();android.database.Cursor c;if(term==null||term.trim().isEmpty())c=db.query("students",new String[]{"id","ref","name","phone","programme","program_json","created_at"},null,null,null,null,"id DESC");else{String like="%"+term.trim().replace("%","\\%").replace("_","\\_")+"%";c=db.rawQuery("SELECT id,ref,name,phone,programme,program_json,created_at FROM students WHERE name LIKE ? OR ref LIKE ? OR phone LIKE ? OR programme LIKE ? ORDER BY id DESC",new String[]{like,like,like,like});}try{while(c.moveToNext()){JSONObject o=new JSONObject();o.put("id",c.getLong(0));o.put("ref",c.getString(1));o.put("name",c.getString(2));o.put("phone",c.getString(3));o.put("programme",c.getString(4));o.put("program_json",c.getString(5));o.put("created_at",c.getLong(6));out.add(o);}}catch(Exception ignored){}finally{c.close();}return out;}
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override public void onBackPressed(){dashboard();}
}
