# Global Minds Education — Student Management & International Education Operations (Offline Android)

This is an upgrade of the Global Minds Admission Officer Android project. It embeds the programme library in `app/src/main/assets/programs.json` and stores student, journey and finance records locally in SQLite on the Android device.

## Included in version 2.1
- Offline home dashboard for admissions operations.
- Register students either with a selected programme or as an enquiry before a programme is selected.
- Automatically generated Student IDs (`STU_000001`, etc.) and separate Acceptance Reference IDs (`GME_000001`, etc.).
- Duplicate warning when a matching name/contact record is found.
- Search/manage student records by name, IDs, phone, programme, city or province; creation dates, current journey stage and programme assignment.
- Student city/town and province/region fields, editable on existing records and included in programme guidance reports.
- Offline Student Area Intelligence grouped by city and province, showing student counts, confirmed-admission-and-later counts, and area admission rates.
- Student journey stages and timestamped milestone history.
- Automatically records `Programme guidance issued` when a Programme Guidance PDF is successfully generated.
- Programme Guidance Report and Student Undertaking with date and Student-ID-based filename.
- Document Centre for application checklist, travel-readiness checklist, student arrival/follow-up report, invoice, payment receipt and finance summary.
- Offline finance tracking for expected amounts, due dates, payments, paid totals and pending balances.
- CEO dashboard with student journey and finance snapshots.
- Database migration from the previous local schema to the new schema, retaining existing local student records when the Android app is installed as a compatible signed update.

## Important offline behaviour
- Records are saved only on this device. There is no cloud synchronisation or multi-device sharing in this version.
- Finance totals include recorded expected amounts and recorded payments; they are not connected to a bank or payment provider.
- A generated payment receipt is an internal record of a payment entry and must be checked against the actual transaction before being issued as official proof of payment.
- Dates, deadlines, application milestones and university decisions should be entered or verified by staff. Only generating a Programme Guidance Report automatically updates a journey milestone in this version.
- Student data is sensitive. Protect the phone with a screen lock and make secure backups before reinstalling or changing devices.

## Build with GitHub Actions
The project includes `.github/workflows/build-apk.yml`. Upload the project source to a GitHub repository, open **Actions**, run **Build Android APK**, then download the `GlobalMinds-APK` artifact after the run succeeds.

The source guide contains expanded programme descriptions; those descriptions should not be treated as a verified official module list or a guarantee of admission, employment or professional registration. Confirm current requirements with the university before advising a student.


## Version 2.2 interface update

- Removed Acceptance Reference ID from the visible app screens and generated documents. New student records now use the Student ID only. The legacy database column remains unused to keep upgrades compatible with existing installations.
- Refreshed the user interface with a branded gradient header, softer colours, rounded search fields, clearer spacing, and dashboard feature cards grouped by task.
- Increased Android versionCode to 4 and versionName to 2.2 for upgrade delivery.

Build using the included GitHub Actions workflow or run `gradle :app:assembleDebug --no-daemon` in an Android/Gradle environment. A full Android build has not been verified in this environment because Gradle is not installed.
