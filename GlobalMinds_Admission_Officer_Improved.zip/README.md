# Global Minds Education — Student Management & International Education Operations (Offline Android)

This is an upgrade of the Global Minds Admission Officer Android project. It embeds the programme library in `app/src/main/assets/programs.json` and stores student, journey and finance records locally in SQLite on the Android device.

## Included in version 2.9
- Offline home dashboard for admissions operations.
- Register students either with a selected programme or as an enquiry before a programme is selected.
- Automatically generated Student IDs (`STU_000001`, etc.). Acceptance Reference IDs are not displayed or generated in the current interface; the legacy database column is retained only for upgrade compatibility.
- Duplicate warning when a matching name/contact record is found.
- Search/manage student records by name, IDs, phone, programme, city or province; creation dates, current journey stage and programme assignment.
- Student city/town and province/region fields, editable on existing records and included in programme guidance reports.
- Offline Student Area Intelligence grouped by city and province, showing student counts, confirmed-admission-and-later counts, and area admission rates.
- Student journey stages and timestamped milestone history.
- Automatically records `Programme guidance issued` when a Programme Guidance PDF is successfully generated.
- Programme Guidance Report and Student Undertaking with date and Student-ID-based filename.
- Document Centre for application checklist, travel-readiness checklist, student arrival/follow-up report, invoice, payment receipt and finance summary.
- Offline finance tracking for expected amounts, due dates, payments, paid totals and pending balances.
- CEO dashboard with charts for student journey distribution, six-month registration trends, programme popularity, admissions by programme and financial snapshots.
- Visual analytics in Student Area Intelligence: top provinces/regions and city-province pairs, student counts, admissions counts, geographic distribution, and location-data completeness.
- Visual analytics in Student Journey Tracker and Financial Dashboard, including stage distribution, payment-vs-balance comparisons, and six-month recorded payment trends.
- Charts use local SQLite records; location and admission analyses distinguish missing locations and use the currently recorded journey stage. Financial figures are based only on recorded expected amounts and payments.
- Database migration from the previous local schema to the new schema, retaining existing local student records when the Android app is installed as a compatible signed update.

## Important offline behaviour
- Records are saved only on this device. There is no cloud synchronisation or multi-device sharing in this version.
- Finance totals include recorded expected amounts and recorded payments; they are not connected to a bank or payment provider.
- A generated payment receipt is an internal record of a payment entry and must be checked against the actual transaction before being issued as official proof of payment.
- Dates, deadlines, application milestones and university decisions should be entered or verified by staff. Only generating a Programme Guidance Report automatically updates a journey milestone in this version.
- Student data is sensitive. Protect the phone with a screen lock and make secure backups before reinstalling or changing devices.

## Build with GitHub Actions
The project includes `.github/workflows/build-apk.yml`. Upload the project source to a GitHub repository, open **Actions**, run **Build Android APK**, then download the `GlobalMinds-APK` artifact after the run succeeds.

The source guide contains expanded programme descriptions; those descriptions should not be treated as a verified official module list or a guarantee of admission, employment or professional registration. Confirm current requirements with the university before advising a student.


## Version 2.2 interface update

- Removed Acceptance Reference ID from the visible app screens and generated documents. New student records now use the Student ID only. The legacy database column remains unused to keep upgrades compatible with existing installations.
- Refreshed the user interface with a branded gradient header, softer colours, rounded search fields, clearer spacing, and dashboard feature cards grouped by task.
- Increased Android versionCode to 4 and versionName to 2.2 for upgrade delivery.

Build using the included GitHub Actions workflow or run `gradle :app:assembleDebug --no-daemon` in an Android/Gradle environment. A full Android build has not been verified in this environment because Gradle is not installed.


## Version 2.3 — App access security

- First launch requires creating an app password of at least 6 characters. Passwords are not stored in plain text: the app stores a random salt and PBKDF2-derived password hash in private app preferences.
- On later launches and after returning from the background, users must unlock the app with the password or an enrolled Android biometric (fingerprint/face) where supported. Biometric templates are handled by Android and are not stored by this app.
- Includes a Change App Password screen.
- Android automatic backup is disabled to reduce the risk of student records and authentication data being copied into device backup. Keep the device protected and arrange a separate secure export/backup process before changing or replacing phones.
- If the app password is forgotten, this version does not provide a password-reset flow that preserves local records. Do not clear app data or uninstall the app; contact the app administrator before taking any recovery action.


## Version 2.4 — CEO dashboard charts

- Added an offline student-journey pie chart, six-month admissions trend line graph, top-programmes bar chart, and expected-fees/payments/balance comparison chart to the CEO Dashboard.
- Charts are drawn with native Android graphics and use locally stored SQLite records; no internet connection or chart service is required.
- Charts refresh when the CEO Dashboard is opened again and display an empty-data message when there are no relevant records. Financial chart amounts are rounded to whole USD for visual comparison; the text totals remain the detailed figures.
- Increased Android versionCode to 6 and versionName to 2.4.
- A full Android build still needs to be verified by the included GitHub Actions workflow.


## Version 2.9 — navigation and login refinements
- Android Back now returns to the previously displayed screen; Back on the main workspace exits the activity.
- Biometric authentication launches automatically when the app opens if a supported fingerprint or face biometric is enrolled. The password field remains available as a fallback.
- Removed the password-privacy/local-storage statement from the login screen.
- Increased Android versionCode to 8 and versionName to 2.9.


## Event management (2.9)
- Upcoming event calendar with venue, start/end date and time, agenda, countdowns and local reminders.
- Guest list with name, contact number, national ID/passport field, gender, notes and RSVP/attendance status.
- Event portfolio and guest participation charts for management review.
- Event information and guest records are stored locally on this device.


## Event documents (v2.9)
- Events support event type, audience and delivery format (physical, online or hybrid).
- Audience options include enquiring students, admitted students, students already in India, former students, business guests, staff and everyone.
- Existing student records can be added to event guest lists; the picker narrows records for enquiry/admitted/in-India audiences and prevents duplicate linking by student ID.
- Generate a named PDF gate pass for physical events, an online meeting invitation for online events, or choose either for hybrid events.
- Generate a ZIP bundle containing an individual PDF for each listed participant for easier distribution. Documents are generated locally and can be shared through installed apps; they are not automatically emailed or sent to participants.


## Version 2.9 additions
- Student profile photographs selected from device storage and linked to the local student record.
- Student referral source tracking and reusable referee profiles for students, staff, alumni and other contributors.
- Monthly and all-time referral leaderboards, admission outcome counts, and referee competency certificate generation.
- Certificate generator for enrolment, event participation, achievement and referee recognition.
- Activity feed for recent student registrations and monthly referral spotlight.
- CEO-friendly referral charts and recognition entry points.

These features use records stored locally on this device. Monthly referral ranking is based on the date the referral source is recorded and the recorded referral source; it does not infer that a referral caused an admission. Activity feed refreshes from local records when opened; it is not a cloud/live multi-device feed.
