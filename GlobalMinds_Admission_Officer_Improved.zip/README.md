# Global Minds Education — Student Management & International Education Operations (Offline Android)

This is an upgrade of the Global Minds Admission Officer Android project. It embeds the programme library in `app/src/main/assets/programs.json` and stores student, journey and finance records locally in SQLite on the Android device.

## Included in version 2.23
- Offline home dashboard for admissions operations.
- Centralized live-refresh handling: student lists, dashboards, document centre, finance views and key student detail screens reload from SQLite after returning to them or when the app resumes, so users no longer need to close and reopen the app to see recent changes.
- Register students either with a selected programme or as an enquiry before a programme is selected.
- Automatically generated Student IDs (`STU_000001`, etc.). Acceptance Reference IDs are not displayed or generated in the current interface; the legacy database column is retained only for upgrade compatibility.
- Duplicate warning when a matching name/contact record is found.
- Search/manage student records by name, IDs, phone, programme, city or province; creation dates, current journey stage and programme assignment.
- Student city/town and province/region fields, editable on existing records and included in programme guidance reports.
- Offline Student Area Intelligence grouped by city and province, showing student counts, confirmed-admission-and-later counts, and area admission rates.
- Student journey stages with automatic completion of all earlier milestones when a later milestone is marked complete; visual progress indicator and clearer journey worklist.\n- Student nationality captured during registration, editable on profiles, searchable, and included in CEO / journey nationality charts.\n- Required referee selection during student registration using a dropdown of saved referee profiles; new referee profiles can be created and selected without leaving registration.\n- Internal-only “Referred by Kelvin” stamp shown in student profiles, lists, journey screens and internal admin workspaces; never printed on student-facing PDFs.\n- Office document branding settings for reusable signatory name/title, signature image and office stamp image.\n- Redesigned checklist, arrival follow-up, invoice, receipt and finance summary PDFs with structured tables and office authorisation areas.\n- Student journey stages and timestamped milestone history.
- Automatically records `Programme guidance issued` when a Programme Guidance PDF is successfully generated.
- Programme Guidance Report and Student Undertaking with date and Student-ID-based filename.
- Document Centre for application checklist, travel-readiness checklist, student arrival/follow-up report, invoice, payment receipt and finance summary.
- Offline finance tracking for expected amounts, due dates, payments, paid totals and pending balances.
- CEO dashboard with charts for student journey distribution, six-month registration trends, programme popularity, admissions by programme and financial snapshots.
- Visual analytics in Student Area Intelligence: top provinces/regions and city-province pairs, student counts, admissions counts, geographic distribution, and location-data completeness.
- Visual analytics in Student Journey Tracker and Financial Dashboard, including stage distribution, payment-vs-balance comparisons, and six-month recorded payment trends.
- Charts use local SQLite records; location and admission analyses distinguish missing locations and use the currently recorded journey stage. Financial figures are based only on recorded expected amounts and payments.
- Database migration from the previous local schema to the new schema, retaining existing local student records when the Android app is installed as a compatible signed update.

## Important offline behaviour
- Records are saved only on this device. There is no cloud synchronisation or multi-device sharing in this version.
- Finance totals include recorded expected amounts and recorded payments; they are not connected to a bank or payment provider.
- A generated payment receipt is an internal record of a payment entry and must be checked against the actual transaction before being issued as official proof of payment.
- Dates, deadlines, application milestones and university decisions should be entered or verified by staff. Only generating a Programme Guidance Report automatically updates a journey milestone in this version.
- Student data is sensitive. Protect the phone with a screen lock and make secure backups before reinstalling or changing devices.

## Build with GitHub Actions
The project includes `.github/workflows/build-apk.yml`. Upload the project source to a GitHub repository, open **Actions**, run **Build Android APK**, then download the `GlobalMinds-APK` artifact after the run succeeds.

The source guide contains expanded programme descriptions; those descriptions should not be treated as a verified official module list or a guarantee of admission, employment or professional registration. Confirm current requirements with the university before advising a student.


## Version 2.2 interface update

- Removed Acceptance Reference ID from the visible app screens and generated documents. New student records now use the Student ID only. The legacy database column remains unused to keep upgrades compatible with existing installations.
- Refreshed the user interface with a branded gradient header, softer colours, rounded search fields, clearer spacing, and dashboard feature cards grouped by task.
- Increased Android versionCode to 4 and versionName to 2.2 for upgrade delivery.

Build using the included GitHub Actions workflow or run `gradle :app:assembleDebug --no-daemon` in an Android/Gradle environment. A full Android build has not been verified in this environment because Gradle is not installed.


## Version 2.3 — App access security

- First launch requires creating an app password of at least 6 characters. Passwords are not stored in plain text: the app stores a random salt and PBKDF2-derived password hash in private app preferences.
- On later launches and after returning from the background, users must unlock the app with the password or an enrolled Android biometric (fingerprint/face) where supported. Biometric templates are handled by Android and are not stored by this app.
- Includes a Change App Password screen.
- Android automatic backup is disabled to reduce the risk of student records and authentication data being copied into device backup. Keep the device protected and arrange a separate secure export/backup process before changing or replacing phones.
- If the app password is forgotten, this version does not provide a password-reset flow that preserves local records. Do not clear app data or uninstall the app; contact the app administrator before taking any recovery action.


## Version 2.4 — CEO dashboard charts

- Added an offline student-journey pie chart, six-month admissions trend line graph, top-programmes bar chart, and expected-fees/payments/balance comparison chart to the CEO Dashboard.
- Charts are drawn with native Android graphics and use locally stored SQLite records; no internet connection or chart service is required.
- Charts refresh when the CEO Dashboard is opened again and display an empty-data message when there are no relevant records. Financial chart amounts are rounded to whole USD for visual comparison; the text totals remain the detailed figures.
- Increased Android versionCode to 6 and versionName to 2.4.
- A full Android build still needs to be verified by the included GitHub Actions workflow.


## Version 2.10 — navigation and login refinements
- Android Back now returns to the previously displayed screen; Back on the main workspace exits the activity.
- Biometric authentication launches automatically when the app opens if a supported fingerprint or face biometric is enrolled. The password field remains available as a fallback.
- Removed the password-privacy/local-storage statement from the login screen.
- Increased Android versionCode to 8 and versionName to 2.9.


## Event management (2.9)
- Upcoming event calendar with venue, start/end date and time, agenda, countdowns and local reminders.
- Guest list with name, contact number, national ID/passport field, gender, notes and RSVP/attendance status.
- Event portfolio and guest participation charts for management review.
- Event information and guest records are stored locally on this device.


## Event documents (v2.10)
- Events support event type, audience and delivery format (physical, online or hybrid).
- Audience options include enquiring students, admitted students, students already in India, former students, business guests, staff and everyone.
- Existing student records can be added to event guest lists; the picker narrows records for enquiry/admitted/in-India audiences and prevents duplicate linking by student ID.
- Generate a named PDF gate pass for physical events, an online meeting invitation for online events, or choose either for hybrid events.
- Generate a ZIP bundle containing an individual PDF for each listed participant for easier distribution. Documents are generated locally and can be shared through installed apps; they are not automatically emailed or sent to participants.


## Version 2.10 additions
- Student profile photographs selected from device storage and linked to the local student record.
- Student referral source tracking and reusable referee profiles for students, staff, alumni and other contributors.
- Monthly and all-time referral leaderboards, admission outcome counts, and referee competency certificate generation.
- Certificate generator for enrolment, event participation, achievement and referee recognition.
- Activity feed for recent student registrations and monthly referral spotlight.
- CEO-friendly referral charts and recognition entry points.

These features use records stored locally on this device. Monthly referral ranking is based on the date the referral source is recorded and the recorded referral source; it does not infer that a referral caused an admission. Activity feed refreshes from local records when opened; it is not a cloud/live multi-device feed.


## Version 2.10 — Preserve active screen on return
When the app is backgrounded, the current screen and navigation history are retained. After re-authentication, the app restores the screen that was open rather than returning to the dashboard, preserving in-progress form entries while the Activity remains alive.


## Version 2.11 — Home screen redesign

- Redesigned the workspace home screen with a purple gradient welcome hero, impact metrics, monthly referee spotlight, and friendly two-column action tiles.
- Grouped actions into Student Operations, Management & Intelligence, and Community & Recognition.
- Preserved access to all existing app modules and kept the offline-storage notice visible.


## Version 2.15 — reusable document signature and company stamp
- Office Document Branding settings now clearly show whether the signature and company stamp are saved, and provide image previews.
- Upload each image once; the saved image URI is reused by supported generated student-facing PDFs.
- Replace the signature or stamp at any time; replacements apply to documents generated afterward.
- Remove controls are available if the saved image should no longer be used.
- Signatory name and designation remain editable and reusable.
- Image selection uses Android document picker and persists read access where supported.



## Version 2.17 — Student Visa Undertaking Form
- Added **Student Visa Undertaking Form** to each student's Document Centre and Student Record.
- The form pre-fills the student's name, programme, phone and location where available.
- Staff can enter/edit passport number, passport issue place/date, Indian university/institution, Indian state, study start/end years, sponsor details, sponsor address and sponsor phone.
- The form preserves the wording and declaration structure of the supplied Global Minds Education visa undertaking template, addressed to the Visa Officer, Embassy of India, Harare, Zimbabwe.
- Completed forms are generated as student-specific PDFs and shared through Android's installed sharing apps.
- Visa undertaking details are saved locally per student so the form can be reopened and regenerated without changing the student's core record.
- Increased Android versionCode to 15 and versionName to 2.17.

## Version 2.16 — Admission, student profile and document improvements
- Recording a student payment automatically moves a student who is earlier in the journey to **Admission confirmed**, while preserving later journey stages.
- Student-record screens include a fixed student identity strip so the open student's name, ID, stage and profile image remain visible while scrolling.
- Registration uses an African-country dropdown. Selecting Zimbabwe switches Province to a dropdown containing Zimbabwe's 10 provinces; other countries use a manually entered province and city.
- Added an optional gender dropdown for student registration and stored the field through a compatible SQLite migration.
- Student photographs display as circular profile images and the student record begins with a structured photo-and-details profile row.
- Removed the receipt disclaimer sentence requested by the organisation.
- Event invitation / gate-pass PDFs include the student's saved photo when the participant is linked to a student record.
- Increased Android versionCode to 14 and versionName to 2.16.



### Version 2.23 — Previous photo setup restored; duplicate protection retained
- Registration and enquiry creation now checks active, archived, withdrawn and other existing student records before creating a new record.
- Phone numbers are normalized for duplicate matching, including common Zimbabwe local `07...` versus `+263...` formatting.
- Exact name + phone matches are treated as the same student and cannot create a second record; the existing student can be opened instead.
- Same-name or same-phone matches are shown as possible duplicates with the matching record's Student ID, contact number, status and reason.
- Existing records can be reviewed before deciding that a new person is genuinely different.
- Existing student data is preserved; no database reset is required.

### Version 2.19
- Fixed document signature and company stamp rendering so uploaded images keep their original aspect ratio and are fitted inside the signing area without distortion.


### Version 2.19 additions
- Student and referee certificates include circular recipient portraits when available.
- Uploaded office signature and company stamp are now included on certificates as well as supported student documents, with aspect-ratio-preserving rendering so they are never stretched or squashed.


## Version 2.23
Updated the Android launcher/app icon to the supplied Global Minds Education signature/stamp artwork. The source proportions are preserved and the adaptive icon keeps the artwork inside the launcher safe area.


Version 2.26: fixed Programme Guidance PDF positioning so Student Details and Programme Overview fields use fixed coordinates and no longer overlap.


Version 2.28: increased the visible size of uploaded signature and company stamp across certificates and supported documents, while preserving aspect ratio and cropping transparent margins so the actual artwork remains clearly visible.


## Version 2.29 invoice and receipt logo update
- Removed the purple circular frame from invoice and payment receipt headers.
- Invoice and payment receipt headers now use the supplied GlobalMinds fingerprint logo directly, preserving its proportions.
- The existing company name text remains beside the logo, matching the supplied invoice/receipt layout.
- Company address and contact details remain: 6012 New Cearney Park Harare, Zimbabwe and +263 78 277 7659.


## Update 2.30 — payment deadline calendar and Accepted milestone

- Student Finance > Set Expected Amount and Deadline now provides a calendar date picker.
- Saving requires an actual selected date; the date is stored consistently as `yyyy-MM-dd`.
- The existing Payment Deadline Management and Deadline Analysis data pipeline reads this same `students.due_date` field, so calendar-selected dates drive the overdue / today / tomorrow / within-7-days / on-track groups and dashboard alerts.
- Deadline eligibility now begins at the new `Accepted` journey milestone, rather than waiting until `Admission confirmed`.
- Added `Accepted` between `Application submitted` and `University decision received` in the journey milestone sequence and journey analytics.
- Existing database schema and student records are retained; no database migration is required for these changes.

Build verification: source changes were made, but an Android Gradle build could not be run in this environment because Gradle is not installed. Run the repository's existing GitHub Actions workflow to produce and verify the APK.


## Update 2.31 — app-wide scroll-position preservation

- Added centralized scroll-position capture and restoration around automatic screen refreshes.
- When a screen is rebuilt to show current student, finance, referral, document, or dashboard data, its main scroll view is returned to its previous vertical offset instead of jumping to the top.
- Back navigation restores the previous screen and its retained view state; the automatic refresh that follows now preserves that screen's previous scroll offset as well.
- The change is implemented in the shared `MainActivity` screen-refresh path so it applies across screens using the app's standard main `ScrollView`.
- Bumped Android version metadata to `2.31` (version code `27`).

Build status: source updated; an Android/Gradle build has not been run in this environment. Validate with the repository's GitHub Actions workflow before installing the APK.


## Update 2.33 — Payment deadline alert repair

- Added dedicated local Android notifications for outstanding accepted-student accounts: one 7 days before the saved deadline and one 1 day before it.
- Alerts are scheduled from the saved student finance record, refreshed when deadlines, journey stages, or payment balances change, and cancelled when no longer eligible.
- Existing deadline analysis, due-date grouping, follow-up records, and scroll/navigation code are retained.
- Corrected deadline day calculations to compare calendar dates without daylight-saving-time millisecond drift.
- Requests Android 13+ notification permission and registers a dedicated payment-deadline notification receiver; event reminders remain separate.
- Increased Android versionCode to 28 and versionName to 2.33.

Build status: source-level changes are complete. A Gradle APK build and on-device notification test still need to be run through GitHub Actions / an Android device before release. Android may delay inexact alarms under battery optimisation; the app uses `setAndAllowWhileIdle` and does not request exact-alarm special access.


## Version 2.34 — Offline QR acknowledgement on registration confirmations
- Registration Confirmation PDFs now include a QR code containing plain-text document details for Google Lens / QR scanner reading; no website, server, internet connection, or live lookup is required.
- The QR text includes institution, document type, unique document serial, student name and ID, application reference, registration status/date, and GlobalMinds contact details.
- Each generated confirmation receives a newly generated serial number.
- Removed +91 76819 66443 from the Registration Confirmation PDF; +91 90415 74079 remains.
- QR is an informational acknowledgement payload and does not perform independent online authenticity verification.
- Increased Android versionCode to 30 and versionName to 2.34.

Build status: source changes completed; Android compilation and on-device Google Lens scanning still require verification.


## Registration Confirmation PDF — generate and share only
- Application Registration Confirmations are generated into the app's temporary cache and immediately opened in Android's share chooser. They are not copied into the persistent Documents folder and are no longer listed as saved documents in Document Centre.
- Any legacy `GME_Registration_Confirmation_*.pdf` files in the app's Documents folder are cleaned up when a new confirmation is generated. Other document-generation and sharing workflows are unchanged.
- Temporary cache files are managed by Android and may be cleared by the operating system. Students should save the PDF from the receiving/sharing app if they need a permanent copy.


## Registration Confirmation filename
- Shared confirmation PDFs use the student's application reference followed by the generation date in numeric YYYYMMDD format, for example `GME-APP-STU000001_20261107.pdf`.
- The PDF remains in temporary app cache for sharing and is not added to the app's Documents section.

## v2.34 Journey Tracker grouped worklists

The Student Journey Tracker worklist now groups active student records by their current/latest completed journey milestone:

- **Enquiry & Application:** Enquiry received through Application submitted.
- **Accepted & Admission:** Accepted, University decision received, and Admission confirmed.
- **Visa Processing:** Visa Applied and Visa Approved.
- **Travel Preparation:** Flight Ticket Booked and Accommodation Booked.
- **Arrived & University Reporting:** Arrived Airport and University Reported.

The group is derived from each student's existing `stage` value; no duplicate student records or new database tables are created. Updating a student's Journey Tracker milestone automatically moves the record to the matching group when the worklist refreshes. Search filters the records across all groups.


## Version 2.35 — Exact journey milestone filters, action icons and finance access lock
- Student Management and Student Journey Tracker now use one horizontal pill filter per exact journey milestone: Enquiry received, Counselling completed, Programme guidance issued, Student undertaking signed, Application submitted, Accepted, University decision received, Admission confirmed, Visa Applied, Visa Approved, Flight Ticket Booked, Accommodation Booked, Arrived Airport, and University Reported. Each tab shows its own live student count; selecting a tab displays only students currently at that exact milestone. All shows the full matching set.
- Journey filter tabs include consistent, professional visual emoji markers and remain horizontally scrollable on narrow screens.
- Added contextual emoji markers to action buttons throughout the app (including document generation, student actions, finance, travel, visa, settings and reporting) while preserving labels and existing click behaviour.
- Financial Dashboard and individual Student Finance screens now require a fresh identity check before opening: Android fingerprint/face biometric when available, or the existing app password as fallback. This reuses the existing salted PBKDF2 app-password verifier; no new password is stored and biometric templates remain managed by Android.
- Increased Android versionCode to 31 and versionName to 2.35.

Build status: source changes are complete and ZIP integrity is checked. Android Gradle compilation and device-level biometric/password testing remain pending; run the included GitHub Actions workflow before installing.


## Version 2.36 – Dark Mode
Adds a saved Light/Dark appearance preference accessible from the dashboard. Dark mode uses dark surfaces, readable light text, and preserves the branded purple header. The selected mode persists across app launches.


## Version 2.42 — LPU Application Form workflow

The Document Centre now includes an LPU application workflow for each student. It uses the supplied `app/src/main/assets/lpu_master_template.docx` master template, allows staff to review/edit applicant details, place the applicant photo in the template photo area, upload supporting documents, and prepare an email with the generated form and uploaded files attached. Required-document validation follows the Diploma and Degree rules recorded in `UPDATE_NOTES_v2.42.txt`. Generated application files are stored in app-private per-student folders.


## v2.43 – LPU Application Form PDF
The LPU form is generated and emailed as a PDF. The bundled DOCX is used internally as the source artwork template only. See UPDATE_NOTES_v2.43.txt.


## v2.49 update
See UPDATE_NOTES_v2.49.txt for LPU field positioning, document requirements, input controls, application numbering, dashboard metric and expanded chart navigation.
