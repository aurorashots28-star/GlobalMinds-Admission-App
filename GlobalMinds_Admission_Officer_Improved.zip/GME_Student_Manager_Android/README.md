# GME Student Manager — Android

Offline Android version of the Global Minds Education desktop student manager.

Included:
- Dashboard with live offline counts
- Student add/edit/delete/search
- Automatic GME-###### reference IDs for new students
- Letter date defaults to today for new records
- Scholarship %, status and university tracking
- Acceptance-letter DOCX generation from the supplied GME template
- 14-day and 21-day deadline calculations
- Android share/open workflow for generated Word letters
- GitHub Actions build; Android Studio is not required

## Build without Android Studio
1. Create a GitHub repository.
2. Upload the contents of this folder.
3. Open **Actions** → **Build GME Android APK** → **Run workflow**.
4. When it finishes, open the workflow run and download **GME-Student-Manager-debug-apk**.
5. Extract the APK and install it on the Android phone.
