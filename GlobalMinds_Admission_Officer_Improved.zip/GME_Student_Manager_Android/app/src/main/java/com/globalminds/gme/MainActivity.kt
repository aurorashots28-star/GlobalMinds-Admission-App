package com.globalminds.gme

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

private const val PURPLE = 0xFF6A1B9A
private val statuses = listOf("Application", "Accepted", "Payment", "Visa", "Enrolled", "On Hold")

data class Student(
    val id: Long = 0,
    var referenceId: String = "",
    var studentName: String = "",
    var guardianName: String = "",
    var passportNumber: String = "",
    var nationality: String = "",
    var dateOfBirth: String = "",
    var programApplied: String = "",
    var yearIntake: String = "",
    var levelApplied: String = "",
    var university: String = "",
    var programDuration: String = "",
    var programFee: String = "",
    var scholarshipPercent: String = "",
    var status: String = "Application",
    var letterDate: String = ""
)

class StudentDb(ctx: Context) {
    private val helper = object : android.database.sqlite.SQLiteOpenHelper(ctx, "gme_students.db", null, 2) {
        override fun onCreate(db: android.database.sqlite.SQLiteDatabase) {
            db.execSQL("CREATE TABLE students (id INTEGER PRIMARY KEY AUTOINCREMENT, reference_id TEXT UNIQUE, student_name TEXT NOT NULL, guardian_name TEXT, passport_number TEXT, nationality TEXT, date_of_birth TEXT, program_applied TEXT, year_intake TEXT, level_applied TEXT, university TEXT, program_duration TEXT, program_fee TEXT, scholarship_percent TEXT, status TEXT, letter_date TEXT, created_at TEXT, updated_at TEXT)")
        }
        override fun onUpgrade(db: android.database.sqlite.SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            if (oldVersion < 2) { db.execSQL("ALTER TABLE students ADD COLUMN scholarship_percent TEXT DEFAULT ''"); db.execSQL("ALTER TABLE students ADD COLUMN status TEXT DEFAULT 'Application'") }
        }
    }
    private fun fromCursor(c: android.database.Cursor) = Student(
        c.getLong(c.getColumnIndexOrThrow("id")), c.getString(c.getColumnIndexOrThrow("reference_id")) ?: "", c.getString(c.getColumnIndexOrThrow("student_name")) ?: "", c.getString(c.getColumnIndexOrThrow("guardian_name")) ?: "", c.getString(c.getColumnIndexOrThrow("passport_number")) ?: "", c.getString(c.getColumnIndexOrThrow("nationality")) ?: "", c.getString(c.getColumnIndexOrThrow("date_of_birth")) ?: "", c.getString(c.getColumnIndexOrThrow("program_applied")) ?: "", c.getString(c.getColumnIndexOrThrow("year_intake")) ?: "", c.getString(c.getColumnIndexOrThrow("level_applied")) ?: "", c.getString(c.getColumnIndexOrThrow("university")) ?: "", c.getString(c.getColumnIndexOrThrow("program_duration")) ?: "", c.getString(c.getColumnIndexOrThrow("program_fee")) ?: "", c.getString(c.getColumnIndexOrThrow("scholarship_percent")) ?: "", c.getString(c.getColumnIndexOrThrow("status")) ?: "Application", c.getString(c.getColumnIndexOrThrow("letter_date")) ?: ""
    )
    fun nextRef(): String { val c=helper.readableDatabase.rawQuery("SELECT reference_id FROM students WHERE reference_id LIKE 'GME-%'",null); var max=0; while(c.moveToNext()){ val m=Regex("GME-(\\d+)",RegexOption.IGNORE_CASE).matchEntire(c.getString(0)?:""); if(m!=null) max=maxOf(max,m.groupValues[1].toInt()) }; c.close(); return "GME-${String.format("%06d",max+1)}" }
    fun all(search:String=""): List<Student> { val db=helper.readableDatabase; val q=if(search.isBlank()) "SELECT * FROM students ORDER BY student_name COLLATE NOCASE" else "SELECT * FROM students WHERE student_name LIKE ? OR reference_id LIKE ? OR passport_number LIKE ? OR university LIKE ? ORDER BY student_name COLLATE NOCASE"; val args=if(search.isBlank()) null else arrayOf("%$search%","%$search%","%$search%","%$search%"); val c=db.rawQuery(q,args); val out=mutableListOf<Student>(); while(c.moveToNext()) out.add(fromCursor(c)); c.close(); return out }
    fun save(s:Student): Long { val db=helper.writableDatabase; val v=android.content.ContentValues().apply{ put("reference_id",s.referenceId); put("student_name",s.studentName); put("guardian_name",s.guardianName); put("passport_number",s.passportNumber); put("nationality",s.nationality); put("date_of_birth",s.dateOfBirth); put("program_applied",s.programApplied); put("year_intake",s.yearIntake); put("level_applied",s.levelApplied); put("university",s.university); put("program_duration",s.programDuration); put("program_fee",s.programFee); put("scholarship_percent",s.scholarshipPercent); put("status",s.status); put("letter_date",s.letterDate); put("updated_at",now()) }; return if(s.id==0L){v.put("created_at",now()); db.insertOrThrow("students",null,v)} else {db.update("students",v,"id=?",arrayOf(s.id.toString())); s.id} }
    fun delete(id:Long){helper.writableDatabase.delete("students","id=?",arrayOf(id.toString()))}
    private fun now()=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.getDefault()).format(Date())
}

object DocxGenerator {
    fun generate(ctx:Context, s:Student): File {
        val asset=ctx.assets.open("gms_template.docx")
        val outDir=File(ctx.getExternalFilesDir(null),"Generated Documents").apply{mkdirs()}
        val safe=s.studentName.replace(Regex("[^A-Za-z0-9 _-]"),"").trim().replace(" ","_")
        val out=File(outDir,"${if(safe.isBlank())"Student" else safe}_${s.referenceId}.docx")
        val tmp=File(outDir,"template_work.docx"); FileOutputStream(tmp).use{asset.copyTo(it)}
        val fee=s.programFee.replace(",","").replace("$","").trim().toDoubleOrNull()?:0.0
        val scholarship=s.scholarshipPercent.ifBlank{"40-60%"}
        val repl=mapOf("DATE" to s.letterDate,"REFERENCE_ID" to s.referenceId,"STUDENT_NAME" to s.studentName,"GUARDIAN_NAME" to s.guardianName,"PASSPORT_NUMBER" to s.passportNumber,"NATIONALITY" to s.nationality,"DATE_OF_BIRTH" to s.dateOfBirth,"PROGRAM_APPLIED" to s.programApplied,"YEAR_INTAKE" to s.yearIntake,"LEVEL_APPLIED" to s.levelApplied,"UNIVERSITY" to s.university,"PROGRAM_DURATION" to s.programDuration,"PROGRAM_FEE" to money(fee),"SCHOLARSHIP_PERCENT" to scholarship,"40_PROGRAM_FEE" to money(fee*.60),"50_PROGRAM_FEE" to money(fee*.50),"60_PROGRAM_FEE" to money(fee*.40),"14_DAYS_DEADLINE" to addDays(s.letterDate,14),"21_DAYS_DEADLINE" to addDays(s.letterDate,21))
        ZipFile(tmp).use{zin-> ZipOutputStream(FileOutputStream(out)).use{zout-> val buf=ByteArray(8192); val entries=zin.entries(); while(entries.hasMoreElements()){ val e=entries.nextElement(); zout.putNextEntry(java.util.zip.ZipEntry(e.name)); if(e.name.endsWith(".xml")){ var text=zin.getInputStream(e).bufferedReader(Charsets.UTF_8).readText(); for((k,v) in repl) text=text.replace("{{$k}}",xmlEscape(v)); zout.write(text.toByteArray(Charsets.UTF_8)) } else zin.getInputStream(e).use{it.copyTo(zout)}; zout.closeEntry() } } }
        tmp.delete(); return out
    }
    private fun money(v:Double)=if(v%1.0==0.0) String.format(Locale.US,"%,.0f",v) else String.format(Locale.US,"%,.2f",v)
    private fun addDays(s:String,n:Int):String=try{ val d=SimpleDateFormat("dd/MM/yyyy",Locale.US).apply{isLenient=false}.parse(s)!!; val cal=Calendar.getInstance(); cal.time=d; cal.add(Calendar.DAY_OF_MONTH,n); SimpleDateFormat("dd/MM/yyyy",Locale.US).format(cal.time)}catch(_:Exception){s}
    private fun xmlEscape(s:String)=s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
}

class MainActivity:ComponentActivity(){
    private lateinit var db:StudentDb
    private val createDoc=registerForActivityResult(ActivityResultContracts.StartActivityForResult()){}
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); db=StudentDb(this); setContent{GmeApp()} }
    @Composable fun GmeApp(){ var page by remember{mutableStateOf("Dashboard")}; var refresh by remember{mutableIntStateOf(0)}; var selected by remember{mutableStateOf<Student?>(null)}; val students=remember(refresh){db.all()}; MaterialTheme(colorScheme=lightColorScheme(primary=androidx.compose.ui.graphics.Color(PURPLE.toLong()))){ Scaffold(topBar={TopAppBar(title={Text("Global Minds Education")})}, bottomBar={NavigationBar{listOf("Dashboard","Students","Add Student").forEach{p->NavigationBarItem(selected=page==p,onClick={page=p},icon={},label={Text(p)})}}}){pad->Box(Modifier.padding(pad).fillMaxSize()){when(page){"Dashboard"->Dashboard(students);"Students"->Students(students,{selected=it;page="Add Student"},{db.delete(it);refresh++});"Add Student"->Editor(selected,students,{db.save(it);selected=null;refresh++;page="Students"},{selected=null;page="Students"})}}}} }
    @Composable fun Dashboard(students:List<Student>){val count=students.size; Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("GME STUDENT MANAGER",style=MaterialTheme.typography.headlineSmall); Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Stat("Students",count);Stat("Accepted",students.count{it.status=="Accepted"});Stat("Payments",students.count{it.status=="Payment"})};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Stat("Visa",students.count{it.status=="Visa"});Stat("Enrolled",students.count{it.status=="Enrolled"})};Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("Universities",style=MaterialTheme.typography.titleLarge);students.groupBy{it.university.ifBlank{"Unknown"}}.entries.sortedByDescending{it.value.size}.forEach{Text("${it.key}   ${it.value.size}")}}}}}
    @Composable fun Stat(label:String,value:Int){Card(Modifier.weight(1f)){Column(Modifier.padding(10.dp)){Text(value.toString(),style=MaterialTheme.typography.headlineMedium);Text(label)}}}
    @Composable fun Students(list:List<Student>,onEdit:(Student)->Unit,onDelete:(Student)->Unit){var q by remember{mutableStateOf("")};val filtered=list.filter{val x=q.lowercase();x.isBlank()||it.studentName.lowercase().contains(x)||it.referenceId.lowercase().contains(x)||it.passportNumber.lowercase().contains(x)||it.university.lowercase().contains(x)};Column(Modifier.padding(16.dp)){OutlinedTextField(q,{q=it},Modifier.fillMaxWidth(),label={Text("Search students")});Spacer(Modifier.height(8.dp));LazyColumn{items(filtered){s->Card(Modifier.fillMaxWidth().padding(vertical=4.dp)){Column(Modifier.padding(12.dp)){Text(s.studentName,style=MaterialTheme.typography.titleMedium);Text("${s.referenceId} • ${s.status}");Text("${s.university} • ${s.programApplied}");Row{Button(onClick={onEdit(s)}){Text("Edit")};Spacer(Modifier.width(8.dp));OutlinedButton(onClick={onDelete(s)}){Text("Delete")};Spacer(Modifier.width(8.dp));Button(onClick={shareDoc(s)}){Text("Letter")}}}}}}}}
    @Composable fun Editor(existing:Student?,list:List<Student>,onSave:(Student)->Unit,onCancel:()->Unit){var s by remember(existing){mutableStateOf(existing?.copy()?:Student(referenceId=db.nextRef(),letterDate=SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(Date())))};LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text(if(existing==null)"Add Student" else "Edit Student",style=MaterialTheme.typography.headlineSmall);field("Reference ID",s.referenceId){s=s.copy(referenceId=it)};field("Student Name",s.studentName){s=s.copy(studentName=it)};field("Guardian Name",s.guardianName){s=s.copy(guardianName=it)};field("Passport Number",s.passportNumber){s=s.copy(passportNumber=it)};field("Nationality",s.nationality){s=s.copy(nationality=it)};field("Date of Birth",s.dateOfBirth){s=s.copy(dateOfBirth=it)};field("Program Applied",s.programApplied){s=s.copy(programApplied=it)};field("Year / Intake",s.yearIntake){s=s.copy(yearIntake=it)};field("Level Applied",s.levelApplied){s=s.copy(levelApplied=it)};field("University",s.university){s=s.copy(university=it)};field("Program Duration",s.programDuration){s=s.copy(programDuration=it)};field("Program Fee",s.programFee){s=s.copy(programFee=it)};field("Scholarship %",s.scholarshipPercent){s=s.copy(scholarshipPercent=it)};field("Letter Date",s.letterDate){s=s.copy(letterDate=it)};var expanded by remember{mutableStateOf(false)};Box{OutlinedButton(onClick={expanded=true},Modifier.fillMaxWidth()){Text("Status: ${s.status}")};DropdownMenu(expanded,{expanded=false}){statuses.forEach{DropdownMenuItem(text={Text(it)},onClick={s=s.copy(status=it);expanded=false})}}};Row{Button(onClick={if(s.studentName.isNotBlank())onSave(s)}){Text("SAVE / UPDATE")};Spacer(Modifier.width(8.dp));OutlinedButton(onClick=onCancel){Text("Cancel")};Spacer(Modifier.width(8.dp));Button(onClick={shareDoc(s)}){Text("Generate Letter")}}}}
    @Composable fun field(label:String,value:String,onChange:(String)->Unit){OutlinedTextField(value,onChange,Modifier.fillMaxWidth(),label={Text(label)},singleLine=true)}
    private fun shareDoc(s:Student){val f=DocxGenerator.generate(this,s);val uri=androidx.core.content.FileProvider.getUriForFile(this,"$packageName.fileprovider",f);val intent=Intent(Intent.ACTION_SEND).apply{type="application/vnd.openxmlformats-officedocument.wordprocessingml.document";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)};createDoc.launch(Intent.createChooser(intent,"Share acceptance letter"))}
}
