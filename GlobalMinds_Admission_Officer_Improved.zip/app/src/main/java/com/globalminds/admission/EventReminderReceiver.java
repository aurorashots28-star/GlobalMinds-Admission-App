package com.globalminds.admission;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class EventReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL = "gme_event_reminders";
    @Override public void onReceive(Context context, Intent intent) {
        String title = intent.getStringExtra("title");
        if (title == null || title.trim().isEmpty()) title = "Upcoming Global Minds event";
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Event reminders", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Reminders for Global Minds Education events");
            manager.createNotificationChannel(channel);
        }
        Notification notification = new NotificationCompat.Builder(context, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Global Minds event reminder")
                .setContentText(title)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(title + " is coming up. Open the app to review the venue, agenda and guest list."))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .build();
        try { manager.notify((int)(intent.getLongExtra("event_id", 1) % Integer.MAX_VALUE), notification); } catch (SecurityException ignored) { }
    }
}
