package com.globalminds.admission;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.*;import android.graphics.pdf.PdfDocument;import android.net.Uri;import android.provider.Settings;import android.webkit.*;import android.print.*;import android.os.CancellationSignal;import android.view.*;import android.view.inputmethod.EditorInfo;import android.widget.*;import android.text.InputType;import android.util.Base64;import java.io.*;import java.util.*;import java.util.zip.*;import java.text.SimpleDateFormat;import java.security.*;import javax.crypto.SecretKeyFactory;import javax.crypto.spec.PBEKeySpec;import org.json.*;import androidx.fragment.app.FragmentActivity;import androidx.biometric.BiometricManager;import androidx.biometric.BiometricPrompt;import androidx.core.content.ContextCompat;import com.google.zxing.BarcodeFormat;import com.google.zxing.EncodeHintType;import com.google.zxing.common.BitMatrix;import com.google.zxing.qrcode.QRCodeWriter;

public class MainActivity extends FragmentActivity {
    LinearLayout root, content, suspendedRoot, suspendedContent; ArrayList<JSONObject> programs=new ArrayList<>(); TextView title, suspendedTitle; StudentDb studentDb; Stack<LinearLayout> screenHistory=new Stack<>(), suspendedHistory=new Stack<>(); Stack<Runnable> refreshHistory=new Stack<>(), suspendedRefreshHistory=new Stack<>(); Runnable currentRefreshAction=null, suspendedRefreshAction=null; boolean restoringScreen=false, refreshingScreen=false; Runnable refreshStudentsAction=null;
    long selectedPhotoStudentId=-1; String pendingRegistrationPhotoUri=""; Button registrationPhotoButton; int purple=Color.rgb(91,42,134); int purpleDark=Color.rgb(57,28,83); int accent=Color.rgb(232,218,247); int bg=Color.rgb(246,244,249); int ink=Color.rgb(42,37,49);
    android.content.SharedPreferences securityPrefs; boolean isUnlocked=false, workspaceInitialized=false, showingBiometric=false; EditText loginPassword;
    boolean darkMode=false; android.content.SharedPreferences appearancePrefs; boolean applyingTheme=false;
    static final String KEY_SALT="password_salt", KEY_HASH="password_hash";
    public void onCreate(Bundle b){super.onCreate(b);appearancePrefs=getSharedPreferences("gme_appearance",MODE_PRIVATE);darkMode=appearancePrefs.getBoolean("dark_mode",false);securityPrefs=getSharedPreferences("gme_app_security",MODE_PRIVATE);securityGate();}
    @Override protected void onStart(){super.onStart();if(workspaceInitialized&&!isUnlocked&&!showingBiometric)securityGate();}
    @Override protected void onResume(){super.onResume();if(workspaceInitialized&&isUnlocked&&!showingBiometric&&!refreshingScreen){new Handler(Looper.getMainLooper()).postDelayed(()->refreshCurrentScreen(),120);}}
    @Override protected void onStop(){if(workspaceInitialized&&isUnlocked&&!showingBiometric){suspendedRoot=root;suspendedContent=content;suspendedTitle=title;suspendedHistory=new Stack<>();suspendedHistory.addAll(screenHistory);suspendedRefreshHistory=new Stack<>();suspendedRefreshHistory.addAll(refreshHistory);suspendedRefreshAction=currentRefreshAction;isUnlocked=false;}super.onStop();}
    void securityGate(){if(securityPrefs==null)securityPrefs=getSharedPreferences("gme_app_security",MODE_PRIVATE);if(!securityPrefs.contains(KEY_HASH))setupPasswordScreen();else loginScreen();}
    void setupPasswordScreen(){base("Secure your workspace");securityIntro("Create an app password to protect student records, financial information and documents on this device.");EditText first=passwordField("Create app password (6+ characters)");EditText second=passwordField("Confirm app password");content.addView(first);content.addView(second);Button save=btn("Set Password and Continue");content.addView(save);save.setOnClickListener(v->{String a=first.getText().toString(),b=second.getText().toString();if(a.length()<6){first.setError("Use at least 6 characters");return;}if(!a.equals(b)){second.setError("Passwords do not match");return;}try{savePassword(a);isUnlocked=true;openWorkspace();}catch(Exception e){toast("Could not secure the app. Please try again.");}});addText("Biometric unlock can be used after setup if fingerprint or face authentication is available on this device.",12,Color.GRAY);}
    void loginScreen(){base("Welcome back");securityIntro("Authenticate to access Global Minds.");loginPassword=passwordField("App password");content.addView(loginPassword);Button unlock=btn("Unlock Workspace");content.addView(unlock);unlock.setOnClickListener(v->tryPasswordUnlock());loginPassword.setOnEditorActionListener((v,action,event)->{if(action==EditorInfo.IME_ACTION_DONE){tryPasswordUnlock();return true;}return false;});if(biometricAvailable()){loginPassword.setHint("App password (or use the biometric prompt)");startBiometric();}else addText("Fingerprint or face unlock is not available. Enter your app password.",12,Color.GRAY);}
    void securityIntro(String text){TextView t=new TextView(this);t.setText(text);t.setTextSize(14);t.setTextColor(Color.rgb(105,98,113));t.setPadding(dp(2),dp(4),dp(2),dp(16));content.addView(t);}
    EditText passwordField(String hint){EditText e=field(hint);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);e.setSingleLine(true);e.setImeOptions(EditorInfo.IME_ACTION_DONE);return e;}
    void tryPasswordUnlock(){if(loginPassword==null)return;String attempt=loginPassword.getText().toString();try{if(verifyPassword(attempt)){isUnlocked=true;openWorkspace();}else{loginPassword.setError("Incorrect password. Try again.");loginPassword.setText("");}}catch(Exception e){toast("Unable to verify password. Please try again.");}}
    void openWorkspace(){if(!workspaceInitialized){studentDb=new StudentDb(this);migrateLegacyStudents();loadPrograms();workspaceInitialized=true;}isUnlocked=true;syncAllPaymentDeadlineAlerts();requestPaymentNotificationPermission();if(suspendedRoot!=null){root=suspendedRoot;content=suspendedContent;title=suspendedTitle;screenHistory=new Stack<>();screenHistory.addAll(suspendedHistory);refreshHistory=new Stack<>();refreshHistory.addAll(suspendedRefreshHistory);currentRefreshAction=suspendedRefreshAction;setContentView(root);attachThemeRail();suspendedRoot=null;suspendedContent=null;suspendedTitle=null;suspendedHistory.clear();suspendedRefreshHistory.clear();suspendedRefreshAction=null;}else dashboard();}
    void savePassword(String password)throws Exception{byte[] salt=new byte[16];new SecureRandom().nextBytes(salt);byte[] hash=derivePassword(password,salt);securityPrefs.edit().putString(KEY_SALT,Base64.encodeToString(salt,Base64.NO_WRAP)).putString(KEY_HASH,Base64.encodeToString(hash,Base64.NO_WRAP)).apply();}
    boolean verifyPassword(String password)throws Exception{String saltText=securityPrefs.getString(KEY_SALT,"");String hashText=securityPrefs.getString(KEY_HASH,"");if(saltText.isEmpty()||hashText.isEmpty())return false;byte[] salt=Base64.decode(saltText,Base64.NO_WRAP);byte[] expected=Base64.decode(hashText,Base64.NO_WRAP);return MessageDigest.isEqual(expected,derivePassword(password,salt));}
    byte[] derivePassword(String password,byte[] salt)throws Exception{PBEKeySpec spec=new PBEKeySpec(password.toCharArray(),salt,120000,256);try{return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).getEncoded();}finally{spec.clearPassword();}}
    boolean biometricAvailable(){try{return BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)==BiometricManager.BIOMETRIC_SUCCESS;}catch(Exception e){return false;}}
    void startBiometric(){if(!biometricAvailable()){toast("Set up fingerprint or face unlock in your phone settings, or use your app password.");return;}showingBiometric=true;BiometricPrompt prompt=new BiometricPrompt(this,ContextCompat.getMainExecutor(this),new BiometricPrompt.AuthenticationCallback(){@Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result){showingBiometric=false;isUnlocked=true;openWorkspace();}@Override public void onAuthenticationFailed(){toast("Biometric not recognised. Try again or use your password.");}@Override public void onAuthenticationError(int code,CharSequence message){showingBiometric=false;}});BiometricPrompt.PromptInfo info=new BiometricPrompt.PromptInfo.Builder().setTitle("Unlock Global Minds").setSubtitle("Authenticate to access confidential student records").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK).setNegativeButtonText("Use app password").build();try{prompt.authenticate(info);}catch(Exception e){showingBiometric=false;toast("Biometric unlock could not start. Enter your app password.");}}
    void changePasswordScreen(){base("Change app password");EditText current=passwordField("Current password"),next=passwordField("New password (6+ characters)"),confirm=passwordField("Confirm new password");content.addView(current);content.addView(next);content.addView(confirm);Button save=btn("Update Password");content.addView(save);save.setOnClickListener(v->{try{if(!verifyPassword(current.getText().toString())){current.setError("Current password is incorrect");return;}if(next.getText().toString().length()<6){next.setError("Use at least 6 characters");return;}if(!next.getText().toString().equals(confirm.getText().toString())){confirm.setError("Passwords do not match");return;}savePassword(next.getText().toString());toast("App password updated");dashboard();}catch(Exception e){toast("Could not update password");}});Button cancel=btn("Cancel");content.addView(cancel);cancel.setOnClickListener(v->dashboard());}
    void setRefreshAction(Runnable action){currentRefreshAction=action;}
    int currentScrollY(){
        try{
            if(root!=null&&root.getChildCount()>1&&root.getChildAt(1) instanceof ScrollView)
                return ((ScrollView)root.getChildAt(1)).getScrollY();
        }catch(Exception ignored){}
        return 0;
    }

    void restoreScrollY(int y){
        try{
            if(root!=null&&root.getChildCount()>1&&root.getChildAt(1) instanceof ScrollView){
                ScrollView sc=(ScrollView)root.getChildAt(1);
                sc.post(()->sc.scrollTo(0,Math.max(0,y)));
            }
        }catch(Exception ignored){}
    }

    void refreshCurrentScreen(){
        if(!isUnlocked||studentDb==null||currentRefreshAction==null||refreshingScreen)return;
        final int previousScrollY=currentScrollY();
        refreshingScreen=true;restoringScreen=true;
        try{currentRefreshAction.run();}
        catch(Exception ignored){}
        finally{
            restoringScreen=false;
            refreshingScreen=false;
            restoreScrollY(previousScrollY);
        }
    }

    void base(String t){
        if(root!=null&&!restoringScreen&&isUnlocked){screenHistory.push(root);refreshHistory.push(currentRefreshAction);}
        getWindow().setStatusBarColor(purpleDark);getWindow().setNavigationBarColor(darkMode?Color.rgb(18,16,22):Color.WHITE);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(darkMode?Color.rgb(18,16,22):bg);
        LinearLayout header=new LinearLayout(this);header.setOrientation(LinearLayout.VERTICAL);header.setPadding(dp(22),dp(18),dp(18),dp(20));
        android.graphics.drawable.GradientDrawable hd=shape(Color.rgb(57,28,83),0);hd.setCornerRadii(new float[]{0,0,0,0,dp(20),dp(20),dp(20),dp(20)});header.setBackground(hd);
        TextView brand=new TextView(this);brand.setText("GLOBALMINDS  •  EDUCATION");brand.setTextSize(11);brand.setLetterSpacing(.08f);brand.setTextColor(Color.rgb(225,210,240));brand.setTypeface(null,1);header.addView(brand);
        title=new TextView(this);title.setText(t);title.setTextSize(24);title.setTextColor(Color.WHITE);title.setTypeface(null,1);title.setPadding(0,dp(8),0,0);header.addView(title);TextView ticker=new TextView(this);ticker.setText("Global Minds Education  |  Transforming Education Empowering Futures  |  Be the Next Global Mind!     ✦     ");ticker.setTextSize(11);ticker.setTypeface(null,1);ticker.setTextColor(Color.rgb(246,236,255));ticker.setSingleLine(true);ticker.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);ticker.setMarqueeRepeatLimit(-1);ticker.setSelected(true);ticker.setPadding(0,dp(10),0,0);header.addView(ticker);root.addView(header,new LinearLayout.LayoutParams(-1,-2));
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(16),dp(16),dp(16),dp(22));ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);attachThemeRail();applyThemeWhenReady(root);
    }

    void applyThemeWhenReady(View target){
        if(target==null)return;
        target.getViewTreeObserver().addOnPreDrawListener(new android.view.ViewTreeObserver.OnPreDrawListener(){
            public boolean onPreDraw(){if(target.getViewTreeObserver().isAlive())target.getViewTreeObserver().removeOnPreDrawListener(this);applyThemeTree(target);return true;}
        });
    }
    void applyThemeTree(View v){
        if(v==null)return;
        if("gme_gold_notice".equals(v.getTag()))return;
        if(v instanceof Spinner)styleSpinner((Spinner)v);
        if(darkMode){
            if(v==root||v==content){v.setBackgroundColor(Color.rgb(18,16,22));}
            else if(!(v instanceof EditText) && !(v instanceof Spinner)){
                android.graphics.drawable.Drawable d=v.getBackground();
                if(d instanceof android.graphics.drawable.ColorDrawable){int c=((android.graphics.drawable.ColorDrawable)d).getColor();if(isLightSurface(c))v.setBackgroundColor(Color.rgb(35,32,41));}
                else if(d instanceof android.graphics.drawable.GradientDrawable){android.graphics.drawable.GradientDrawable gd=(android.graphics.drawable.GradientDrawable)d;try{android.content.res.ColorStateList cs=gd.getColor();if(cs!=null&&isLightSurface(cs.getDefaultColor())){gd.setColor(Color.rgb(35,32,41));gd.setStroke(dp(1),Color.rgb(72,65,82));}}catch(Exception ignored){}}
            }
            if(v instanceof EditText){
                EditText e=(EditText)v;
                e.setTextColor(Color.rgb(248,246,251));
                e.setHintTextColor(Color.rgb(174,166,186));
                e.setBackground(shape(Color.rgb(43,39,50),Color.rgb(91,78,108)));
            }
            else if(v instanceof TextView){TextView t=(TextView)v;int c=t.getCurrentTextColor();if(isDarkText(c)||c==Color.BLACK||c==Color.DKGRAY||c==Color.GRAY)t.setTextColor(Color.rgb(235,231,241));}
            if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int i=0;i<g.getChildCount();i++)applyThemeTree(g.getChildAt(i));}
        }else{
            if(v==root||v==content)v.setBackgroundColor(bg);
            if(v instanceof EditText){EditText e=(EditText)v;e.setTextColor(ink);e.setHintTextColor(Color.rgb(105,98,113));}
            if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int i=0;i<g.getChildCount();i++)applyThemeTree(g.getChildAt(i));}
        }
    }
    void styleSpinner(Spinner spinner){
        if(spinner==null||Boolean.TRUE.equals(spinner.getTag()))return;
        SpinnerAdapter original=spinner.getAdapter();
        if(original!=null){
            int selected=spinner.getSelectedItemPosition();
            ArrayList<String> values=new ArrayList<>();
            for(int i=0;i<original.getCount();i++){Object item=original.getItem(i);values.add(item==null?"":item.toString());}
            ArrayAdapter<String> themed=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,values){
                TextView makeItemView(String value,boolean dropdown){TextView tv=new TextView(MainActivity.this);tv.setText(value);tv.setTextSize(14);tv.setTextColor(darkMode?Color.rgb(248,246,251):ink);tv.setGravity(Gravity.CENTER_VERTICAL);tv.setPadding(dp(12),dp(dropdown?12:10),dp(12),dp(dropdown?12:10));tv.setBackgroundColor(darkMode?Color.rgb(43,39,50):Color.WHITE);return tv;}
                @Override public View getView(int position,View convertView,android.view.ViewGroup parent){return makeItemView(getItem(position),false);}
                @Override public View getDropDownView(int position,View convertView,android.view.ViewGroup parent){return makeItemView(getItem(position),true);}
            };
            spinner.setAdapter(themed);
            if(selected>=0&&selected<themed.getCount())spinner.setSelection(selected);
        }
        int spinnerSurface=darkMode?Color.rgb(43,39,50):Color.WHITE;
        spinner.setBackground(shape(spinnerSurface,darkMode?Color.rgb(91,78,108):Color.rgb(205,195,216)));
        if(Build.VERSION.SDK_INT>=16)spinner.setPopupBackgroundDrawable(new android.graphics.drawable.ColorDrawable(spinnerSurface));
        spinner.setTag(Boolean.TRUE);
    }
    boolean isLightSurface(int c){return (0.2126*Color.red(c)+0.7152*Color.green(c)+0.0722*Color.blue(c))>178;}
    boolean isDarkText(int c){return Color.alpha(c)>0&&Color.red(c)<155&&Color.green(c)<155&&Color.blue(c)<165;}
    void toggleDarkMode(){setDarkModeEnabled(!darkMode);}
    void setDarkModeEnabled(boolean enabled){
        if(darkMode==enabled)return;
        darkMode=enabled;
        if(appearancePrefs==null)appearancePrefs=getSharedPreferences("gme_appearance",MODE_PRIVATE);
        appearancePrefs.edit().putBoolean("dark_mode",darkMode).apply();
        toast(darkMode?"Dark mode enabled":"Light mode enabled");
        if(currentRefreshAction!=null)refreshCurrentScreen();else dashboard();
    }
    void attachThemeRail(){
        try{
            View decor=getWindow().getDecorView();
            if(!(decor instanceof android.view.ViewGroup))return;
            android.view.ViewGroup host=(android.view.ViewGroup)decor;
            View previous=host.findViewWithTag("gme_theme_rail");
            if(previous!=null)host.removeView(previous);
            LinearLayout rail=new LinearLayout(this);
            rail.setTag("gme_theme_rail");
            rail.setOrientation(LinearLayout.VERTICAL);
            rail.setGravity(Gravity.CENTER);
            rail.setPadding(dp(3),dp(5),dp(3),dp(5));
            rail.setBackground(shape(darkMode?Color.rgb(43,39,50):Color.WHITE,darkMode?Color.rgb(91,78,108):Color.rgb(205,195,216)));
            rail.setElevation(dp(8));
            TextView light=themeRailOption("☀","Light mode",!darkMode);
            TextView dark=themeRailOption("☾","Dark mode",darkMode);
            rail.addView(light,new LinearLayout.LayoutParams(dp(38),dp(42)));
            View gap=new View(this);rail.addView(gap,new LinearLayout.LayoutParams(1,dp(3)));
            rail.addView(dark,new LinearLayout.LayoutParams(dp(38),dp(42)));
            light.setOnClickListener(v->setDarkModeEnabled(false));
            dark.setOnClickListener(v->setDarkModeEnabled(true));
            android.widget.FrameLayout.LayoutParams lp=new android.widget.FrameLayout.LayoutParams(-2,-2,Gravity.RIGHT|Gravity.CENTER_VERTICAL);
            lp.rightMargin=dp(3);
            if(host instanceof android.widget.FrameLayout) ((android.widget.FrameLayout)host).addView(rail,lp);
            else host.addView(rail);
        }catch(Exception ignored){}
    }
    TextView themeRailOption(String symbol,String description,boolean selected){
        TextView option=new TextView(this);
        option.setText(symbol);option.setTextSize(21);option.setGravity(Gravity.CENTER);
        option.setContentDescription(description);option.setFocusable(true);option.setClickable(true);
        option.setTextColor(selected?Color.WHITE:(darkMode?Color.rgb(224,216,235):purpleDark));
        option.setBackground(shape(selected?purpleDark:(darkMode?Color.rgb(35,32,41):Color.rgb(246,244,249)),0));
        return option;
    }
    void appearanceSettings(){base("Appearance");addText("Choose the display theme for GlobalMinds Education.",14,ink);Switch sw=new Switch(this);sw.setText("Dark mode");sw.setTextSize(16);sw.setChecked(darkMode);content.addView(sw);sw.setOnCheckedChangeListener((button,checked)->{if(darkMode!=checked){darkMode=checked;appearancePrefs.edit().putBoolean("dark_mode",darkMode).apply();toast(darkMode?"Dark mode enabled":"Light mode enabled");appearanceSettings();}});Button back=btn("← Back to dashboard");content.addView(back);back.setOnClickListener(v->dashboard());}

    String[] africanCountries(){return new String[]{"Algeria","Angola","Benin","Botswana","Burkina Faso","Burundi","Cabo Verde","Cameroon","Central African Republic","Chad","Comoros","Democratic Republic of the Congo","Republic of the Congo","Côte d’Ivoire","Djibouti","Egypt","Equatorial Guinea","Eritrea","Eswatini","Ethiopia","Gabon","The Gambia","Ghana","Guinea","Guinea-Bissau","Kenya","Lesotho","Liberia","Libya","Madagascar","Malawi","Mali","Mauritania","Mauritius","Morocco","Mozambique","Namibia","Niger","Nigeria","Rwanda","São Tomé and Príncipe","Senegal","Seychelles","Sierra Leone","Somalia","South Africa","South Sudan","Sudan","Tanzania","Togo","Tunisia","Uganda","Zambia","Zimbabwe"};}
    String[] zimbabweProvinces(){return new String[]{"Bulawayo Metropolitan","Harare Metropolitan","Manicaland","Mashonaland Central","Mashonaland East","Mashonaland West","Masvingo","Matabeleland North","Matabeleland South","Midlands"};}
    String viewValue(View v){if(v instanceof EditText)return ((EditText)v).getText().toString().trim();if(v instanceof Spinner)return ((Spinner)v).getSelectedItem()==null?"":((Spinner)v).getSelectedItem().toString();return "";}
    void makeCircular(ImageView image){if(Build.VERSION.SDK_INT>=21){image.setClipToOutline(true);image.setOutlineProvider(new ViewOutlineProvider(){public void getOutline(View view, android.graphics.Outline outline){outline.setOval(0,0,view.getWidth(),view.getHeight());}});}}
    void pinStudentContext(JSONObject st){if(root==null||st==null)return;View old=root.findViewWithTag("sticky_student_context");if(old!=null)root.removeView(old);LinearLayout bar=new LinearLayout(this);bar.setTag("sticky_student_context");bar.setOrientation(LinearLayout.HORIZONTAL);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(12),dp(7),dp(12),dp(7));bar.setBackgroundColor(Color.WHITE);ImageView pic=new ImageView(this);pic.setScaleType(ImageView.ScaleType.CENTER_CROP);String u=st.optString("photo_uri");try{if(!u.isEmpty())pic.setImageURI(Uri.parse(u));}catch(Exception ignored){}pic.setBackground(shape(accent,0));makeCircular(pic);bar.addView(pic,new LinearLayout.LayoutParams(dp(38),dp(38)));LinearLayout text=new LinearLayout(this);text.setOrientation(LinearLayout.VERTICAL);text.setPadding(dp(10),0,0,0);TextView n=new TextView(this);n.setText(st.optString("name","Student record"));n.setTextColor(purpleDark);n.setTextSize(13);n.setTypeface(null,Typeface.BOLD);n.setMaxLines(1);n.setEllipsize(android.text.TextUtils.TruncateAt.END);text.addView(n);TextView id=new TextView(this);id.setText(st.optString("student_id")+" • "+st.optString("stage","Enquiry received"));id.setTextColor(Color.DKGRAY);id.setTextSize(11);id.setMaxLines(1);id.setEllipsize(android.text.TextUtils.TruncateAt.END);text.addView(id);bar.addView(text,new LinearLayout.LayoutParams(0,-2,1));root.addView(bar,new LinearLayout.LayoutParams(-1,-2));}
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    android.graphics.drawable.GradientDrawable shape(int color,int stroke){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(dp(16));if(stroke>0)d.setStroke(dp(1),stroke);return d;}
    String professionalButtonLabel(String label){String s=label==null?"":label;String lower=s.toLowerCase(Locale.ROOT);if(s.isEmpty()||s.startsWith("←")||s.startsWith("🔐")||s.codePointAt(0)>0x2600)return s;String emoji="";if(lower.contains("registration confirmation"))emoji="📄";else if(lower.contains("programme guidance")||lower.contains("program guidance"))emoji="🎓";else if(lower.contains("visa"))emoji="🛂";else if(lower.contains("flight")||lower.contains("travel"))emoji="✈️";else if(lower.contains("accommodation"))emoji="🏠";else if(lower.contains("arrival")||lower.contains("arrived"))emoji="🛬";else if(lower.contains("university reported")||lower.contains("reporting"))emoji="🏛️";else if(lower.contains("undertaking"))emoji="✍️";else if(lower.contains("application"))emoji="📝";else if(lower.contains("accepted")||lower.contains("admission"))emoji="✅";else if(lower.contains("enquiry"))emoji="💬";else if(lower.contains("counselling"))emoji="🤝";else if(lower.contains("payment")||lower.contains("finance")||lower.contains("invoice")||lower.contains("receipt"))emoji="💳";else if(lower.contains("document")||lower.contains("pdf")||lower.contains("report"))emoji="📑";else if(lower.contains("student"))emoji="👤";else if(lower.contains("search"))emoji="🔎";else if(lower.contains("setting"))emoji="⚙️";else if(lower.contains("event"))emoji="📅";else if(lower.contains("certificate"))emoji="🏅";else if(lower.contains("referee")||lower.contains("referral"))emoji="🤝";else if(lower.contains("save")||lower.contains("update"))emoji="💾";else if(lower.contains("delete")||lower.contains("remove"))emoji="🗑️";else if(lower.contains("share")||lower.contains("generate"))emoji="✨";return emoji.isEmpty()?s:emoji+"  "+s;}
    Button btn(String t){Button b=new Button(this);b.setText(professionalButtonLabel(t));b.setAllCaps(false);b.setTextSize(14);b.setTextColor(darkMode?Color.rgb(235,231,241):purpleDark);b.setTypeface(null,1);b.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);b.setPadding(dp(14),dp(10),dp(14),dp(10));b.setBackground(shape(darkMode?Color.rgb(43,39,50):Color.WHITE,darkMode?Color.rgb(78,68,91):Color.rgb(229,221,237)));b.setElevation(dp(1));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(6));b.setLayoutParams(lp);return b;}
    void featureCard(String icon,String heading,String description,Runnable action){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.HORIZONTAL);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(14),dp(13),dp(12),dp(13));card.setBackground(shape(Color.WHITE,Color.rgb(232,225,239)));card.setElevation(dp(2));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,dp(10));card.setLayoutParams(cp);TextView badge=new TextView(this);badge.setText(icon);badge.setTextSize(23);badge.setGravity(Gravity.CENTER);badge.setBackground(shape(accent,0));card.addView(badge,new LinearLayout.LayoutParams(dp(48),dp(48)));LinearLayout words=new LinearLayout(this);words.setOrientation(LinearLayout.VERTICAL);words.setPadding(dp(12),0,dp(6),0);TextView h=new TextView(this);h.setText(heading);h.setTextColor(ink);h.setTextSize(15);h.setTypeface(null,1);words.addView(h);TextView desc=new TextView(this);desc.setText(description);desc.setTextColor(Color.rgb(112,103,121));desc.setTextSize(12);desc.setPadding(0,dp(4),0,0);words.addView(desc);card.addView(words,new LinearLayout.LayoutParams(0,-2,1));TextView arrow=new TextView(this);arrow.setText("›");arrow.setTextColor(purple);arrow.setTextSize(28);card.addView(arrow);card.setOnClickListener(v->action.run());content.addView(card);}

    void dashboard(){
        base("Your workspace");
        setRefreshAction(()->dashboard());
        screenHistory.clear();refreshHistory.clear();
        ArrayList<JSONObject> allStudents=studentDb.search("");
        int admitted=0; for(JSONObject st:allStudents){String stage=st.optString("stage","");if(stage.contains("Admission")||stage.contains("Visa")||stage.contains("Arrived")||stage.contains("University Reported"))admitted++;}
        ArrayList<JSONObject> monthReferrals=studentDb.referralRankings(true);
        LinearLayout hero=new LinearLayout(this);hero.setOrientation(LinearLayout.VERTICAL);hero.setPadding(dp(20),dp(20),dp(20),dp(20));
        android.graphics.drawable.GradientDrawable heroBg=shape(Color.rgb(57,28,83),0);heroBg.setCornerRadius(dp(22));hero.setBackground(heroBg);hero.setElevation(dp(3));
        TextView eyebrow=new TextView(this);eyebrow.setText("YOUR GLOBAL MINDS COMMAND CENTRE  ✦");eyebrow.setTextSize(10);eyebrow.setLetterSpacing(.08f);eyebrow.setTypeface(null,1);eyebrow.setTextColor(Color.rgb(230,211,248));hero.addView(eyebrow);
        TextView welcome=new TextView(this);welcome.setText("Big futures start here.");welcome.setTextSize(25);welcome.setTypeface(null,1);welcome.setTextColor(Color.WHITE);welcome.setPadding(0,dp(8),0,dp(4));hero.addView(welcome);
        TextView subtitle=new TextView(this);subtitle.setText("Welcome back. Your students, events and achievements are all within reach.");subtitle.setTextSize(13);subtitle.setTextColor(Color.rgb(246,239,252));hero.addView(subtitle);
        TextView brandLine=new TextView(this);brandLine.setText("TRANSFORMING EDUCATION  •  EMPOWERING FUTURES");brandLine.setTextSize(10);brandLine.setTypeface(null,1);brandLine.setTextColor(Color.rgb(236,219,249));brandLine.setPadding(0,dp(14),0,0);hero.addView(brandLine);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.setMargins(0,0,0,dp(16));content.addView(hero,hp);
        addText("YOUR IMPACT AT A GLANCE",11,purple);
        LinearLayout metrics1=new LinearLayout(this);metrics1.setOrientation(LinearLayout.HORIZONTAL);metrics1.setGravity(Gravity.TOP);metrics1.addView(dashboardMetric("👥",String.valueOf(allStudents.size()),"STUDENT RECORDS",Color.rgb(239,231,249)),metricCellParams());View metricGap1=new View(this);metrics1.addView(metricGap1,new LinearLayout.LayoutParams(dp(12),1));metrics1.addView(dashboardMetric("🎓",String.valueOf(admitted),"ADMISSION+",Color.rgb(228,242,235)),metricCellParams());content.addView(metrics1);
        LinearLayout.LayoutParams ml=new LinearLayout.LayoutParams(-1,-2);ml.setMargins(0,dp(10),0,dp(14));
        LinearLayout metrics2=new LinearLayout(this);metrics2.setOrientation(LinearLayout.HORIZONTAL);metrics2.setGravity(Gravity.TOP);metrics2.addView(dashboardMetric("🤝",String.valueOf(monthReferrals.size()),"ACTIVE REFEREES",Color.rgb(255,244,220)),metricCellParams());View metricGap2=new View(this);metrics2.addView(metricGap2,new LinearLayout.LayoutParams(dp(12),1));metrics2.addView(dashboardMetric("📝",String.valueOf(getSharedPreferences("gme_lpu_sequence",MODE_PRIVATE).getInt("successful_generations",0)),"UNIVERSITY APPLICATIONS SUBMITTED",Color.rgb(226,239,250)),metricCellParams());content.addView(metrics2,ml);
        ArrayList<JSONObject> deadlineAlerts=deadlineRows();int dueTomorrowAlert=0,dueWeekAlert=0,overdueAlert=0;for(JSONObject ds:deadlineAlerts){int dd=ds.optInt("days_left");if(dd==1)dueTomorrowAlert++;else if(dd>=2&&dd<=7)dueWeekAlert++;else if(dd<0)overdueAlert++;}if(dueTomorrowAlert+dueWeekAlert+overdueAlert>0){LinearLayout deadlineAlertCard=new LinearLayout(this);deadlineAlertCard.setOrientation(LinearLayout.VERTICAL);deadlineAlertCard.setPadding(dp(15),dp(13),dp(15),dp(13));deadlineAlertCard.setBackground(shape(Color.rgb(255,250,232),Color.rgb(226,201,139)));deadlineAlertCard.setTag("gme_gold_notice");TextView daTitle=new TextView(this);daTitle.setText("PAYMENT DEADLINE FOLLOW-UPS");daTitle.setTextSize(11);daTitle.setTypeface(null,1);daTitle.setTextColor(Color.rgb(143,79,18));deadlineAlertCard.addView(daTitle);TextView daText=new TextView(this);daText.setText((dueTomorrowAlert>0?"Tomorrow: "+dueTomorrowAlert+" student(s)  •  ":"")+(dueWeekAlert>0?"Within 7 days: "+dueWeekAlert+"  •  ":"")+(overdueAlert>0?"Overdue: "+overdueAlert:""));daText.setTextSize(14);daText.setTypeface(null,1);daText.setTextColor(ink);daText.setPadding(0,dp(5),0,0);deadlineAlertCard.addView(daText);deadlineAlertCard.setOnClickListener(v->paymentDeadlines());LinearLayout.LayoutParams dal=new LinearLayout.LayoutParams(-1,-2);dal.setMargins(0,0,0,dp(15));content.addView(deadlineAlertCard,dal);}
        if(!monthReferrals.isEmpty()){JSONObject top=monthReferrals.get(0);LinearLayout alert=new LinearLayout(this);alert.setOrientation(LinearLayout.HORIZONTAL);alert.setGravity(Gravity.CENTER_VERTICAL);alert.setPadding(dp(14),dp(12),dp(14),dp(12));alert.setBackground(shape(Color.rgb(255,250,232),Color.rgb(226,201,139)));alert.setTag("gme_gold_notice");TextView medal=new TextView(this);medal.setText("🏆");medal.setTextSize(25);alert.addView(medal);LinearLayout aw=new LinearLayout(this);aw.setOrientation(LinearLayout.VERTICAL);aw.setPadding(dp(10),0,0,0);TextView at=new TextView(this);at.setText("MONTHLY SPOTLIGHT");at.setTextSize(10);at.setTypeface(null,1);at.setTextColor(purple);aw.addView(at);TextView av=new TextView(this);av.setText(top.optString("name")+" • "+top.optInt("total")+" recorded referrals this month");av.setTextSize(13);av.setTypeface(null,1);av.setTextColor(ink);aw.addView(av);alert.addView(aw,new LinearLayout.LayoutParams(0,-2,1));alert.setOnClickListener(v->newsHub());LinearLayout.LayoutParams al=new LinearLayout.LayoutParams(-1,-2);al.setMargins(0,0,0,dp(16));content.addView(alert,al);}
        addText("STUDENT OPERATIONS",11,purple);
        addDashboardTileRow("＋","Register a student","Start a new record",()->newStudent(),"⌕","Search students","Find profiles and history",()->students());
        addDashboardTileRow("↗","Student journey","Track progress milestones",()->journeyTracker(),"▣","Programmes","Explore study options",()->programs());
        addText("MANAGEMENT & INTELLIGENCE",11,purple);
        addDashboardTileRow("📅","Events & guests","Plan, invite and track attendance",()->eventsDashboard(),"▥","CEO dashboard","Operational insights and charts",()->ceoDashboard());
        addDashboardTileRow("⌖","Area intelligence","City and province trends",()->areaIntelligence(),"＄","Finance","Payments and balances",()->financialDashboard());
        addDashboardTileRow("⏰","Payment deadlines","7-day and tomorrow reminders",()->paymentDeadlines(),"▦","Deadline analysis","Upcoming and overdue payments",()->paymentDeadlines());
        addText("COMMUNITY & RECOGNITION",11,purple);
        addDashboardTileRow("▤","Document centre","Student documents and reports",()->documentCentre(),"🏅","Certificates","Recognise milestones",()->certificatesHub());
        addDashboardTileRow("🤝","Referrals","Referee profiles and awards",()->referralsHub(),"🔔","News & achievements","Recent activity and recognition",()->newsHub());
        addGap();Button appearance=btn(darkMode?"🌙  Appearance: Dark mode":"☀️  Appearance: Light mode");content.addView(appearance);appearance.setOnClickListener(v->appearanceSettings());Button auditUser=btn("Set Current Staff Name / ID for Audit Log");content.addView(auditUser);auditUser.setOnClickListener(v->setAuditUser());Button auditLog=btn("Activity & Audit Log");content.addView(auditLog);auditLog.setOnClickListener(v->showGlobalAudit());Button settings=btn("🔐  Change app password");content.addView(settings);settings.setOnClickListener(v->changePasswordScreen());
        addText("🔒 Offline workspace • Your records are stored on this device",11,Color.GRAY);
        addText("Programme information is guidance. Confirm current curriculum and entry requirements with the university before applying.",11,Color.GRAY);
    }
    LinearLayout.LayoutParams metricCellParams(){return new LinearLayout.LayoutParams(0,-2,1);}
    View dashboardMetric(String emoji,String value,String label,int tint){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(13),dp(12),dp(10),dp(12));card.setMinimumHeight(dp(112));card.setBackground(shape(Color.WHITE,Color.rgb(232,225,239)));TextView iconView=new TextView(this);iconView.setText(emoji);iconView.setTextSize(19);iconView.setGravity(Gravity.CENTER);iconView.setBackground(shape(tint,0));card.addView(iconView,new LinearLayout.LayoutParams(dp(36),dp(34)));TextView number=new TextView(this);number.setText(value);number.setTextSize(25);number.setTypeface(null,1);number.setTextColor(purpleDark);number.setPadding(0,dp(4),0,0);card.addView(number);TextView caption=new TextView(this);caption.setText(label);caption.setTextSize(9);caption.setLetterSpacing(.04f);caption.setTypeface(null,1);caption.setTextColor(Color.rgb(112,103,121));card.addView(caption);return card;}
    void addDashboardTileRow(String icon1,String title1,String desc1,Runnable action1,String icon2,String title2,String desc2,Runnable action2){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.setMargins(0,dp(2),0,dp(8));row.setLayoutParams(rp);row.addView(dashboardActionTile(icon1,title1,desc1,action1),new LinearLayout.LayoutParams(0,-2,1));View gap=new View(this);row.addView(gap,new LinearLayout.LayoutParams(dp(9),1));row.addView(dashboardActionTile(icon2,title2,desc2,action2),new LinearLayout.LayoutParams(0,-2,1));content.addView(row);}
    View dashboardActionTile(String icon,String heading,String description,Runnable action){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(12),dp(13),dp(10),dp(13));card.setBackground(shape(Color.WHITE,Color.rgb(232,225,239)));card.setElevation(dp(1));TextView badge=new TextView(this);badge.setText(icon);badge.setTextSize(22);badge.setGravity(Gravity.CENTER);badge.setBackground(shape(accent,0));card.addView(badge,new LinearLayout.LayoutParams(dp(42),dp(42)));TextView h=new TextView(this);h.setText(heading);h.setTextSize(14);h.setTypeface(null,1);h.setTextColor(ink);h.setPadding(0,dp(9),0,dp(2));card.addView(h);TextView d=new TextView(this);d.setText(description);d.setTextSize(11);d.setTextColor(Color.rgb(112,103,121));card.addView(d);card.setOnClickListener(v->action.run());return card;}
    void addText(String x,float z,int c){TextView t=new TextView(this);t.setText(x);t.setTextSize(z);t.setTextColor(darkMode&&isDarkText(c)?Color.rgb(235,231,241):c);t.setPadding(dp(3),dp(7),dp(3),dp(7));if(z>=17)t.setTypeface(null,1);content.addView(t);}
    void addReferralStamp(LinearLayout target){addReferralStamp(target, "");}
    void addReferralStamp(LinearLayout target,String refereeName){if(refereeName==null||refereeName.trim().isEmpty())return;TextView stamp=new TextView(this);stamp.setText("↗  Referred by "+refereeName.trim()+"  •  INTERNAL");stamp.setTextSize(11);stamp.setTypeface(null,Typeface.BOLD);stamp.setTextColor(purpleDark);stamp.setPadding(dp(10),dp(7),dp(10),dp(7));stamp.setBackground(shape(accent,Color.rgb(219,202,235)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);lp.setMargins(0,dp(3),0,dp(7));target.addView(stamp,lp);}
    void addGap(){Space s=new Space(this);content.addView(s,new LinearLayout.LayoutParams(1,18));}
    void loadPrograms(){try{InputStream in=getAssets().open("programs.json");BufferedReader r=new BufferedReader(new InputStreamReader(in));StringBuilder s=new StringBuilder();String l;while((l=r.readLine())!=null)s.append(l);JSONArray a=new JSONArray(s.toString());for(int i=0;i<a.length();i++)programs.add(a.getJSONObject(i));}catch(Exception e){}}
    void migrateLegacyStudents(){
        android.content.SharedPreferences prefs=getPreferences(0);
        if(prefs.getBoolean("students_migrated_to_database",false))return;
        String old=prefs.getString("students","");
        if(!old.isEmpty()){
            for(String row:old.split("\\n")){
                String[] parts=row.split(" \\| ",4);
                if(parts.length>=4)studentDb.insertLegacy(parts[0],parts[1],parts[2],parts[3]);
            }
        }
        prefs.edit().putBoolean("students_migrated_to_database",true).apply();
    }
    void newStudent(){pendingRegistrationPhotoUri="";base("Register a Student");addText("STUDENT PROFILE",12,purple);EditText name=field("Student full name *");EditText phone=field("Phone / WhatsApp (optional)");EditText city=field("City / Town");applyUppercaseInput(name);applyUppercaseInput(phone);applyUppercaseInput(city);Spinner country=new Spinner(this);ArrayList<String> countryOptions=new ArrayList<>();countryOptions.add("Select African country *");countryOptions.addAll(Arrays.asList(africanCountries()));country.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,countryOptions));Spinner gender=new Spinner(this);gender.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Select gender (optional)","Female","Male","Other","Prefer not to say"}));LinearLayout provinceHolder=new LinearLayout(this);provinceHolder.setOrientation(LinearLayout.VERTICAL);EditText manualProvince=field("Province / Region / State");applyUppercaseInput(manualProvince);Spinner zimProvince=new Spinner(this);ArrayList<String> zProvinceOptions=new ArrayList<>();zProvinceOptions.add("Select Zimbabwe province");zProvinceOptions.addAll(Arrays.asList(zimbabweProvinces()));zimProvince.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,zProvinceOptions));provinceHolder.addView(manualProvince);country.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){}public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long rowId){provinceHolder.removeAllViews();if(pos>0&&"Zimbabwe".equals(country.getSelectedItem().toString())){styleSpinner(zimProvince);provinceHolder.addView(zimProvince);}else provinceHolder.addView(manualProvince);}});content.addView(name);content.addView(phone);content.addView(city);addText("Nationality / Country *",12,purple);content.addView(country);addText("Province / Region",12,purple);content.addView(provinceHolder);addText("Gender",12,purple);content.addView(gender);registrationPhotoButton=btn("＋ Add Student Photograph (optional)");content.addView(registrationPhotoButton);registrationPhotoButton.setOnClickListener(v->{Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);pick.addCategory(Intent.CATEGORY_OPENABLE);pick.setType("image/*");startActivityForResult(pick,7415);});addText("REFERRAL SOURCE",12,purple);ArrayList<JSONObject> refs=studentDb.allReferees();ArrayList<String> labels=new ArrayList<>();labels.add("Select referee *");for(JSONObject r:refs)labels.add(r.optString("name")+" • "+r.optString("category"));Spinner referee=new Spinner(this);ArrayAdapter<String> refereeAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,labels);referee.setAdapter(refereeAdapter);content.addView(referee);Button addRef=btn("＋ Create a referee profile");content.addView(addRef);addRef.setOnClickListener(v->addRefereeForRegistration(refs,labels,refereeAdapter,referee));addText("Student country, location and referral source help Global Minds understand its reach and referral performance. Student ID is generated automatically.",12,Color.GRAY);Button choose=btn("Select Programme and Register");content.addView(choose);choose.setOnClickListener(v->{if(country.getSelectedItemPosition()==0){toast("Please select an African country");return;}if("Zimbabwe".equals(country.getSelectedItem().toString())&&zimProvince.getSelectedItemPosition()==0){toast("Please select one of Zimbabwe’s 10 provinces");return;}if(referee.getSelectedItemPosition()==0){toast("Please select a referee. Add a referee profile first if needed.");return;}View pv=provinceHolder.getChildAt(0);chooseForStudent(name,phone,city,pv,country,gender,refs.get(referee.getSelectedItemPosition()-1).optString("name"),pendingRegistrationPhotoUri);});Button enquiry=btn("Save as Enquiry (programme not selected yet)");content.addView(enquiry);enquiry.setOnClickListener(v->{String n=upper(name.getText().toString()),ph=upper(phone.getText().toString()),ct=upper(city.getText().toString()),pr=upper(viewValue(provinceHolder.getChildAt(0))),nat=country.getSelectedItemPosition()==0?"":country.getSelectedItem().toString();if(n.isEmpty()){name.setError("Required");return;}if(nat.isEmpty()){toast("Please select a country");return;}if("Zimbabwe".equals(nat)&&zimProvince.getSelectedItemPosition()==0){toast("Please select one of Zimbabwe’s 10 provinces");return;}if(referee.getSelectedItemPosition()==0){toast("Please select a referee. Add a referee profile first if needed.");return;}String refName=refs.get(referee.getSelectedItemPosition()-1).optString("name"),g=gender.getSelectedItemPosition()==0||gender.getSelectedItem().toString().equals("Prefer not to say")?"":gender.getSelectedItem().toString(),photoUri=pendingRegistrationPhotoUri;confirmDuplicate(n,ph,ct,nat,()->{try{JSONObject blank=new JSONObject();long id=studentDb.insert(n,ph,blank);studentDb.updateLocation(id,ct,pr);studentDb.updateNationality(id,nat);studentDb.updateStudentReferrer(id,refName);studentDb.updateStudentGender(id,g);if(!photoUri.isEmpty())studentDb.updateStudentPhoto(id,photoUri);toast("Enquiry saved");savedStudentDetails(studentDb.getStudent(id));}catch(Exception e){toast("Could not save enquiry: "+e.getMessage());}});});}
    void addRefereeForRegistration(ArrayList<JSONObject> refs,ArrayList<String> labels,ArrayAdapter<String> adapter,Spinner spinner){LinearLayout f=new LinearLayout(this);f.setPadding(20,8,20,8);f.setOrientation(LinearLayout.VERTICAL);EditText name=field("Referee full name *"),phone=field("Contact number"),pid=field("Student ID / Staff ID / National ID");Spinner gender=new Spinner(this);gender.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Not provided","Female","Male","Other","Prefer not to say"}));Spinner category=new Spinner(this);category.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Student","Staff","Alumni","Business partner","Other"}));f.addView(name);f.addView(phone);f.addView(pid);f.addView(gender);f.addView(category);new AlertDialog.Builder(this).setTitle("Create referee profile").setView(f).setNegativeButton("Cancel",null).setPositiveButton("Save and Select Referee",(d,w)->{String n=name.getText().toString().trim();if(n.isEmpty()){toast("Referee name is required");return;}String cat=category.getSelectedItem().toString();studentDb.addReferee(n,phone.getText().toString().trim(),pid.getText().toString().trim(),gender.getSelectedItem().toString().equals("Prefer not to say")?"Not provided":gender.getSelectedItem().toString(),cat);refs.clear();refs.addAll(studentDb.allReferees());ArrayList<String> refreshedLabels=new ArrayList<>();refreshedLabels.add("Select referee *");int selected=0;for(int i=0;i<refs.size();i++){JSONObject r=refs.get(i);refreshedLabels.add(r.optString("name")+" • "+r.optString("category"));if(r.optString("name").equalsIgnoreCase(n)&&r.optString("category").equalsIgnoreCase(cat))selected=i+1;}ArrayAdapter<String> refreshedAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,refreshedLabels);spinner.setAdapter(refreshedAdapter);spinner.setSelection(selected);toast("Referee profile created and selected");}).show();}
    void chooseForStudent(EditText name,EditText phone,EditText city,View province,Spinner nationality,Spinner gender,String refereeName,String photoUri){String n=upper(name.getText().toString()),ph=upper(phone.getText().toString()),ct=upper(city.getText().toString()),pr=upper(viewValue(province)),nat=nationality.getSelectedItemPosition()==0?"":nationality.getSelectedItem().toString(),g=gender.getSelectedItemPosition()==0||gender.getSelectedItem().toString().equals("Prefer not to say")?"":gender.getSelectedItem().toString();if(n.isEmpty()){name.setError("Student name is required");return;}if(nat.isEmpty()){toast("Please select a country");return;}confirmDuplicate(n,ph,ct,nat,()->programPicker(p->{try{long id=studentDb.insert(n,ph,p);studentDb.updateLocation(id,ct,pr);studentDb.updateNationality(id,nat);studentDb.updateStudentGender(id,g);studentDb.updateStudentReferrer(id,refereeName);if(photoUri!=null&&!photoUri.isEmpty())studentDb.updateStudentPhoto(id,photoUri);String sid=studentDb.getStudentId(id);documentScreen(n,ph,sid,"",p);}catch(Exception e){toast("Could not save student: "+e.getMessage());}}));}
    void confirmDuplicate(String name,String phone,String city,String nationality,Runnable proceed){ArrayList<JSONObject> matches=studentDb.findPotentialDuplicates(name,phone,city,nationality);if(matches.isEmpty()){proceed.run();return;}boolean exact=false;for(JSONObject m:matches){if(m.optBoolean("duplicate_exact",false)){exact=true;break;}}final boolean exactMatch=exact;LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(20),dp(8),dp(20),dp(8));TextView intro=new TextView(this);intro.setText(exactMatch?"An existing record has the same student name and phone number. This combination is treated as the same student, so a second record will not be created.":"One or more existing records look similar. Review them before creating a new record.");intro.setTextSize(14);intro.setTextColor(Color.DKGRAY);box.addView(intro);for(JSONObject m:matches){String status=m.optString("record_status","ACTIVE");String statusLabel="ACTIVE".equalsIgnoreCase(status)?"Active":status.equalsIgnoreCase("ARCHIVED")?"Archived":status.equalsIgnoreCase("WITHDRAWN")?"Withdrawn":status;String why=m.optString("duplicate_reason");Button rec=btn(m.optString("name")+" • "+m.optString("student_id")+"\n"+m.optString("phone")+" • "+statusLabel+"\n"+why);rec.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);box.addView(rec);rec.setOnClickListener(v->{savedStudentDetails(studentDb.getStudent(m.optLong("id")));});}AlertDialog dlg=new AlertDialog.Builder(this).setTitle(exactMatch?"Duplicate student detected":"Possible duplicate student").setView(box).setNegativeButton("Cancel",null).setPositiveButton(exactMatch?"Use Existing Student":"This Is a Different Student",null).create();dlg.setOnShowListener(x->{Button action=dlg.getButton(AlertDialog.BUTTON_POSITIVE);action.setOnClickListener(v->{if(exactMatch){JSONObject first=matches.get(0);dlg.dismiss();savedStudentDetails(studentDb.getStudent(first.optLong("id")));}else{dlg.dismiss();proceed.run();}});});dlg.show();}
    interface Pick{void go(JSONObject p);}
    void programs(){programPicker(null);}
    void programPicker(Pick pick){base("Programme Library");addText(programs.size()+" PROGRAMMES AVAILABLE",13,purple);EditText q=field("Search programmes...");content.addView(q);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);Runnable refresh=()->{list.removeAllViews();String term=q.getText().toString().toLowerCase();int c=0;for(JSONObject p:programs){String n=p.optString("name");if(term.isEmpty()||n.toLowerCase().contains(term)){Button b=btn(n+"\n"+p.optString("type")+" • "+p.optString("duration"));list.addView(b);b.setOnClickListener(v->{if(pick==null)detail(p);else pick.go(p);});if(++c>=80)break;}}};q.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){}public void onTextChanged(CharSequence s,int a,int b,int c){refresh.run();}public void afterTextChanged(android.text.Editable e){}});refresh.run();}
    void detail(JSONObject p){base(p.optString("name")); addText(p.optString("type"),15,purple);addText("Duration: "+p.optString("duration"),15,Color.DKGRAY);addText("Entry: "+p.optString("entryPoint"),15,Color.DKGRAY);String[] fs={"about","study","skills","practical","specialisation","careers","industries","jobs","furtherStudy","demand"};String[] hs={"What it is about","What students study","Skills developed","Practical / technical component","Specialisation / emphasis","Potential career paths","Relevant industries","Possible job roles","Further study options","Study expectations"};for(int i=0;i<fs.length;i++){addText(hs[i],16,purple);addText(p.optString(fs[i]),14,Color.DKGRAY);}Button back=btn("← Back to programmes");content.addView(back);back.setOnClickListener(v->programs());}
    void documentScreen(String name,String phone,String studentId,String ref,JSONObject p){base("Programme Guidance");pinStudentContext(studentDb.getStudentByStudentId(studentId));addText("STUDENT DETAILS",12,purple);addText(name,19,ink);addText("Student ID: "+studentId,14,purple);addText("Programme: "+p.optString("name"),16,ink);addText("Review the programme overview before generating the report. The report includes a dated Student Undertaking.",14,Color.DKGRAY);Button pdf=btn("Generate Programme Guidance PDF  ›");content.addView(pdf);pdf.setOnClickListener(v->makePdf(name,phone,studentId,"",p));}
    int pdfPageNo;
    PdfDocument pdfDoc;
    PdfDocument.Page pdfPage;
    Canvas pdfCanvas;
    Paint pdfPaint;
    float pdfY;
    final int pdfPurple=Color.rgb(74,35,110), pdfInk=Color.rgb(42,45,52), pdfMuted=Color.rgb(105,110,120), pdfLight=Color.rgb(245,241,249);
    void startPdfPage(){
        pdfPageNo++;
        pdfPage=pdfDoc.startPage(new PdfDocument.PageInfo.Builder(595,842,pdfPageNo).create());
        pdfCanvas=pdfPage.getCanvas();
        pdfCanvas.drawColor(Color.WHITE);
        Paint p=new Paint(3);p.setColor(pdfPurple);pdfCanvas.drawRect(0,0,595,12,p);
        p.setColor(pdfMuted);p.setTextSize(8);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
        pdfCanvas.drawText("GLOBALMINDS EDUCATION  •  PROGRAMME GUIDANCE",42,815,p);
        pdfCanvas.drawText("Page "+pdfPageNo,510,815,p);
        pdfY=48;
    }
    void finishPdfPage(){if(pdfPage!=null){pdfDoc.finishPage(pdfPage);pdfPage=null;}}
    void ensurePdfSpace(float needed){if(pdfY+needed>785){finishPdfPage();startPdfPage();}}
    void pdfText(String text,float x,float y,float size,int color,boolean bold){
        pdfPaint.setColor(color);pdfPaint.setTextSize(size);pdfPaint.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
        pdfCanvas.drawText(text,x,y,pdfPaint);
    }
    float drawPdfParagraph(String text,float x,float y,float maxWidth,float size,int color,boolean bold,float leading){
        pdfPaint.setColor(color);pdfPaint.setTextSize(size);pdfPaint.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
        String clean=text==null?"":text.trim();
        if(clean.isEmpty())return y;
        String[] words=clean.split("\\s+");String line="";float cursor=y;
        for(String word:words){
            String candidate=line.isEmpty()?word:line+" "+word;
            if(pdfPaint.measureText(candidate)>maxWidth && !line.isEmpty()){
                if(cursor+leading>785){finishPdfPage();startPdfPage();cursor=pdfY;}
                pdfText(line,x,cursor,size,color,bold);cursor+=leading;line=word;
            }else line=candidate;
        }
        if(!line.isEmpty()){
            if(cursor+leading>785){finishPdfPage();startPdfPage();cursor=pdfY;}
            pdfText(line,x,cursor,size,color,bold);cursor+=leading;
        }
        if(Math.abs(y-pdfY)<0.5f)pdfY=cursor;
        return cursor;
    }
    String expandedSection(String key,JSONObject p){
        String value=p.optString(key,"").trim();
        String name=p.optString("name","this programme");
        if(value.isEmpty())return "";
        if(key.equals("about"))return value+" This programme is intended to build a foundation in the field and help students connect classroom learning with the kinds of tasks and responsibilities they may encounter in further study or employment. The precise curriculum, facilities and learning outcomes should be confirmed with the university for the intake concerned.";
        if(key.equals("study"))return "Students may encounter the following subject areas: "+value+" These areas are typically developed progressively through lectures, guided reading, assignments and assessments. The balance between introductory concepts and advanced topics depends on the university's approved curriculum and the student's year of study.";
        if(key.equals("skills"))return "Through coursework and guided practice, students can work towards developing the following skills: "+value+" These skills usually improve through repeated practice, feedback, teamwork and the completion of assignments or projects; the level achieved will depend on the course requirements and each student's engagement.";
        if(key.equals("practical"))return value+" Practical activities are intended to help students apply theory, build confidence with relevant methods or equipment, and learn to document their work. The exact availability and format of laboratories, placements, workshops or internships must be confirmed with the institution.";
        if(key.equals("careers")||key.equals("jobs"))return "Career pathways related to this field may include: "+value+" Students can build towards these opportunities through their academic work, practical experience and continued professional development.";
        if(key.equals("industries"))return "Knowledge from this field may be relevant to organisations in areas such as: "+value+" The most suitable sector will depend on the student's interests, chosen specialisation, practical experience and local employment conditions.";
        if(key.equals("furtherStudy"))return value+" Eligibility for any next qualification depends on admission criteria, academic results, prerequisite subjects and the rules of the receiving institution.";
        if(key.equals("licensing"))return "";
        if(key.equals("demand"))return value+" Applicants should be prepared for regular attendance, independent study, timely completion of assignments and active participation in assessments and any required practical components.";
        if(key.equals("entryNote"))return "";
        if(key.equals("specialisation"))return value+" Students can discuss available electives, project options and any formal specialisation routes with the university before choosing their academic plan.";
        return value;
    }
    void pdfSection(String heading,String body){
        if(body==null||body.trim().isEmpty())return;
        ensurePdfSpace(42);
        pdfCanvas.drawRect(42,pdfY-13,553,pdfY+7,new Paint(3){{setColor(pdfLight);}});
        pdfText(heading,50,pdfY,11,pdfPurple,true);pdfY+=20;
        drawPdfParagraph(body,50,pdfY,495,9.5f,pdfInk,false,14);
        pdfY+=10;
    }
    void makePdf(String name,String phone,String studentId,String ref,JSONObject p){
        try{
            String generatedDate=dateText(System.currentTimeMillis());
            pdfDoc=new PdfDocument();pdfPaint=new Paint(3);pdfPageNo=0;startPdfPage();
            // Branded title block
            pdfCanvas.drawRect(0,12,595,155,new Paint(3){{setColor(pdfPurple);}});
            pdfText("GLOBALMINDS",42,48,12,Color.rgb(226,211,240),true);
            pdfText("STUDENT PROGRAMME",42,79,22,Color.WHITE,true);
            pdfText("GUIDANCE REPORT",42,106,22,Color.WHITE,true);
            pdfText("A clear overview to support an informed study decision",42,132,9,Color.WHITE,false);
            pdfY=180;
            pdfText("STUDENT DETAILS",42,pdfY,10,pdfPurple,true);
            float studentTop=pdfY+8;
            float studentBottom=studentTop+92;
            pdfCanvas.drawRoundRect(42,studentTop,553,studentBottom,8,8,new Paint(3){{setColor(pdfLight);}});
            // Fixed two-column, two-row layout. Every value is positioned from the card's
            // own coordinates so wrapped text cannot push neighbouring fields into each other.
            float leftX=54,rightX=320;
            float label1=studentTop+20,value1=studentTop+38;
            float label2=studentTop+58,value2=studentTop+76;
            pdfText("Student",leftX,label1,8,pdfMuted,true);
            pdfText("Student ID",rightX,label1,8,pdfMuted,true);
            pdfText(name==null||name.trim().isEmpty()?"Not provided":name,leftX,value1,10.5f,pdfInk,true);
            pdfText(studentId==null||studentId.trim().isEmpty()?"Not provided":studentId,rightX,value1,10,pdfInk,true);
            pdfText("Phone / WhatsApp",leftX,label2,8,pdfMuted,true);
            pdfText("City / Province",rightX,label2,8,pdfMuted,true);
            pdfText(phone==null||phone.trim().isEmpty()?"Not provided":phone,leftX,value2,9,pdfInk,false);
            JSONObject studentRecord=studentDb.getStudentByStudentId(studentId);
            String area=areaLabel(studentRecord);
            pdfText(area==null||area.trim().isEmpty()?"Not recorded":area,rightX,value2,8.8f,pdfInk,false);
            pdfY=studentBottom+28;

            pdfText("Report generated: "+generatedDate,42,pdfY,9,pdfMuted,false);
            pdfY+=24;
            pdfText("PROGRAMME OVERVIEW",42,pdfY,10,pdfPurple,true);
            float programmeTop=pdfY+10;
            float programmeBottom=programmeTop+118;
            pdfCanvas.drawRoundRect(42,programmeTop,553,programmeBottom,8,8,new Paint(3){{setColor(Color.rgb(250,249,252));}});
            pdfText(p.optString("name","Programme not specified"),54,programmeTop+30,12.5f,pdfPurple,true);
            pdfText("Qualification type",54,programmeTop+60,8,pdfMuted,true);
            pdfText(p.optString("type","Not specified"),54,programmeTop+78,9,pdfInk,false);
            pdfText("Typical duration",320,programmeTop+60,8,pdfMuted,true);
            pdfText(p.optString("duration","Confirm with university"),320,programmeTop+78,9,pdfInk,false);
            pdfText("Listed entry point",54,programmeTop+98,8,pdfMuted,true);
            pdfText(p.optString("entryPoint","Confirm with university"),150,programmeTop+98,9,pdfInk,false);
            pdfY=programmeBottom+22;
            String[] fs={"about","study","skills","practical","specialisation","careers","industries","jobs","furtherStudy","demand"};
            String[] hs={"Programme overview","Areas of study","Skills students can develop","Practical learning","Specialisation and focus","Potential career pathways","Relevant employment sectors","Examples of job roles","Further study options","Study expectations"};
            for(int i=0;i<fs.length;i++)pdfSection(hs[i],expandedSection(fs[i],p));
            ensurePdfSpace(125);
            pdfText("STUDENT UNDERTAKING",42,pdfY,11,pdfPurple,true);pdfY+=23;
            drawPdfParagraph("[  ] I understand the programme overview and would like to proceed.",50,pdfY,490,10,pdfInk,false,17);pdfY+=26;
            pdfText("Date of undertaking: "+generatedDate,50,pdfY,9,pdfMuted,false);pdfY+=18;
            pdfText("Student signature: ______________________________",50,pdfY,9,pdfInk,false);pdfY+=18;
            pdfCanvas.drawLine(50,pdfY,545,pdfY,new Paint(1){{setColor(Color.LTGRAY);setStrokeWidth(1);}});
            pdfY+=22;pdfText("Guidance note",42,pdfY,9,pdfPurple,true);pdfY+=15;
            drawPdfParagraph("This report is an educational guidance document, not an offer of admission or a guarantee of employment. Programme details, entry requirements, curriculum, practical opportunities and professional recognition should be verified with the university and relevant authorities before a final decision.",42,pdfY,510,8.5f,pdfMuted,false,12);
            if(pdfY>650){finishPdfPage();startPdfPage();pdfY=82;}else{pdfY=Math.max(pdfY+30,650);}
            pdfText("OFFICE SIGNATORY",42,pdfY,10,pdfPurple,true);pdfY+=16;android.content.SharedPreferences brand=getSharedPreferences("gme_document_branding",MODE_PRIVATE);drawBrandingImage(pdfCanvas,"signature_uri",42,pdfY-2,220,pdfY+60);drawBrandingImage(pdfCanvas,"stamp_uri",405,pdfY-8,535,pdfY+68);pdfY+=64;pdfText(brand.getString("signatory_name","Authorised Signatory"),42,pdfY,9,pdfInk,true);pdfY+=13;pdfText(brand.getString("signatory_role","Global Minds Education"),42,pdfY,8,pdfMuted,false);
            finishPdfPage();
            File f=new File(getCacheDir(),safe(studentId)+"_"+safe(p.optString("name","Programme"))+"_Programme_Guidance.pdf");
            FileOutputStream o=new FileOutputStream(f);pdfDoc.writeTo(o);o.close();pdfDoc.close();studentDb.updateStageByStudentId(studentId,"Programme guidance issued");share(f);
        }catch(Exception e){try{finishPdfPage();if(pdfDoc!=null)pdfDoc.close();}catch(Exception ignored){}toast(e.toString());}
    }
    String safe(String s){return s.replaceAll("[^A-Za-z0-9_-]","_");}
    void share(File f){Uri u=Uri.parse("content://com.globalminds.admission.pdfprovider/"+f.getName());Intent i=new Intent(Intent.ACTION_SEND);String n=f.getName().toLowerCase(Locale.ROOT);String mime=n.endsWith(".zip")?"application/zip":(n.endsWith(".docx")?"application/vnd.openxmlformats-officedocument.wordprocessingml.document":(n.endsWith(".doc")?"application/msword":"application/pdf"));i.setType(mime);i.putExtra(Intent.EXTRA_STREAM,u);i.setClipData(ClipData.newUri(getContentResolver(),"Global Minds document",u));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Share document"));}
    interface ChipClick { void onSelect(int index); }
    void horizontalFilterChips(LinearLayout host,String[] labels,int[] counts,int selected,ChipClick listener){
        Object savedPosition=host.getTag();final int savedX=savedPosition instanceof Integer?Math.max(0,(Integer)savedPosition):0;
        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);hsv.setFillViewport(false);hsv.setSmoothScrollingEnabled(true);hsv.setFocusable(false);hsv.setFocusableInTouchMode(false);
        LinearLayout strip=new LinearLayout(this);strip.setOrientation(LinearLayout.HORIZONTAL);strip.setPadding(dp(2),dp(7),dp(2),dp(10));
        ArrayList<View> chipViews=new ArrayList<>();
        for(int i=0;i<labels.length;i++){final int ix=i;boolean active=i==selected;TextView chip=new TextView(this);String count=counts!=null&&i<counts.length?"  "+counts[i]:"";chip.setText(labels[i]+count);chip.setTextSize(14);chip.setTypeface(null,active?Typeface.BOLD:Typeface.NORMAL);chip.setTextColor(active?Color.WHITE:Color.rgb(95,91,101));chip.setGravity(Gravity.CENTER);chip.setSingleLine(true);chip.setFocusable(false);chip.setPadding(dp(18),dp(10),dp(18),dp(10));chip.setBackground(shape(active?purpleDark:Color.WHITE,active?purpleDark:Color.rgb(218,215,222)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);lp.setMargins(0,0,dp(9),0);strip.addView(chip,lp);chipViews.add(chip);chip.setOnClickListener(v->{host.setTag(hsv.getScrollX());listener.onSelect(ix);});}
        hsv.addView(strip);host.addView(hsv,new LinearLayout.LayoutParams(-1,-2));
        hsv.setOnScrollChangeListener((v,scrollX,scrollY,oldX,oldY)->host.setTag(scrollX));
        hsv.post(()->{
            int maxScroll=Math.max(0,strip.getWidth()-hsv.getWidth());
            int target=Math.min(savedX,maxScroll);
            if(selected>=0&&selected<chipViews.size()){
                View activeChip=chipViews.get(selected);
                int chipLeft=activeChip.getLeft();int chipRight=activeChip.getRight();int viewport=hsv.getWidth();
                int margin=dp(18);int visibleLeft=hsv.getScrollX()+margin;int visibleRight=hsv.getScrollX()+viewport-margin;
                if(chipLeft<visibleLeft||chipRight>visibleRight){
                    target=Math.max(0,Math.min(maxScroll,chipLeft-(viewport-activeChip.getWidth())/2));
                }else target=hsv.getScrollX();
            }
            hsv.smoothScrollTo(target,0);
        });
    }
    void students(){
        base("Search / Manage Students");setRefreshAction(()->students());
        EditText query=field("Search by name, reference, phone, programme, city or province");content.addView(query);Button inactive=btn("Archived / Withdrawn Records");content.addView(inactive);inactive.setOnClickListener(v->inactiveStudents());
        final String[] groups=journeyFilterLabels();final int[] selected={0};
        LinearLayout chips=new LinearLayout(this);chips.setOrientation(LinearLayout.VERTICAL);content.addView(chips);TextView count=new TextView(this);count.setTextColor(Color.GRAY);count.setPadding(4,4,4,8);content.addView(count);LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);content.addView(results);
        final Runnable[] render={null};render[0]=()->{results.removeAllViews();ArrayList<JSONObject> found=studentDb.search(query.getText().toString().trim());int[] totals=new int[groups.length];totals[0]=found.size();for(JSONObject st:found)totals[journeyFilterIndex(st.optString("stage","Enquiry received"))]++;chips.removeAllViews();horizontalFilterChips(chips,groups,totals,selected[0],ix->{selected[0]=ix;if(render[0]!=null)render[0].run();});
            ArrayList<JSONObject> visible=new ArrayList<>();for(JSONObject st:found)if(selected[0]==0||selected[0]==journeyFilterIndex(st.optString("stage","Enquiry received")))visible.add(st);count.setText(visible.size()+" student record"+(visible.size()==1?"":"s")+" shown");if(visible.isEmpty()){addResultMessage(results,"No matching students at this journey milestone.");return;}for(JSONObject st:visible){String ph=st.optString("phone");addStudentListRow(results,st,st.optString("name")+"\nStudent ID: "+st.optString("student_id")+"\n"+st.optString("programme")+" • "+st.optString("stage","Enquiry received")+"\nArea: "+areaLabel(st)+"\nNationality: "+(st.optString("nationality").isEmpty()?"Not recorded":st.optString("nationality"))+"\nReferred by: "+(st.optString("referred_by").isEmpty()?"Not recorded":st.optString("referred_by"))+(ph.isEmpty()?"":"\n"+ph));}};
        query.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){}public void onTextChanged(CharSequence s,int a,int b,int c){render[0].run();}public void afterTextChanged(android.text.Editable e){}});
        // Rebuild on chip selection without changing the search term.
        refreshStudentsAction=()->render[0].run();render[0].run();
    }
    void addTextToContainer(LinearLayout parent,String value,int size,int color){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(darkMode&&isDarkText(color)?Color.rgb(235,231,241):color);t.setPadding(dp(8),dp(10),dp(8),dp(10));parent.addView(t);}
    void addStudentListRow(LinearLayout parent,JSONObject st,String details){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(7),dp(8),dp(7));row.setBackground(shape(Color.WHITE,Color.rgb(232,225,239)));LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,-2);rlp.setMargins(0,dp(4),0,dp(6));parent.addView(row,rlp);ImageView photo=new ImageView(this);photo.setScaleType(ImageView.ScaleType.CENTER_CROP);photo.setBackground(shape(accent,Color.rgb(220,210,232)));makeCircular(photo);String uri=st.optString("photo_uri");try{if(!uri.isEmpty())photo.setImageURI(Uri.parse(uri));}catch(Exception ignored){}row.addView(photo,new LinearLayout.LayoutParams(dp(66),dp(66)));TextView info=new TextView(this);info.setText(details);info.setTextSize(13);info.setTypeface(null,Typeface.BOLD);info.setTextColor(purpleDark);info.setPadding(dp(10),dp(5),dp(4),dp(5));row.addView(info,new LinearLayout.LayoutParams(0,-2,1));row.setOnClickListener(v->savedStudentDetails(st));}
    void addResultMessage(LinearLayout list,String message){TextView t=new TextView(this);t.setText(message);t.setTextColor(Color.GRAY);t.setPadding(4,16,4,16);list.addView(t);}

    void generateApplicationRegistrationConfirmation(JSONObject st){
        if(st==null||st.optLong("id")<=0){toast("Student record could not be found.");return;}
        String studentName=st.optString("name","").trim();
        String studentId=st.optString("student_id","").trim();
        if(studentName.isEmpty()||studentId.isEmpty()){toast("Student name or ID is missing from the saved record.");return;}
        try{
            String registrationDate=dateText(st.optLong("created_at")>0?st.optLong("created_at"):System.currentTimeMillis());
            String appRef="GME-APP-"+studentId.replaceAll("[^A-Za-z0-9-]","").toUpperCase(Locale.ROOT);
            String serialDate=new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date());
            String serialSuffix=String.format(Locale.US,"%06d",new SecureRandom().nextInt(1000000));
            String documentSerial="GME-ARC-"+serialDate+"-"+studentId.replaceAll("[^A-Za-z0-9_]", "_")+"-"+serialSuffix;
            String qrPayload="GLOBALMINDS EDUCATION (GLOBALMINDS EDUCATION | APPLICATION REGISTRATION ACKNOWLEDGEMENT)\n\n"
                +"Key Details from the Code\n"
                +"Institution: GlobalMinds Education\n"
                +"Document Type: Application Registration Confirmation\n"
                +"Serial Number: "+documentSerial+"\n"
                +"Student Name: "+studentName+"\n"
                +"Student ID: "+studentId+"\n"
                +"Application Reference: "+appRef+"\n"
                +"Status: Application received and recorded\n"
                +"Registration Date: "+registrationDate+"\n"
                +"Contact: admissions@globalmindsstudy.com\n"
                +"Phone: +91 90415 74079\n"
                +"This acknowledges application registration only. It is not a university admission offer.";
            PdfDocument doc=new PdfDocument();
            PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());
            Canvas c=page.getCanvas(); c.drawColor(Color.WHITE);
            Paint p=new Paint(3);
            int deep=Color.rgb(57,28,83), purple=Color.rgb(91,42,134), light=Color.rgb(235,225,244), ink=Color.rgb(45,42,50), muted=Color.rgb(105,99,112);
            // Corporate letterhead and geometric accents
            p.setColor(deep);c.drawRect(0,0,595,112,p);
            p.setColor(purple);Path corner=new Path();corner.moveTo(495,0);corner.lineTo(595,0);corner.lineTo(595,100);corner.close();c.drawPath(corner,p);
            p.setColor(Color.rgb(171,132,202));Path accentShape=new Path();accentShape.moveTo(535,0);accentShape.lineTo(595,0);accentShape.lineTo(595,58);accentShape.close();c.drawPath(accentShape,p);
            p.setColor(Color.WHITE);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(15);c.drawText("GLOBALMINDS EDUCATION",38,39,p);
            p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setTextSize(8.5f);c.drawText("TRANSFORMING EDUCATION, EMPOWERING FUTURES",38,57,p);
            p.setTextSize(9);c.drawText("Official Application Correspondence",38,82,p);
            // Title
            p.setColor(purple);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(18);c.drawText("APPLICATION REGISTRATION",38,151,p);c.drawText("CONFIRMATION",38,174,p);
            p.setColor(muted);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setTextSize(9);c.drawText("Your journey to a global future starts here.",38,195,p);
            // Reference/date panel
            p.setColor(light);c.drawRoundRect(38,218,557,278,8,8,p);
            p.setColor(deep);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(8);c.drawText("APPLICATION REFERENCE",52,239,p);c.drawText("REGISTRATION DATE",330,239,p);
            p.setColor(ink);p.setTextSize(10);c.drawText(appRef,52,258,p);c.drawText(registrationDate,330,258,p);
            // Student details
            p.setColor(purple);p.setTextSize(10);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));c.drawText("STUDENT DETAILS",38,314,p);
            p.setColor(Color.rgb(250,249,252));c.drawRoundRect(38,326,557,421,7,7,p);
            p.setColor(muted);p.setTextSize(8);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));c.drawText("FULL REGISTERED NAME",52,349,p);c.drawText("GLOBALMINDS STUDENT ID",330,349,p);
            p.setColor(ink);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(11);c.drawText(clipPdf(studentName,38),52,369,p);c.drawText(clipPdf(studentId,25),330,369,p);
            p.setColor(muted);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setTextSize(8);c.drawText("PROGRAMME OF INTEREST",52,395,p);
            p.setColor(ink);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(10);c.drawText(clipPdf(st.optString("programme","Not yet assigned"),54),52,411,p);
            // Confirmation letter
            p.setColor(ink);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setTextSize(10.5f);
            c.drawText("Dear "+clipPdf(studentName,48)+",",38,456,p);
            c.drawText("We are pleased to confirm that your application has been received",38,481,p);
            c.drawText("and recorded by GlobalMinds Education.",38,497,p);
            c.drawText("This confirmation marks an important first step in your educational",38,523,p);
            c.drawText("journey. Our team will guide you through the next stages, including",38,539,p);
            c.drawText("application review, programme guidance and any further requirements.",38,555,p);
            c.drawText("Please keep this document and your application reference for future",38,581,p);
            c.drawText("communication with GlobalMinds Education.",38,597,p);
            p.setColor(purple);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(10.5f);c.drawText("Your ambition matters. Your future matters.",38,631,p);
            p.setColor(ink);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setTextSize(10);c.drawText("Thank you for choosing GlobalMinds Education.",38,657,p);c.drawText("We look forward to supporting you on the journey ahead.",38,673,p);
            // Signature section and an offline QR containing readable document details.
            int signY=710;
            p.setColor(ink);p.setTextSize(9);c.drawText("Yours sincerely,",38,signY,p);
            String signatory=getSharedPreferences("gme_document_branding",MODE_PRIVATE).getString("signatory_name","GlobalMinds Education");
            String designation=getSharedPreferences("gme_document_branding",MODE_PRIVATE).getString("signatory_role","Admissions & Student Support");
            p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));c.drawText(clipPdf(signatory,38),38,signY+20,p);
            p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setTextSize(8.5f);c.drawText(clipPdf(designation,42),38,signY+35,p);
            p.setColor(purple);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(8);c.drawText("DOCUMENT SERIAL",38,766,p);
            p.setColor(ink);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setTextSize(7.5f);c.drawText(clipPdf(documentSerial,47),38,780,p);
            p.setColor(muted);p.setTextSize(7);c.drawText("Scan QR with Google Lens to read document details",38,795,p);
            try{
                Map<EncodeHintType,Object> hints=new EnumMap<>(EncodeHintType.class);hints.put(EncodeHintType.MARGIN,1);hints.put(EncodeHintType.CHARACTER_SET,"UTF-8");
                BitMatrix matrix=new QRCodeWriter().encode(qrPayload,BarcodeFormat.QR_CODE,420,420,hints);
                Bitmap qrBitmap=Bitmap.createBitmap(matrix.getWidth(),matrix.getHeight(),Bitmap.Config.RGB_565);
                for(int y=0;y<matrix.getHeight();y++)for(int x=0;x<matrix.getWidth();x++)qrBitmap.setPixel(x,y,matrix.get(x,y)?Color.BLACK:Color.WHITE);
                p.setColor(Color.WHITE);c.drawRect(427,686,557,816,p);c.drawBitmap(qrBitmap,null,new Rect(439,698,545,804),p);qrBitmap.recycle();
                p.setColor(muted);p.setTextSize(6.5f);c.drawText("DOCUMENT DETAILS QR",439,813,p);
            }catch(Exception qrError){throw new IOException("Could not create document QR code",qrError);}
            p.setColor(purple);c.drawRect(38,819,557,821,p);
            p.setColor(muted);p.setTextSize(7);c.drawText("GlobalMinds Education • admissions@globalmindsstudy.com • +91 90415 74079",38,833,p);
            doc.finishPage(page);
            // Generate into temporary cache only; filename is application reference + numeric date.
            // YYYYMMDD keeps filenames sortable and unambiguous across locales.
            File cacheDir=getCacheDir();
            String safeAppRef=appRef.replaceAll("[^A-Za-z0-9_-]", "_");
            String fileDate=new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date());
            String outputFileName=safeAppRef+"_"+fileDate+".pdf";
            File shareFile=new File(cacheDir,outputFileName);
            // Remove previous temporary registration-confirmation PDFs; retain only the current output.
            File[] oldCacheFiles=cacheDir.listFiles((dir,name)->
                (name.startsWith("GME_Registration_Confirmation_") || name.matches("GME-APP-[A-Za-z0-9_-]+_[0-9]{8}\\.pdf"))
                && !name.equals(shareFile.getName()));
            if(oldCacheFiles!=null)for(File oldFile:oldCacheFiles)oldFile.delete();
            try(FileOutputStream out=new FileOutputStream(shareFile)){doc.writeTo(out);}
            doc.close();
            // Clean up confirmation PDFs created by earlier versions that were stored persistently.
            File oldDir=new File(getExternalFilesDir(null),"Documents");
            File[] oldFiles=oldDir.listFiles((dir,name)->name.startsWith("GME_Registration_Confirmation_")&&name.endsWith(".pdf"));
            if(oldFiles!=null)for(File oldFile:oldFiles)oldFile.delete();
            toast("Registration confirmation generated. Choose how to share it.");
            share(shareFile);
        }catch(Exception e){toast("Could not generate registration confirmation: "+e.getMessage());}
    }
    void addStudentRecordSection(String heading){
        TextView label=new TextView(this);label.setText(heading.toUpperCase(Locale.ROOT));label.setTextSize(12);label.setTypeface(null,Typeface.BOLD);label.setTextColor(darkMode?Color.rgb(205,185,226):purple);label.setPadding(dp(2),dp(14),dp(2),dp(6));content.addView(label);
    }
    void addStudentRecordAction(String label,Runnable action){
        Button b=new Button(this);b.setText(professionalButtonLabel(label));b.setAllCaps(false);b.setTextSize(15);b.setTypeface(null,Typeface.BOLD);b.setTextColor(darkMode?Color.rgb(241,237,247):purpleDark);b.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);b.setPadding(dp(17),dp(13),dp(17),dp(13));b.setMinHeight(dp(58));b.setBackground(shape(darkMode?Color.rgb(43,39,50):Color.WHITE,darkMode?Color.rgb(91,78,105):Color.rgb(220,211,231)));b.setElevation(dp(1));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(7));content.addView(b,lp);b.setOnClickListener(v->action.run());
    }

    // GME Conditional Acceptance Letter: fill the supplied Word master template
    // without changing its page design, branding, tables, headers or footers.
    String gmeLetterSafe(String value){
        String v=(value==null?"Student":value).trim().replaceAll("[^A-Za-z0-9 _-]","").replaceAll("\\s+"," ");
        return v.isEmpty()?"Student":v;
    }
    String gmeXmlEscape(String value){
        if(value==null)return "";
        return value.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");
    }
    String gmeDate(String value)throws Exception{
        String v=value==null?"":value.trim();
        String[] formats={"dd/MM/yyyy","dd-MM-yyyy","yyyy-MM-dd"};
        for(String f:formats){try{SimpleDateFormat sdf=new SimpleDateFormat(f,Locale.US);sdf.setLenient(false);Date d=sdf.parse(v);return new SimpleDateFormat("dd/MM/yyyy",Locale.US).format(d);}catch(Exception ignored){}}
        throw new Exception("Enter a valid date using DD/MM/YYYY.");
    }
    String gmeMoney(String value)throws Exception{
        String v=(value==null?"":value).replace(",","").replace("$","").trim();
        double n=Double.parseDouble(v);
        if(n<0)throw new Exception("Programme fee cannot be negative.");
        return n==Math.floor(n)?String.format(Locale.US,"%,.0f",n):String.format(Locale.US,"%,.2f",n);
    }

    String gmeProgramFeeForName(String programme){
        String wanted=(programme==null?"":programme).toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]","");
        if(wanted.isEmpty())return "";
        JSONObject best=null;int bestScore=0;
        for(JSONObject item:programs){
            String candidate=item.optString("name","").toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]","");
            if(candidate.isEmpty())continue;
            int score=0;
            if(candidate.equals(wanted))score=10000;
            else if(candidate.contains(wanted)||wanted.contains(candidate))score=Math.min(candidate.length(),wanted.length())*10;
            if(score>bestScore){bestScore=score;best=item;}
        }
        if(best==null||bestScore<Math.min(80,wanted.length()*3))return "";
        String fee=best.optString("fee","");
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("([0-9][0-9,]*(?:\\\\.[0-9]+)?)").matcher(fee);
        return m.find()?m.group(1).replace(",",""):"";
    }
    void gmeAttachUppercase(EditText input){
        input.addTextChangedListener(new android.text.TextWatcher(){
            boolean changing=false;
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){}
            public void afterTextChanged(android.text.Editable e){
                if(changing)return;
                String value=e.toString();String upper=value.toUpperCase(Locale.ROOT);
                if(!value.equals(upper)){changing=true;int pos=input.getSelectionStart();input.setText(upper);input.setSelection(Math.min(Math.max(0,pos),upper.length()));changing=false;}
            }
        });
    }
    void gmeShowDatePicker(EditText target){
        Calendar c=Calendar.getInstance();
        try{c.setTime(new SimpleDateFormat("dd/MM/yyyy",Locale.US).parse(target.getText().toString()));}catch(Exception ignored){}
        DatePickerDialog picker=new DatePickerDialog(this,(view,y,m,d)->target.setText(String.format(Locale.US,"%02d/%02d/%04d",d,m+1,y)),c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH));
        picker.getDatePicker().setMaxDate(System.currentTimeMillis());
        picker.show();
    }
    String gmeProgramValue(JSONObject p,String... keys){
        if(p==null)return "";
        for(String k:keys){String v=p.optString(k,"").trim();if(!v.isEmpty()&&!v.equals("null"))return v;}
        return "";
    }
    String gmeAcademicLevel(String programme,JSONObject p){
        String level=gmeProgramValue(p,"level","academicLevel","academic_level","qualification","type");
        if(!level.isEmpty())return level.toUpperCase(Locale.ROOT);
        String v=programme==null?"":programme.toLowerCase(Locale.ROOT);
        if(v.contains("phd")||v.contains("doctor"))return "PHD";
        if(v.contains("master")||v.contains("mba")||v.contains("msc")||v.contains("m.tech"))return "MASTERS";
        if(v.contains("degree")||v.contains("bachelor")||v.contains("honours")||v.contains("bsc")||v.contains("bba"))return "UNDERGRADUATE";
        return "DIPLOMA";
    }
    File gmeLetterFolder(long sid){
        File f=new File(getFilesDir(),"gme_acceptance_letters/"+sid);
        if(!f.exists())f.mkdirs();
        return f;
    }
    JSONObject gmeLoadLetterData(long sid){
        File f=new File(gmeLetterFolder(sid),"letter_data.json");
        try(FileInputStream in=new FileInputStream(f);ByteArrayOutputStream b=new ByteArrayOutputStream()){
            byte[] buf=new byte[4096];int n;while((n=in.read(buf))>0)b.write(buf,0,n);
            return new JSONObject(new String(b.toByteArray(),"UTF-8"));
        }catch(Exception ignored){return new JSONObject();}
    }
    void gmeSaveLetterData(long sid,JSONObject data){
        try(FileOutputStream out=new FileOutputStream(new File(gmeLetterFolder(sid),"letter_data.json"))){
            out.write(data.toString(2).getBytes("UTF-8"));
        }catch(Exception e){toast("Letter details could not be saved on this device.");}
    }

    String gmeReplaceWordXml(String xml,HashMap<String,String> replacements)throws Exception{
        final String wordNs="http://schemas.openxmlformats.org/wordprocessingml/2006/main";
        javax.xml.parsers.DocumentBuilderFactory factory=javax.xml.parsers.DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        try{factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);}catch(Exception ignored){}
        org.w3c.dom.Document document=factory.newDocumentBuilder().parse(new org.xml.sax.InputSource(new java.io.StringReader(xml)));
        org.w3c.dom.NodeList paragraphs=document.getElementsByTagNameNS(wordNs,"p");
        java.util.regex.Pattern token=java.util.regex.Pattern.compile("\\{\\{([^{}]+)\\}\\}");
        for(int pi=0;pi<paragraphs.getLength();pi++){
            org.w3c.dom.Element paragraph=(org.w3c.dom.Element)paragraphs.item(pi);
            org.w3c.dom.NodeList textNodes=paragraph.getElementsByTagNameNS(wordNs,"t");
            if(textNodes.getLength()==0)continue;
            ArrayList<org.w3c.dom.Element> nodes=new ArrayList<>();
            StringBuilder full=new StringBuilder();
            for(int ni=0;ni<textNodes.getLength();ni++){
                org.w3c.dom.Element node=(org.w3c.dom.Element)textNodes.item(ni);
                nodes.add(node);full.append(node.getTextContent());
            }
            java.util.regex.Matcher matcher=token.matcher(full.toString());
            ArrayList<int[]> spans=new ArrayList<>();ArrayList<String> values=new ArrayList<>();
            while(matcher.find()){
                String replacement=replacements.get(matcher.group(1));
                if(replacement!=null){spans.add(new int[]{matcher.start(),matcher.end()});values.add(replacement);}
            }
            int[] starts=new int[nodes.size()+1];for(int ni=0;ni<nodes.size();ni++)starts[ni+1]=starts[ni]+nodes.get(ni).getTextContent().length();
            for(int mi=spans.size()-1;mi>=0;mi--){
                int start=spans.get(mi)[0],end=spans.get(mi)[1];
                int first=0,last=0;
                while(first+1<starts.length&&starts[first+1]<=start)first++;
                while(last+1<starts.length&&starts[last+1]<end)last++;
                int localStart=start-starts[first],localEnd=end-starts[last];
                String firstText=nodes.get(first).getTextContent();
                if(first==last){
                    nodes.get(first).setTextContent(firstText.substring(0,localStart)+values.get(mi)+firstText.substring(localEnd));
                }else{
                    nodes.get(first).setTextContent(firstText.substring(0,localStart)+values.get(mi));
                    for(int ni=first+1;ni<last;ni++)nodes.get(ni).setTextContent("");
                    String lastText=nodes.get(last).getTextContent();
                    nodes.get(last).setTextContent(lastText.substring(localEnd));
                }
            }
            for(org.w3c.dom.Element node:nodes){
                String value=node.getTextContent();
                if(value.startsWith(" ")||value.endsWith(" "))node.setAttributeNS("http://www.w3.org/XML/1998/namespace","xml:space","preserve");
            }
        }
        javax.xml.transform.Transformer transformer=javax.xml.transform.TransformerFactory.newInstance().newTransformer();
        transformer.setOutputProperty(javax.xml.transform.OutputKeys.ENCODING,"UTF-8");
        transformer.setOutputProperty(javax.xml.transform.OutputKeys.OMIT_XML_DECLARATION,"no");
        java.io.StringWriter writer=new java.io.StringWriter();
        transformer.transform(new javax.xml.transform.dom.DOMSource(document),new javax.xml.transform.stream.StreamResult(writer));
        return writer.toString();
    }
    void gmeGenerateAcceptanceDocx(File output,JSONObject values)throws Exception{
        InputStream raw=getAssets().open("gme_acceptance_template.docx");
        ZipInputStream zin=new ZipInputStream(new BufferedInputStream(raw));
        ZipOutputStream zout=new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(output)));
        HashMap<String,String> replacements=new HashMap<>();
        String letterDate=gmeDate(values.optString("DATE"));
        String dob=gmeDate(values.optString("DATE_OF_BIRTH"));
        double fee=Double.parseDouble(values.optString("PROGRAM_FEE").replace(",","").replace("$","").trim());
        replacements.put("DATE",letterDate);
        replacements.put("REFERENCE_ID",values.optString("REFERENCE_ID"));
        replacements.put("STUDENT_NAME",values.optString("STUDENT_NAME"));
        replacements.put("GUARDIAN_NAME",values.optString("GUARDIAN_NAME"));
        replacements.put("PASSPORT_NUMBER",values.optString("PASSPORT_NUMBER"));
        replacements.put("NATIONALITY",values.optString("NATIONALITY"));
        replacements.put("DATE_OF_BIRTH",dob);
        replacements.put("PROGRAM_APPLIED",values.optString("PROGRAM_APPLIED"));
        replacements.put("YEAR_INTAKE",values.optString("YEAR_INTAKE"));
        replacements.put("LEVEL_APPLIED",values.optString("LEVEL_APPLIED"));
        replacements.put("UNIVERSITY",values.optString("UNIVERSITY"));
        replacements.put("PROGRAM_DURATION",values.optString("PROGRAM_DURATION"));
        replacements.put("PROGRAM_FEE",gmeMoney(String.valueOf(fee)));
        replacements.put("40_PROGRAM_FEE",gmeMoney(String.valueOf(fee*.60)));
        replacements.put("50_PROGRAM_FEE",gmeMoney(String.valueOf(fee*.50)));
        replacements.put("60_PROGRAM_FEE",gmeMoney(String.valueOf(fee*.40)));
        SimpleDateFormat df=new SimpleDateFormat("dd/MM/yyyy",Locale.US);
        Date issued=new SimpleDateFormat("dd/MM/yyyy",Locale.US).parse(letterDate);
        Calendar cal=Calendar.getInstance();cal.setTime(issued);cal.add(Calendar.DAY_OF_YEAR,14);
        replacements.put("14_DAYS_DEADLINE",df.format(cal.getTime()));
        cal.setTime(issued);cal.add(Calendar.DAY_OF_YEAR,21);
        replacements.put("21_DAYS_DEADLINE",df.format(cal.getTime()));
        try{
            ZipEntry entry;
            byte[] buffer=new byte[8192];
            while((entry=zin.getNextEntry())!=null){
                ByteArrayOutputStream bytes=new ByteArrayOutputStream();int count;
                while((count=zin.read(buffer))>0)bytes.write(buffer,0,count);
                byte[] content=bytes.toByteArray();
                if(entry.getName().endsWith(".xml")){
                    String xml=new String(content,"UTF-8");
                    xml=gmeReplaceWordXml(xml,replacements);
                    content=xml.getBytes("UTF-8");
                }
                ZipEntry next=new ZipEntry(entry.getName());
                next.setTime(entry.getTime());
                zout.putNextEntry(next);zout.write(content);zout.closeEntry();zin.closeEntry();
            }
            zout.finish();
        }finally{try{zin.close();}catch(Exception ignored){}try{zout.close();}catch(Exception ignored){}}
    }

    String gmeHtmlEscape(String v){return v==null?"":v.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");}
    String gmeWordNodeHtml(org.w3c.dom.Node node,Map<String,String> images)throws Exception{
        if(node.getNodeType()==org.w3c.dom.Node.TEXT_NODE)return gmeHtmlEscape(node.getNodeValue());
        if(node.getNodeType()!=org.w3c.dom.Node.ELEMENT_NODE)return "";
        org.w3c.dom.Element e=(org.w3c.dom.Element)node;String n=e.getLocalName();StringBuilder inner=new StringBuilder();
        if("t".equals(n))return gmeHtmlEscape(e.getTextContent());
        if("tab".equals(n))return "&nbsp;&nbsp;&nbsp;";
        if("br".equals(n)){String type=e.getAttributeNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","type");return "page".equals(type)?"<div style='page-break-before:always'></div>":"<br/>";}
        if("lastRenderedPageBreak".equals(n))return "<div style='page-break-before:always'></div>";
        if("blip".equals(n)){
            String rid=e.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships","embed");
            String data=images.get(rid);return data==null?"":"<img src='"+data+"' style='max-width:100%;max-height:6.5in;object-fit:contain;'/>";
        }
        org.w3c.dom.NodeList children=node.getChildNodes();
        for(int i=0;i<children.getLength();i++)inner.append(gmeWordNodeHtml(children.item(i),images));
        if("p".equals(n)){
            String align="";org.w3c.dom.NodeList pp=e.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","jc");
            if(pp.getLength()>0){String a=((org.w3c.dom.Element)pp.item(0)).getAttributeNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","val");if("center".equals(a))align="text-align:center;";else if("right".equals(a))align="text-align:right;";else if("both".equals(a))align="text-align:justify;";}
            boolean sectionBreak=e.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","sectPr").getLength()>0;
            return "<p style='"+align+"'>"+inner+"</p>"+(sectionBreak?"<div style='page-break-after:always'></div>":"");
        }
        if("tbl".equals(n))return "<table>"+inner+"</table>";
        if("tr".equals(n))return "<tr>"+inner+"</tr>";
        if("tc".equals(n))return "<td>"+inner+"</td>";
        if("r".equals(n)){
            String style="";org.w3c.dom.NodeList bold=e.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","b");
            org.w3c.dom.NodeList italic=e.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","i");
            if(bold.getLength()>0)style+="font-weight:bold;";if(italic.getLength()>0)style+="font-style:italic;";
            org.w3c.dom.NodeList sizes=e.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","sz");
            if(sizes.getLength()>0){try{int half=Integer.parseInt(((org.w3c.dom.Element)sizes.item(0)).getAttributeNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","val"));style+="font-size:"+(half/2)+"pt;";}catch(Exception ignored){}}
            return style.isEmpty()?inner.toString():"<span style='"+style+"'>"+inner+"</span>";
        }
        return inner.toString();
    }
    String gmeDocxToHtml(File docx)throws Exception{
        ZipFile zip=new ZipFile(docx);try{
            HashMap<String,String> images=new HashMap<>();
            ZipEntry rel=zip.getEntry("word/_rels/document.xml.rels");
            if(rel!=null){
                org.w3c.dom.Document rd=javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(zip.getInputStream(rel));
                org.w3c.dom.NodeList rs=rd.getElementsByTagName("Relationship");
                for(int i=0;i<rs.getLength();i++){org.w3c.dom.Element re=(org.w3c.dom.Element)rs.item(i);String id=re.getAttribute("Id"),target=re.getAttribute("Target");
                    if(target.startsWith("/"))target=target.substring(1);else if(!target.startsWith("word/"))target="word/"+target;
                    ZipEntry im=zip.getEntry(target);if(im!=null&&target.startsWith("word/media/")){ByteArrayOutputStream b=new ByteArrayOutputStream();InputStream in=zip.getInputStream(im);byte[] buf=new byte[8192];int k;while((k=in.read(buf))>0)b.write(buf,0,k);in.close();String ext=target.toLowerCase(Locale.ROOT).endsWith(".jpg")||target.toLowerCase(Locale.ROOT).endsWith(".jpeg")?"image/jpeg":target.toLowerCase(Locale.ROOT).endsWith(".gif")?"image/gif":"image/png";images.put(id,"data:"+ext+";base64,"+Base64.encodeToString(b.toByteArray(),Base64.NO_WRAP));}
                }
            }
            ZipEntry de=zip.getEntry("word/document.xml");if(de==null)throw new Exception("The GME master template has no document body.");
            org.w3c.dom.Document doc=javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(zip.getInputStream(de));
            org.w3c.dom.NodeList bodies=doc.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","body");
            if(bodies.getLength()==0)throw new Exception("The GME master template is empty.");
            String body=gmeWordNodeHtml(bodies.item(0),images);
            return "<!doctype html><html><head><meta charset='utf-8'><style>@page{size:A4;margin:18mm 16mm 18mm 16mm}body{font-family:Arial,sans-serif;color:#111;font-size:10pt;line-height:1.25}p{margin:0 0 8pt 0;orphans:2;widows:2}table{border-collapse:collapse;width:100%;margin:5pt 0;table-layout:auto}td{vertical-align:top;padding:3pt 4pt;border:0}img{display:block;margin:3pt auto;max-width:100%}div{box-sizing:border-box} </style></head><body>"+body+"</body></html>";
        }finally{zip.close();}
    }
    interface GmePdfFailure{void onFailure(String message);}
    void gmeRenderHtmlPdf(String html,File pdf,Runnable success,GmePdfFailure failure){
        WebView web=new WebView(this);web.getSettings().setJavaScriptEnabled(false);
        web.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView view,String url){
            try{
                PrintDocumentAdapter adapter=view.createPrintDocumentAdapter("GME Acceptance Letter");
                PrintAttributes attrs=new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(new PrintAttributes.Resolution("gme","GlobalMinds",300,300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build();
                adapter.onLayout(null,attrs,new CancellationSignal(),new PrintDocumentAdapter.LayoutResultCallback(){
                    @Override public void onLayoutFinished(PrintDocumentInfo info,boolean changed){
                        try{ParcelFileDescriptor pfd=ParcelFileDescriptor.open(pdf,ParcelFileDescriptor.MODE_CREATE|ParcelFileDescriptor.MODE_TRUNCATE|ParcelFileDescriptor.MODE_READ_WRITE);
                            adapter.onWrite(new PageRange[]{PageRange.ALL_PAGES},pfd,new CancellationSignal(),new PrintDocumentAdapter.WriteResultCallback(){
                                @Override public void onWriteFinished(PageRange[] pages){try{pfd.close();}catch(Exception ignored){}view.destroy();success.run();}
                                @Override public void onWriteFailed(CharSequence error){try{pfd.close();}catch(Exception ignored){}view.destroy();failure.onFailure(String.valueOf(error));}
                            });
                        }catch(Exception e){view.destroy();failure.onFailure(e.getMessage());}
                    }
                    @Override public void onLayoutFailed(CharSequence error){view.destroy();failure.onFailure(String.valueOf(error));}
                });
            }catch(Exception e){view.destroy();failure.onFailure(e.getMessage());}
        }});
        web.loadDataWithBaseURL("file:///android_asset/",html,"text/html","UTF-8",null);
    }
    void gmeAcceptanceLetterOpen(JSONObject student){
        if(student==null){toast("Student record could not be found.");return;}
        final long sid=student.optLong("id");
        JSONObject fresh=studentDb.getStudent(sid);
        if(fresh==null){toast("Student record could not be found.");return;}
        JSONObject programme=new JSONObject();
        try{programme=new JSONObject(fresh.optString("program_json","{}"));}catch(Exception ignored){}
        JSONObject saved=gmeLoadLetterData(sid);
        String[] keys={"REFERENCE_ID","STUDENT_NAME","GUARDIAN_NAME","PASSPORT_NUMBER","NATIONALITY","DATE_OF_BIRTH","PROGRAM_APPLIED","YEAR_INTAKE","LEVEL_APPLIED","UNIVERSITY","PROGRAM_DURATION","PROGRAM_FEE"};
        String[] labels={"Reference ID","Student Name","Father / Guardian Name","Passport Number","Nationality","Date of Birth (DD/MM/YYYY)","Programme Applied","Year / Intake","Academic Level","University","Programme Duration","Standard Programme Fee (USD / semester)"};
        String catalogFee=gmeProgramFeeForName(fresh.optString("programme"));
        String[] defaults={fresh.optString("student_id"),fresh.optString("name"),"", "",fresh.optString("nationality"),"",fresh.optString("programme"),"2026/2027",gmeAcademicLevel(fresh.optString("programme"),programme),gmeProgramValue(programme,"university","universityName","institution"),gmeProgramValue(programme,"duration","programDuration","program_duration"),!catalogFee.isEmpty()?catalogFee:gmeProgramValue(programme,"fee","program_fee","tuitionFee","tuition_fee")};
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(18),dp(8),dp(18),dp(8));
        EditText[] inputs=new EditText[keys.length];
        for(int i=0;i<keys.length;i++){
            TextView label=new TextView(this);label.setText(labels[i]);label.setTextSize(12);label.setTypeface(null,Typeface.BOLD);label.setTextColor(darkMode?Color.LTGRAY:purpleDark);label.setPadding(0,dp(7),0,dp(3));form.addView(label);
            EditText input=new EditText(this);input.setSingleLine(true);input.setTextSize(15);input.setTextColor(darkMode?Color.WHITE:ink);input.setHint(labels[i]);
            String value=saved.optString(keys[i],defaults[i]);if(value==null||value.trim().isEmpty())value=defaults[i];
            if("PROGRAM_FEE".equals(keys[i])&&!defaults[i].trim().isEmpty())value=defaults[i];
            input.setText(value);gmeAttachUppercase(input);
            if("DATE_OF_BIRTH".equals(keys[i])){input.setFocusable(false);input.setClickable(true);input.setOnClickListener(v->gmeShowDatePicker(input));input.setCompoundDrawablesWithIntrinsicBounds(0,0,android.R.drawable.ic_menu_my_calendar,0);}
            if("PROGRAM_FEE".equals(keys[i])){String catalogFee=gmeProgramFeeForName(defaults[6]);if(!catalogFee.isEmpty()&&(saved.optString("PROGRAM_FEE","").trim().isEmpty()||saved.optString("PROGRAM_FEE").equals(defaults[i])))value=catalogFee;input.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);}
            input.setText(value);form.addView(input,new LinearLayout.LayoutParams(-1,dp(48)));inputs[i]=input;
        }
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.addView(form);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Generate GME Acceptance Letter").setView(scroll)
            .setNegativeButton("Cancel",null).setPositiveButton("Generate Letter",null).create();
        dialog.setOnShowListener(v->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(btn->{
            try{
                JSONObject values=new JSONObject();
                for(int i=0;i<keys.length;i++)values.put(keys[i],inputs[i].getText().toString().trim().toUpperCase(Locale.ROOT));
                if(values.optString("STUDENT_NAME").isEmpty())throw new Exception("Student name is required.");
                if(values.optString("PROGRAM_APPLIED").isEmpty())throw new Exception("Programme applied is required.");
                values.put("DATE",new SimpleDateFormat("dd/MM/yyyy",Locale.US).format(new Date()));
                values.put("DATE_OF_BIRTH",gmeDate(values.optString("DATE_OF_BIRTH")));
                values.put("PROGRAM_FEE",gmeMoney(values.optString("PROGRAM_FEE")));
                gmeSaveLetterData(sid,values);
                File folder=gmeLetterFolder(sid);
                File wordSource=new File(folder,"GME_Acceptance_Letter_"+gmeLetterSafe(values.optString("STUDENT_NAME"))+"_"+gmeLetterSafe(values.optString("REFERENCE_ID"))+".docx");
                File output=new File(getCacheDir(),"GME_Acceptance_Letter_"+gmeLetterSafe(values.optString("STUDENT_NAME"))+"_"+gmeLetterSafe(values.optString("REFERENCE_ID"))+".pdf");
                String archiveName="GME_ACCEPTANCE_LETTER_"+gmeLetterSafe(values.optString("STUDENT_NAME")).replace(" ","_")+"_"+gmeLetterSafe(values.optString("REFERENCE_ID")).replace(" ","_")+"_"+new SimpleDateFormat("yyyyMMdd_HHmmss_SSS",Locale.US).format(new Date())+".pdf";
                File storedPdf=new File(folder,archiveName);
                gmeGenerateAcceptanceDocx(wordSource,values);
                String html=gmeDocxToHtml(wordSource);
                dialog.dismiss();
                toast("Preparing the GME Acceptance Letter PDF...");
                gmeRenderHtmlPdf(html,output,()->{try(FileInputStream in=new FileInputStream(output);FileOutputStream out=new FileOutputStream(storedPdf)){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);wordSource.delete();toast("GME Acceptance Letter PDF generated and archived.");share(output);}catch(Exception saveError){wordSource.delete();toast("PDF was generated, but its archive copy could not be saved: "+saveError.getMessage());}},err->toast("Could not create the GME PDF: "+err));
            }catch(Exception e){toast(e.getMessage()==null?"Could not generate the GME Acceptance Letter.":e.getMessage());}
        }));
        dialog.show();
    }

    void gmeShowAcceptanceArchive(long sid){
        File folder=gmeLetterFolder(sid);File[] files=folder.listFiles((dir,name)->name.toLowerCase(Locale.ROOT).endsWith(".pdf"));
        if(files==null||files.length==0){toast("No saved GME Acceptance Letters for this student yet.");return;}
        java.util.Arrays.sort(files,(a,b)->Long.compare(b.lastModified(),a.lastModified()));
        String[] names=new String[files.length];for(int i=0;i<files.length;i++)names[i]=files[i].getName().replace('_',' ');
        new AlertDialog.Builder(this).setTitle("Saved GME Acceptance Letters").setItems(names,(d,which)->{
            File archived=files[which];File cached=new File(getCacheDir(),archived.getName());
            try(FileInputStream in=new FileInputStream(archived);FileOutputStream out=new FileOutputStream(cached)){
                byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);share(cached);
            }catch(Exception e){toast("Could not open the archived letter: "+e.getMessage());}
        }).setNegativeButton("Close",null).show();
    }

    void savedStudentDetails(JSONObject st){
        if(st==null){toast("Student record could not be found.");students();return;}
        base("Student Record");setRefreshAction(()->savedStudentDetails(studentDb.getStudent(st.optLong("id"))));pinStudentContext(st);
        String name=st.optString("name"),phone=st.optString("phone"),studentId=st.optString("student_id");long sid=st.optLong("id");
        addReferralStamp(content,st.optString("referred_by"));
        LinearLayout profileRow=new LinearLayout(this);profileRow.setOrientation(LinearLayout.HORIZONTAL);profileRow.setGravity(Gravity.CENTER_VERTICAL);profileRow.setPadding(dp(12),dp(12),dp(12),dp(12));profileRow.setBackground(shape(darkMode?Color.rgb(43,39,50):Color.WHITE,darkMode?Color.rgb(78,68,91):Color.rgb(232,225,239)));
        ImageView profilePic=new ImageView(this);profilePic.setScaleType(ImageView.ScaleType.CENTER_CROP);profilePic.setBackground(shape(accent,0));makeCircular(profilePic);String topPhoto=st.optString("photo_uri");try{if(!topPhoto.isEmpty())profilePic.setImageURI(Uri.parse(topPhoto));}catch(Exception ignored){}profileRow.addView(profilePic,new LinearLayout.LayoutParams(dp(82),dp(82)));
        LinearLayout profileWords=new LinearLayout(this);profileWords.setOrientation(LinearLayout.VERTICAL);profileWords.setPadding(dp(12),0,0,0);
        TextView profileName=new TextView(this);profileName.setText(name);profileName.setTextSize(17);profileName.setTypeface(null,Typeface.BOLD);profileName.setTextColor(darkMode?Color.rgb(241,237,247):purpleDark);profileWords.addView(profileName);
        TextView profileId=new TextView(this);profileId.setText(studentId);profileId.setTextSize(12);profileId.setTextColor(darkMode?Color.rgb(205,185,226):purple);profileWords.addView(profileId);
        TextView profileStage=new TextView(this);profileStage.setText(st.optString("stage","Enquiry received"));profileStage.setTextSize(12);profileStage.setTextColor(darkMode?Color.LTGRAY:Color.DKGRAY);profileWords.addView(profileStage);profileRow.addView(profileWords,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams profileLp=new LinearLayout.LayoutParams(-1,-2);profileLp.setMargins(0,dp(4),0,dp(10));content.addView(profileRow,profileLp);
        addText("Student name",13,Color.GRAY);addText(name,19,Color.DKGRAY);addText("Student ID: "+studentId,15,purple);addText("Record generated: "+dateText(st.optLong("created_at")),14,Color.GRAY);addText("Phone / WhatsApp: "+(phone.isEmpty()?"Not provided":phone),14,Color.DKGRAY);addText("City / Town: "+(st.optString("city").isEmpty()?"Not recorded":st.optString("city")),14,Color.DKGRAY);addText("Province / Region: "+(st.optString("province").isEmpty()?"Not recorded":st.optString("province")),14,Color.DKGRAY);addText("Nationality: "+(st.optString("nationality").isEmpty()?"Not recorded":st.optString("nationality")),14,Color.DKGRAY);addText("Gender: "+(st.optString("gender").isEmpty()?"Not recorded":st.optString("gender")),14,Color.DKGRAY);addText("Programme: "+st.optString("programme"),16,purple);addText("Current journey stage: "+st.optString("stage","Enquiry received"),15,Color.DKGRAY);if(!"ACTIVE".equals(st.optString("record_status","ACTIVE")))addText("RECORD STATUS: "+st.optString("record_status"),14,Color.rgb(160,70,30));

        // Document actions are intentionally grouped and ordered for quick access.
        addStudentRecordSection("Document Generation");
        addStudentRecordAction("Application Registration Confirmation",()->generateApplicationRegistrationConfirmation(studentDb.getStudent(sid)));
        addStudentRecordAction("Programme Guidance Report",()->{try{JSONObject fresh=studentDb.getStudent(sid);JSONObject p=new JSONObject(fresh.optString("program_json","{}"));if(!p.has("name")){String target=fresh.optString("programme");for(JSONObject candidate:programs){if(!target.isEmpty()&&candidate.optString("name").equalsIgnoreCase(target)){p=candidate;break;}}}if(!p.has("name")){toast("Please assign a programme before generating Programme Guidance.");return;}documentScreen(fresh.optString("name"),fresh.optString("phone"),fresh.optString("student_id"),"",p);}catch(Exception e){toast("Could not open this programme record.");}});
        addStudentRecordAction("Generate GME Acceptance Letter",()->gmeAcceptanceLetterOpen(studentDb.getStudent(sid)));
        addStudentRecordAction("View Saved GME Acceptance Letters",()->gmeShowAcceptanceArchive(sid));
        addStudentRecordAction("Certificate / Recognition",()->studentCertificateChoices(studentDb.getStudent(sid)));
        addStudentRecordAction("Generate LPU Application Form",()->lpuOpen(studentDb.getStudent(sid)));
        addStudentRecordAction("Visa Undertaking",()->visaUndertakingForm(studentDb.getStudent(sid)));

        // Existing record-editing actions are grouped separately, without adding or removing capabilities.
        addStudentRecordSection("Student Record Editing");
        addStudentRecordAction("Edit Student City / Province",()->editStudentArea(studentDb.getStudent(sid)));
        addStudentRecordAction("Edit Student Nationality",()->{JSONObject fresh=studentDb.getStudent(sid);EditText nat=field("Nationality");nat.setText(fresh.optString("nationality"));new AlertDialog.Builder(this).setTitle("Update nationality").setView(nat).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{studentDb.updateNationality(sid,nat.getText().toString().trim());savedStudentDetails(studentDb.getStudent(sid));}).show();});
        String photoUri=st.optString("photo_uri");
        addStudentRecordAction(photoUri.isEmpty()?"Add Student Photograph":"Change Student Photograph",()->{selectedPhotoStudentId=sid;Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);pick.addCategory(Intent.CATEGORY_OPENABLE);pick.setType("image/*");startActivityForResult(pick,7412);});
        addStudentRecordAction("Set / Update Referral Source",()->chooseStudentReferrer(studentDb.getStudent(sid)));
        addStudentRecordAction("Assign / Change Programme",()->programPicker(p->{studentDb.updateProgramme(sid,p);toast("Programme updated");savedStudentDetails(studentDb.getStudent(sid));}));

        addStudentRecordSection("Student Journey & Management");
        addStudentRecordAction("Update Journey Stage / View History",()->studentJourneyDetails(studentDb.getStudent(sid)));
        addStudentRecordAction("Manage Student Finance",()->studentFinance(studentDb.getStudent(sid)));
        addStudentRecordAction("Student Status: Archive / Withdraw / Delete",()->studentLifecycleActions(studentDb.getStudent(sid)));
        addStudentRecordAction("View Student Activity & Audit History",()->showStudentAudit(sid));
        Button back=btn("← Back to student search");content.addView(back);back.setOnClickListener(v->students());
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==LPU_PICK_PHOTO&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&lpuStudentId>0){Uri u=data.getData();try{File dest=new File(lpuFolder(lpuStudentId),"applicant_photo"+lpuExtension(u));try(InputStream in=getContentResolver().openInputStream(u);FileOutputStream o=new FileOutputStream(dest)){byte[] b=new byte[16384];int n;while((n=in.read(b))>0)o.write(b,0,n);}lpuPhotoUri=Uri.fromFile(dest);if(lpuPhotoPreview!=null)lpuPhotoPreview.setImageURI(lpuPhotoUri);JSONObject ix=lpuLoadIndex(lpuStudentId);ix.put("photo_path",dest.getAbsolutePath());lpuSaveIndex(lpuStudentId,ix);toast("Applicant photograph saved.");}catch(Exception e){toast("Could not save photograph.");}return;}if(requestCode>=LPU_PICK_BASE&&requestCode<LPU_PICK_BASE+lpuDocTypes.length&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&lpuStudentId>0){try{lpuStoreDocument(data.getData(),lpuDocTypes[requestCode-LPU_PICK_BASE]);toast(lpuPendingType+" uploaded.");lpuOpen(studentDb.getStudent(lpuStudentId));}catch(Exception e){toast("Could not upload document: "+e.getMessage());}return;}if((requestCode==7413||requestCode==7414)&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){Uri u=data.getData();try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}String key=requestCode==7413?"signature_uri":"stamp_uri";try{String processedUri=removeLightBackgroundAndSave(u,key);if(processedUri==null||processedUri.isEmpty())throw new IOException("Could not process image");getSharedPreferences("gme_document_branding",MODE_PRIVATE).edit().putString(key,processedUri).apply();toast(requestCode==7413?"Signature saved with background removed":"Company stamp saved with background removed");}catch(Exception ex){getSharedPreferences("gme_document_branding",MODE_PRIVATE).edit().putString(key,u.toString()).apply();toast("Image saved, but background removal failed. Use a clear, light-background image for best results.");}documentBrandingSettings();return;}if(requestCode==7415&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){Uri u=data.getData();try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}pendingRegistrationPhotoUri=u.toString();if(registrationPhotoButton!=null)registrationPhotoButton.setText("✓ Student Photograph Selected (optional)");toast("Student photograph selected");return;}if(requestCode==7412&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&selectedPhotoStudentId>0){Uri u=data.getData();try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}studentDb.updateStudentPhoto(selectedPhotoStudentId,u.toString());JSONObject fresh=studentDb.getStudent(selectedPhotoStudentId);selectedPhotoStudentId=-1;savedStudentDetails(fresh);toast("Student photograph saved to profile");return;}}
    void chooseStudentReferrer(JSONObject st){ArrayList<JSONObject> refs=studentDb.allReferees();ArrayList<String> labels=new ArrayList<>();for(JSONObject r:refs)labels.add(r.optString("name")+" • "+r.optString("category"));labels.add("＋ Add a new referee profile");new AlertDialog.Builder(this).setTitle("Referral source").setItems(labels.toArray(new String[0]),(d,w)->{if(w==refs.size()){addRefereeDialog(st);return;}studentDb.updateStudentReferrer(st.optLong("id"),refs.get(w).optString("name"));toast("Referral source updated");savedStudentDetails(studentDb.getStudent(st.optLong("id")));}).setNeutralButton("Clear source",(d,w)->{studentDb.updateStudentReferrer(st.optLong("id"),"");savedStudentDetails(studentDb.getStudent(st.optLong("id")));}).setNegativeButton("Cancel",null).show();}
    void addRefereeDialog(JSONObject linkedStudent){LinearLayout f=new LinearLayout(this);f.setPadding(20,8,20,8);f.setOrientation(LinearLayout.VERTICAL);EditText name=field("Referee full name *"),phone=field("Contact number"),pid=field("Student ID / Staff ID / National ID");Spinner gender=new Spinner(this);gender.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Not provided","Female","Male","Other","Prefer not to say"}));Spinner category=new Spinner(this);category.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Student","Staff","Alumni","Business partner","Other"}));f.addView(name);f.addView(phone);f.addView(pid);f.addView(gender);f.addView(category);new AlertDialog.Builder(this).setTitle("Create referee profile").setView(f).setNegativeButton("Cancel",null).setPositiveButton("Save profile",(d,w)->{if(name.getText().toString().trim().isEmpty()){toast("Referee name is required");return;}studentDb.addReferee(name.getText().toString(),phone.getText().toString(),pid.getText().toString(),gender.getSelectedItem()==null?"Not provided":gender.getSelectedItem().toString(),category.getSelectedItem().toString());if(linkedStudent!=null&&linkedStudent.optLong("id")>0){studentDb.updateStudentReferrer(linkedStudent.optLong("id"),name.getText().toString().trim());savedStudentDetails(studentDb.getStudent(linkedStudent.optLong("id")));}else referralsHub();toast("Referee profile saved");}).show();}
    void certificatesHub(){base("Certificates & Recognition");addText("Generate personalised, dated certificates for student milestones, event participation, enrolment and other approved achievements.",14,Color.GRAY);featureCard("🎓","Certificate of Enrolment","Confirm a student's recorded enrolment with Global Minds Education",()->pickCertificateStudent("Certificate of Enrolment"));featureCard("🌟","Event Participation","Recognise a participant after an event",()->pickCertificateStudent("Certificate of Participation"));featureCard("🏅","Custom Achievement","Create a certificate for another approved achievement",()->pickCertificateStudent("Certificate of Achievement"));featureCard("✍️","Custom Certificate","Choose the certificate title and citation for a student or contributor",()->customCertificate());featureCard("🏆","Monthly Referee Competency","Recognise the top referral contributor for this month",()->monthlyRefereeAward());Button back=btn("← Home");content.addView(back);back.setOnClickListener(v->dashboard());}
    void pickCertificateStudent(String type){if(type.equals("Certificate of Participation")){pickParticipationCertificate();return;}ArrayList<JSONObject> all=studentDb.search("");if(all.isEmpty()){toast("Register a student first");return;}String[] labels=new String[all.size()];for(int i=0;i<all.size();i++)labels[i]=all.get(i).optString("name")+" • "+all.get(i).optString("student_id");new AlertDialog.Builder(this).setTitle("Choose certificate recipient").setItems(labels,(d,w)->{JSONObject st=all.get(w);String detail=type.equals("Certificate of Enrolment")?"This certificate recognises the student's recorded association with Global Minds Education.\nJourney stage: "+st.optString("stage"):"In recognition of a recorded achievement and contribution.";generateCertificate(st,type,detail);}).setNegativeButton("Cancel",null).show();}
    void customCertificate(){ArrayList<JSONObject> people=studentDb.search("");ArrayList<JSONObject> refs=studentDb.allReferees();ArrayList<JSONObject> recipients=new ArrayList<>(people);for(JSONObject r:refs){JSONObject copy=new JSONObject();try{copy.put("id",r.optLong("id"));copy.put("name",r.optString("name"));copy.put("student_id",r.optString("personal_id","GME-CONTRIBUTOR"));}catch(Exception ignored){}recipients.add(copy);}if(recipients.isEmpty()){toast("Add a student or referee profile first");return;}String[] labels=new String[recipients.size()];for(int i=0;i<recipients.size();i++)labels[i]=recipients.get(i).optString("name")+" • "+recipients.get(i).optString("student_id","Contributor");new AlertDialog.Builder(this).setTitle("Choose recipient").setItems(labels,(d,w)->{JSONObject person=recipients.get(w);LinearLayout f=new LinearLayout(this);f.setPadding(20,8,20,8);f.setOrientation(LinearLayout.VERTICAL);EditText title=field("Certificate title (e.g. Excellence, Completion)");EditText citation=multiField("Citation / reason for recognition");f.addView(title);f.addView(citation);new AlertDialog.Builder(this).setTitle("Custom certificate details").setView(f).setNegativeButton("Cancel",null).setPositiveButton("Generate PDF",(dd,ww)->{String t=title.getText().toString().trim(),c=citation.getText().toString().trim();if(t.isEmpty()){toast("Enter a certificate title");return;}if(c.isEmpty())c="In recognition of contribution to the Global Minds Education community.";generateCertificate(person,t,c);}).show();}).setNegativeButton("Cancel",null).show();}
    void pickParticipationCertificate(){ArrayList<JSONObject> events=studentDb.allEvents();if(events.isEmpty()){toast("Create an event first");return;}String[] evLabels=new String[events.size()];for(int j=0;j<events.size();j++)evLabels[j]=events.get(j).optString("title")+" • "+eventDateTime(events.get(j).optLong("start_at"));new AlertDialog.Builder(this).setTitle("Choose event").setItems(evLabels,(d,w)->{JSONObject ev=events.get(w);ArrayList<JSONObject> attended=new ArrayList<>();for(JSONObject person:studentDb.eventPeople(ev.optLong("id")))if(person.optString("status").equals("Attended"))attended.add(person);if(attended.isEmpty()){toast("No attendees are marked Attended for this event. Update attendance in Events first.");return;}String[] peopleLabels=new String[attended.size()];for(int i=0;i<attended.size();i++)peopleLabels[i]=attended.get(i).optString("name")+" • "+attended.get(i).optString("personal_id","No ID");new AlertDialog.Builder(this).setTitle("Choose verified attendee").setItems(peopleLabels,(dd,ww)->{JSONObject person=attended.get(ww);JSONObject recipient=new JSONObject();try{recipient.put("name",person.optString("name"));recipient.put("student_id",person.optString("personal_id","EVENT-GUEST"));}catch(Exception ignored){}generateCertificate(recipient,"Certificate of Participation","In recognition of participation in the Global Minds Education event.\nEvent: "+ev.optString("title")+"\nDate: "+eventDateTime(ev.optLong("start_at")));}).setNegativeButton("Cancel",null).show();}).setNegativeButton("Cancel",null).show();}
    void studentCertificateChoices(JSONObject st){String[] types={"Certificate of Enrolment","Certificate of Participation","Certificate of Achievement"};new AlertDialog.Builder(this).setTitle("Generate certificate for "+st.optString("name")).setItems(types,(d,w)->{if(w==1){pickCertificateStudent(types[w]);}else generateCertificate(st,types[w],w==0?"This certificate recognises the student's recorded association with Global Minds Education.\nJourney stage: "+st.optString("stage"):"In recognition of a recorded achievement and contribution.");}).show();}
    void generateCertificate(JSONObject recipient,String type,String detail){try{PdfDocument doc=new PdfDocument();PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(842,595,1).create());Canvas c=page.getCanvas();c.drawColor(Color.WHITE);Paint p=new Paint(3);p.setColor(purple);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5);c.drawRoundRect(22,22,820,573,20,20,p);p.setStrokeWidth(1.5f);c.drawRoundRect(34,34,808,561,16,16,p);p.setStyle(Paint.Style.FILL);p.setColor(purple);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.create("serif",Typeface.BOLD));p.setTextSize(23);c.drawText("GLOBAL MINDS EDUCATION",421,82,p);p.setColor(Color.rgb(155,117,45));p.setTextSize(13);c.drawText("TRANSFORMING EDUCATION • EMPOWERING FUTURES",421,108,p);
            p.setColor(ink);p.setTextSize(30);c.drawText(type.toUpperCase(Locale.ROOT),421,178,p);p.setTextSize(15);p.setTypeface(Typeface.create("serif",Typeface.ITALIC));c.drawText("This certificate is proudly presented to",421,218,p);p.setColor(purpleDark);p.setTypeface(Typeface.create("serif",Typeface.BOLD));p.setTextSize(28);c.drawText(recipient.optString("name"),421,268,p);p.setColor(ink);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setTextSize(13);int yy=306;for(String line:wrapText(detail.replace("\n"," "),78)){c.drawText(line,421,yy,p);yy+=18;}p.setTextSize(11);c.drawText("Record ID: "+recipient.optString("student_id","GME"),421,yy+8,p);c.drawText("Issued: "+dateText(System.currentTimeMillis()),421,yy+26,p);
            p.setTextAlign(Paint.Align.LEFT);p.setColor(Color.LTGRAY);c.drawLine(58,470,292,470,p);c.drawLine(548,470,782,470,p);p.setColor(purpleDark);p.setTextSize(9);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));c.drawText("OFFICE AUTHORISATION",58,420,p);c.drawText("COMPANY STAMP",548,420,p);drawBrandingImage(c,"signature_uri",58,414,330,476);drawBrandingImage(c,"stamp_uri",555,408,800,480);p.setColor(ink);p.setTextSize(10);c.drawText("Authorised Representative",100,488,p);c.drawText("Global Minds Education",625,488,p);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(10);p.setColor(Color.GRAY);c.drawText("Be the Next Global Mind!",421,535,p);p.setTextAlign(Paint.Align.LEFT);doc.finishPage(page);File f=new File(getCacheDir(),safe(recipient.optString("student_id"))+"_"+safe(type)+".pdf");FileOutputStream out=new FileOutputStream(f);doc.writeTo(out);out.close();doc.close();share(f);}catch(Exception e){toast("Could not generate certificate: "+e.getMessage());}}
    void referralsHub(){base("Referrals & Referee Profiles");setRefreshAction(()->referralsHub());ArrayList<JSONObject> month=studentDb.referralRankings(true),all=studentDb.referralRankings(false);addText("Track every student referral, view each referee's profile and celebrate contributions based on recorded student registrations.",14,Color.GRAY);int monthTotal=0;for(JSONObject r:month)monthTotal+=r.optInt("total");addText("This month's referred students: "+monthTotal,18,purple);if(!month.isEmpty()){JSONObject leader=month.get(0);LinearLayout hero=new LinearLayout(this);hero.setOrientation(LinearLayout.VERTICAL);hero.setPadding(dp(16),dp(16),dp(16),dp(16));hero.setBackground(shape(Color.WHITE,Color.rgb(226,201,139)));TextView crown=new TextView(this);crown.setText("🏆 MONTHLY REFERRAL LEADER");crown.setTextSize(13);crown.setTextColor(purple);crown.setTypeface(null,1);hero.addView(crown);TextView nm=new TextView(this);nm.setText("✨ "+leader.optString("name"));nm.setTextSize(22);nm.setTextColor(ink);nm.setTypeface(null,1);hero.addView(nm);TextView score=new TextView(this);score.setText(leader.optInt("total")+" referred students • "+leader.optInt("admitted")+" admissions");score.setTextSize(13);score.setTextColor(ink);hero.addView(score);content.addView(hero);Button award=btn("Generate Monthly Referee Competency Certificate");content.addView(award);award.setOnClickListener(v->monthlyRefereeAward());chartCard("Monthly referral leaderboard",new DataChart(DataChart.BAR,rankingLabels(month),rankingCounts(month)));}else addText("No referral activity recorded this month yet. Add referral sources to student records to start the leaderboard.",14,Color.GRAY);Button add=btn("＋ Create Referee Profile");content.addView(add);add.setOnClickListener(v->addRefereeDialog(null));addText("Referee Profiles",18,purple);for(JSONObject r:studentDb.allReferees()){int count=studentDb.referralCount(r.optString("name"));Button b=btn(r.optString("name")+" • "+r.optString("category")+"\n"+r.optString("phone","No contact")+" • "+count+" referred students");b.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);content.addView(b);b.setOnClickListener(v->refereeProfile(r));}addText("Referral leaderboard • All time",18,purple);chartCard("Students referred by each person",new DataChart(DataChart.BAR,rankingLabels(all),rankingCounts(all)));for(JSONObject r:all){Button b=btn(r.optString("name")+" • "+r.optInt("total")+" students • "+r.optInt("admitted")+" admissions");b.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);content.addView(b);b.setOnClickListener(v->refereeProfile(r));}Button back=btn("← Home");content.addView(back);back.setOnClickListener(v->dashboard());}
    String[] rankingLabels(ArrayList<JSONObject> a){int n=Math.min(8,a.size());String[] x=new String[n];for(int i=0;i<n;i++)x[i]=a.get(i).optString("name");return x;}int[] rankingCounts(ArrayList<JSONObject> a){int n=Math.min(8,a.size());int[] x=new int[n];for(int i=0;i<n;i++)x[i]=a.get(i).optInt("total");return x;}
    void refereeProfile(JSONObject r){String name=r.optString("name");ArrayList<JSONObject> people=studentDb.studentsByReferee(name);base("Referee Profile");addText(name,22,purple);addText("Category: "+r.optString("category"),14,Color.DKGRAY);addText("Contact: "+r.optString("phone","Not recorded"),14,Color.DKGRAY);addText("Identity / Staff / Student ID: "+r.optString("personal_id","Not recorded"),14,Color.DKGRAY);addText("Total referrals: "+people.size(),18,purple);int admitted=0;for(JSONObject st:people){String stage=st.optString("stage");if(stage.contains("Admission")||stage.contains("Visa")||stage.contains("Arrived")||stage.contains("University Reported"))admitted++;addReferralStamp(content,st.optString("referred_by"));addStudentListRow(content,st,st.optString("name")+" • "+st.optString("student_id")+"\n"+st.optString("stage")+"\nNationality: "+(st.optString("nationality").isEmpty()?"Not recorded":st.optString("nationality")));}addText("Recorded admission-or-later outcomes: "+admitted,14,Color.DKGRAY);final int admittedCount=admitted;Button cert=btn("Generate Referee Competency Certificate");content.addView(cert);cert.setOnClickListener(v->generateCertificate(r,"Referee Competency Certificate","In recognition of contribution to student referrals and Global Minds Education's education access mission.\nTotal recorded referrals: "+people.size()+"\nRecorded admission-or-later outcomes: "+admittedCount));Button back=btn("← Referrals");content.addView(back);back.setOnClickListener(v->referralsHub());}
    void monthlyRefereeAward(){ArrayList<JSONObject> month=studentDb.referralRankings(true);if(month.isEmpty()){toast("No referrals recorded this month yet");return;}JSONObject leader=month.get(0);new AlertDialog.Builder(this).setTitle("Monthly Referee Award").setMessage("Award the certificate to "+leader.optString("name")+" for "+leader.optInt("total")+" student referrals this month? Rankings use student record creation dates and recorded referral sources.").setNegativeButton("Cancel",null).setPositiveButton("Generate Certificate",(d,w)->{celebrationMoment(leader.optString("name"),leader.optInt("total"));generateCertificate(leader,"Referee Competency Certificate","Recognised as Global Minds Education's monthly referral leader for "+new SimpleDateFormat("MMMM yyyy",Locale.ENGLISH).format(new Date())+".\nRecorded student referrals this month: "+leader.optInt("total")+"\nRecorded admission-or-later outcomes: "+leader.optInt("admitted"));toast("Monthly recognition certificate prepared");}).show();}
    void celebrationMoment(String name,int count){TextView message=new TextView(this);message.setText("🎉 ✨ 🏆 ✨ 🎉\n\nCONGRATULATIONS!\n"+name+"\n\nMonthly referral leader\n"+count+" recorded referrals\n\n🌟 Be the Next Global Mind! 🌟");message.setTextSize(19);message.setTextColor(purpleDark);message.setGravity(Gravity.CENTER);message.setPadding(dp(18),dp(24),dp(18),dp(24));message.setBackground(shape(Color.rgb(255,250,232),Color.rgb(226,201,139)));new AlertDialog.Builder(this).setView(message).setPositiveButton("Celebrate",(d,w)->{}).show();}
    void newsHub(){base("News & Achievements");setRefreshAction(()->newsHub());addText("Live activity feed from records stored on this device. Refreshes whenever you open this section; no external news or cross-device sync is implied.",13,Color.GRAY);ArrayList<JSONObject> month=studentDb.referralRankings(true);if(!month.isEmpty()){JSONObject top=month.get(0);addText("🏆 MONTHLY REFERRAL SPOTLIGHT",13,purple);addText("✨ "+top.optString("name")+" has the highest recorded referrals this month: "+top.optInt("total")+" students.",17,ink);Button b=btn("Celebrate this referee");content.addView(b);b.setOnClickListener(v->monthlyRefereeAward());}ArrayList<JSONObject> recent=studentDb.search("");addText("📣 Recent student registrations",17,purple);int n=0;for(JSONObject st:recent){if(n++>=12)break;addText("🟣 "+st.optString("name")+" joined the database • "+dateTime(st.optLong("created_at"))+" • "+st.optString("stage"),13,Color.DKGRAY);}if(recent.isEmpty())addText("No activity recorded yet.",14,Color.GRAY);addText("🌟 Recognition ideas",17,purple);addText("• Issue enrolment certificates when the relevant status is verified.\n• Issue event participation certificates after attendance is confirmed.\n• Review the monthly referral leaderboard and celebrate its leader.",14,Color.DKGRAY);Button refresh=btn("↻ Refresh Activity Feed");content.addView(refresh);refresh.setOnClickListener(v->newsHub());Button back=btn("← Home");content.addView(back);back.setOnClickListener(v->dashboard());}
    String areaLabel(JSONObject st){String city=st.optString("city").trim(),province=st.optString("province").trim();if(city.isEmpty())city="City not recorded";if(province.isEmpty())province="Province not recorded";return city+", "+province;}
    void editStudentArea(JSONObject st){LinearLayout form=new LinearLayout(this);form.setPadding(24,8,24,8);form.setOrientation(LinearLayout.VERTICAL);EditText city=field("City / Town");city.setText(st.optString("city"));EditText province=field("Province / Region / State");province.setText(st.optString("province"));form.addView(city);form.addView(province);new AlertDialog.Builder(this).setTitle("Student location").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{studentDb.updateLocation(st.optLong("id"),city.getText().toString().trim(),province.getText().toString().trim());toast("Student location saved");savedStudentDetails(studentDb.getStudent(st.optLong("id")));}).show();}
    boolean sameAreaValue(String studentValue,String reportValue){String a=studentValue==null?"":studentValue.trim(),b=reportValue==null?"":reportValue.trim();if(b.equalsIgnoreCase("Not recorded"))return a.isEmpty();return a.equalsIgnoreCase(b);}
    void areaIntelligence(){
        base("Student Area Intelligence");
        setRefreshAction(()->areaIntelligence());
        addText("Analyse where enquiries and admissions originate. Counts update from student records saved on this device. Admission means the student is at Admission Confirmed or a later recorded milestone.",14,Color.GRAY);
        ArrayList<JSONObject> rows=studentDb.areaRows();
        int total=studentDb.countAll(),admitted=0,missing=0;
        for(JSONObject r:rows){
            admitted+=r.optInt("admitted");
            if("Not recorded".equals(r.optString("city"))||"Not recorded".equals(r.optString("province")))missing+=r.optInt("total");
        }
        addText("Total student records: "+total,17,purple);
        addText("Students at admission-or-later stages: "+admitted,15,Color.DKGRAY);
        addText("Records with a missing city or province: "+missing,14,Color.DKGRAY);
        chartCard("Location data completeness",new DataChart(DataChart.PIE,new String[]{"Location recorded","Missing location"},new int[]{Math.max(0,total-missing),missing}));
        ArrayList<JSONObject> provinces=studentDb.areaSummary(true);
        String[] provinceLabels=new String[Math.min(8,provinces.size())];
        int[] provinceTotals=new int[provinceLabels.length],provinceAdmissions=new int[provinceLabels.length];
        for(int i=0;i<provinceLabels.length;i++){provinceLabels[i]=provinces.get(i).optString("area");provinceTotals[i]=provinces.get(i).optInt("total");provinceAdmissions[i]=provinces.get(i).optInt("admitted");}
        addGap();addText("Students by Province / Region",18,purple);
        chartCard("Top provinces by student count",new DataChart(DataChart.BAR,provinceLabels,provinceTotals));
        chartCard("Admissions by province / region",new DataChart(DataChart.BAR,provinceLabels,provinceAdmissions));
        chartCard("Share of students by province / region",new DataChart(DataChart.PIE,provinceLabels,provinceTotals));
        ArrayList<JSONObject> cities=studentDb.areaSummary(false);
        String[] cityLabels=new String[Math.min(8,cities.size())];
        int[] cityTotals=new int[cityLabels.length],cityAdmissions=new int[cityLabels.length];
        for(int i=0;i<cityLabels.length;i++){cityLabels[i]=cities.get(i).optString("area");cityTotals[i]=cities.get(i).optInt("total");cityAdmissions[i]=cities.get(i).optInt("admitted");}
        addGap();addText("Students by City / Town",18,purple);
        chartCard("Top cities by student count",new DataChart(DataChart.BAR,cityLabels,cityTotals));
        chartCard("Admissions by city / town",new DataChart(DataChart.BAR,cityLabels,cityAdmissions));
        addGap();addText("Detailed City / Province Records",18,purple);
        if(rows.isEmpty())addText("No student records available yet.",14,Color.GRAY);
        for(JSONObject area:rows){
            int n=area.optInt("total"),a=area.optInt("admitted");
            double rate=n==0?0:(100.0*a/n);
            Button areaButton=btn(area.optString("city")+", "+area.optString("province")+"\nStudents: "+n+" • Admissions: "+a+" • Admission rate: "+String.format(Locale.US,"%.1f%%",rate));
            areaButton.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);
            content.addView(areaButton);
            areaButton.setOnClickListener(v->{
                base("Area Student Records");
                JSONObject selectedArea=area;
                String areaTitle=selectedArea.optString("city")+", "+selectedArea.optString("province");
                addText(areaTitle,18,purple);
                ArrayList<JSONObject> areaStudents=new ArrayList<>();
                for(JSONObject student:studentDb.search("")){
                    if(sameAreaValue(student.optString("city"),selectedArea.optString("city"))&&sameAreaValue(student.optString("province"),selectedArea.optString("province")))areaStudents.add(student);
                }
                addText(areaStudents.size()+" student record"+(areaStudents.size()==1?"":"s"),13,Color.GRAY);
                for(JSONObject student:areaStudents){
                    String phone=student.optString("phone");
                    String details=student.optString("name")+"\nStudent ID: "+student.optString("student_id")+"\n"+student.optString("programme")+" • "+student.optString("stage","Enquiry received")+"\nArea: "+areaLabel(student)+"\nNationality: "+(student.optString("nationality").isEmpty()?"Not recorded":student.optString("nationality"))+"\nReferred by: "+(student.optString("referred_by").isEmpty()?"Not recorded":student.optString("referred_by"))+(phone.isEmpty()?"":"\n"+phone);
                    // Reuse the Search Student row renderer so profile photos and row styling match exactly.
                    addStudentListRow(content,student,details);
                }
                Button backToArea=btn("← Area Intelligence");
                content.addView(backToArea);
                backToArea.setOnClickListener(vv->areaIntelligence());
            });
        }
        addGap();
        addText("Data quality: records with missing locations are grouped as 'Not recorded'. Admission rates are calculated as admitted-or-later records divided by all records in that exact area; they are descriptive and do not prove location causes admission outcomes. Complete city and province fields to improve comparisons.",12,Color.GRAY);
        Button back=btn("← Home");content.addView(back);back.setOnClickListener(v->dashboard());
    }
    String dateText(long millis){if(millis<=0)return "Date not available";return new SimpleDateFormat("dd MMM yyyy",Locale.ENGLISH).format(new Date(millis));}
    class StudentDb extends android.database.sqlite.SQLiteOpenHelper{
        StudentDb(Context c){super(c,"globalminds_students.db",null,13);}
        public void onCreate(android.database.sqlite.SQLiteDatabase db){
            db.execSQL("CREATE TABLE students (id INTEGER PRIMARY KEY AUTOINCREMENT, student_id TEXT UNIQUE, ref TEXT UNIQUE, name TEXT NOT NULL, phone TEXT, programme TEXT, program_json TEXT, created_at INTEGER NOT NULL, stage TEXT NOT NULL DEFAULT 'Enquiry received', expected_amount REAL NOT NULL DEFAULT 0, due_date TEXT, city TEXT, province TEXT, nationality TEXT, gender TEXT, photo_uri TEXT, referred_by TEXT, referred_at INTEGER)");
            db.execSQL("CREATE TABLE journey_events (id INTEGER PRIMARY KEY AUTOINCREMENT, student_row_id INTEGER NOT NULL, stage TEXT NOT NULL, event_at INTEGER NOT NULL, note TEXT)");
            db.execSQL("CREATE TABLE payments (id INTEGER PRIMARY KEY AUTOINCREMENT, student_row_id INTEGER NOT NULL, amount REAL NOT NULL, currency TEXT NOT NULL DEFAULT 'USD', payment_date INTEGER NOT NULL, method TEXT, note TEXT, transaction_reference TEXT, status TEXT NOT NULL DEFAULT 'ACTIVE')");
            db.execSQL("ALTER TABLE students ADD COLUMN record_status TEXT NOT NULL DEFAULT 'ACTIVE'");
            db.execSQL("CREATE TABLE audit_log (id INTEGER PRIMARY KEY AUTOINCREMENT, entity_type TEXT NOT NULL, entity_id TEXT, action TEXT NOT NULL, before_json TEXT, after_json TEXT, reason TEXT, actor TEXT NOT NULL, created_at INTEGER NOT NULL)");
            db.execSQL("CREATE TABLE payment_receipts (id INTEGER PRIMARY KEY AUTOINCREMENT, payment_id INTEGER NOT NULL, receipt_number TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'CURRENT', created_at INTEGER NOT NULL)");
            db.execSQL("CREATE TABLE payment_followups (student_row_id INTEGER PRIMARY KEY, status TEXT NOT NULL DEFAULT 'Not Contacted', last_contact_at INTEGER, next_followup_date TEXT, notes TEXT, actor TEXT, updated_at INTEGER NOT NULL)");
            createEventTables(db); createReferralTables(db);
        }
        public void onUpgrade(android.database.sqlite.SQLiteDatabase db,int oldVersion,int newVersion){
            if(oldVersion<2){
                db.execSQL("ALTER TABLE students ADD COLUMN student_id TEXT");
                android.database.Cursor c=db.query("students",new String[]{"id","ref"},null,null,null,null,"id ASC");
                try{while(c.moveToNext()){long id=c.getLong(0);String ref=c.getString(1);android.content.ContentValues v=new android.content.ContentValues();v.put("student_id",formatStudentId(id));if(ref!=null&&ref.matches("GME-[0-9]{6,}")){v.put("ref",ref.replaceFirst("GME-","GME_"));}db.update("students",v,"id=?",new String[]{String.valueOf(id)});}}finally{c.close();}
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_students_student_id ON students(student_id)");
            }
            if(oldVersion<3){
                db.execSQL("ALTER TABLE students ADD COLUMN stage TEXT NOT NULL DEFAULT 'Enquiry received'");
                db.execSQL("ALTER TABLE students ADD COLUMN expected_amount REAL NOT NULL DEFAULT 0");
                db.execSQL("ALTER TABLE students ADD COLUMN due_date TEXT");
                db.execSQL("CREATE TABLE IF NOT EXISTS journey_events (id INTEGER PRIMARY KEY AUTOINCREMENT, student_row_id INTEGER NOT NULL, stage TEXT NOT NULL, event_at INTEGER NOT NULL, note TEXT)");
                db.execSQL("CREATE TABLE IF NOT EXISTS payments (id INTEGER PRIMARY KEY AUTOINCREMENT, student_row_id INTEGER NOT NULL, amount REAL NOT NULL, currency TEXT NOT NULL DEFAULT 'USD', payment_date INTEGER NOT NULL, method TEXT, note TEXT)");
                android.database.Cursor c=db.query("students",new String[]{"id","stage"},null,null,null,null,null);
                try{while(c.moveToNext()){android.content.ContentValues v=new android.content.ContentValues();v.put("stage",c.getString(1)==null?"Enquiry received":c.getString(1));db.insert("journey_events",null,eventValues(c.getLong(0),v.getAsString("stage"),"Existing record migrated"));}}finally{c.close();}
            }
            if(oldVersion<4){
                db.execSQL("ALTER TABLE students ADD COLUMN city TEXT");
                db.execSQL("ALTER TABLE students ADD COLUMN province TEXT");
            }
            if(oldVersion<5)createEventTables(db);
            if(oldVersion<6){try{db.execSQL("ALTER TABLE events ADD COLUMN event_type TEXT NOT NULL DEFAULT 'Community event'");}catch(Exception ignored){} try{db.execSQL("ALTER TABLE events ADD COLUMN audience TEXT NOT NULL DEFAULT 'Everyone'");}catch(Exception ignored){} try{db.execSQL("ALTER TABLE events ADD COLUMN delivery_mode TEXT NOT NULL DEFAULT 'Physical'");}catch(Exception ignored){}}
            if(oldVersion<7){try{db.execSQL("ALTER TABLE students ADD COLUMN photo_uri TEXT");}catch(Exception ignored){} try{db.execSQL("ALTER TABLE students ADD COLUMN referred_by TEXT");}catch(Exception ignored){} createReferralTables(db);}
            if(oldVersion<8){try{db.execSQL("ALTER TABLE students ADD COLUMN referred_at INTEGER");}catch(Exception ignored){}}
            if(oldVersion<9){try{db.execSQL("ALTER TABLE students ADD COLUMN nationality TEXT");}catch(Exception ignored){}}
            if(oldVersion<10){try{db.execSQL("ALTER TABLE students ADD COLUMN gender TEXT");}catch(Exception ignored){}}
            if(oldVersion<11){try{db.execSQL("ALTER TABLE payments ADD COLUMN transaction_reference TEXT");}catch(Exception ignored){} try{db.execSQL("ALTER TABLE payments ADD COLUMN status TEXT NOT NULL DEFAULT 'ACTIVE'");}catch(Exception ignored){} try{db.execSQL("ALTER TABLE students ADD COLUMN record_status TEXT NOT NULL DEFAULT 'ACTIVE'");}catch(Exception ignored){} db.execSQL("CREATE TABLE IF NOT EXISTS audit_log (id INTEGER PRIMARY KEY AUTOINCREMENT, entity_type TEXT NOT NULL, entity_id TEXT, action TEXT NOT NULL, before_json TEXT, after_json TEXT, reason TEXT, actor TEXT NOT NULL, created_at INTEGER NOT NULL)"); db.execSQL("CREATE TABLE IF NOT EXISTS payment_receipts (id INTEGER PRIMARY KEY AUTOINCREMENT, payment_id INTEGER NOT NULL, receipt_number TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'CURRENT', created_at INTEGER NOT NULL);" );}
            if(oldVersion<12){try{db.execSQL("ALTER TABLE referees ADD COLUMN photo_uri TEXT");}catch(Exception ignored){} createReferralTables(db);}
            if(oldVersion<13){db.execSQL("CREATE TABLE IF NOT EXISTS payment_followups (student_row_id INTEGER PRIMARY KEY, status TEXT NOT NULL DEFAULT 'Not Contacted', last_contact_at INTEGER, next_followup_date TEXT, notes TEXT, actor TEXT, updated_at INTEGER NOT NULL)");}
        }
        void createEventTables(android.database.sqlite.SQLiteDatabase db){db.execSQL("CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT, venue TEXT, start_at INTEGER NOT NULL, end_at INTEGER NOT NULL, agenda TEXT, created_at INTEGER NOT NULL, reminder_minutes INTEGER NOT NULL DEFAULT 60, status TEXT NOT NULL DEFAULT 'Upcoming', event_type TEXT NOT NULL DEFAULT 'Community event', audience TEXT NOT NULL DEFAULT 'Everyone', delivery_mode TEXT NOT NULL DEFAULT 'Physical')");db.execSQL("CREATE TABLE IF NOT EXISTS event_people (id INTEGER PRIMARY KEY AUTOINCREMENT, event_id INTEGER NOT NULL, name TEXT NOT NULL, phone TEXT, personal_id TEXT, gender TEXT, status TEXT NOT NULL DEFAULT 'Registered', note TEXT, created_at INTEGER NOT NULL)");}
        void createReferralTables(android.database.sqlite.SQLiteDatabase db){db.execSQL("CREATE TABLE IF NOT EXISTS referees (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE COLLATE NOCASE, phone TEXT, personal_id TEXT, gender TEXT, category TEXT NOT NULL DEFAULT 'Student', photo_uri TEXT, created_at INTEGER NOT NULL)");}
        long addEvent(String title,String description,String venue,long start,long end,String agenda,int reminder,String eventType,String audience,String deliveryMode){android.content.ContentValues v=new android.content.ContentValues();v.put("title",title);v.put("description",description);v.put("venue",venue);v.put("start_at",start);v.put("end_at",end);v.put("agenda",agenda);v.put("created_at",System.currentTimeMillis());v.put("reminder_minutes",reminder);v.put("status","Upcoming");v.put("event_type",eventType);v.put("audience",audience);v.put("delivery_mode",deliveryMode);return getWritableDatabase().insertOrThrow("events",null,v);}
        ArrayList<JSONObject> allEvents(){ArrayList<JSONObject> out=new ArrayList<>();android.database.Cursor c=getReadableDatabase().query("events",null,null,null,null,null,"CASE WHEN status='Upcoming' AND start_at>=0 THEN 0 ELSE 1 END, start_at ASC");try{while(c.moveToNext()){JSONObject o=new JSONObject();String[] cols={"id","title","description","venue","start_at","end_at","agenda","created_at","reminder_minutes","status","event_type","audience","delivery_mode"};for(String col:cols){int ix=c.getColumnIndex(col);if(ix>=0){if(col.equals("id")||col.endsWith("_at")||col.equals("reminder_minutes"))o.put(col,c.getLong(ix));else o.put(col,c.getString(ix));}}out.add(o);}}catch(Exception ignored){}finally{c.close();}return out;}
        JSONObject getEvent(long id){for(JSONObject e:allEvents())if(e.optLong("id")==id)return e;return new JSONObject();}
        void updateEventStatus(long id,String status){android.content.ContentValues v=new android.content.ContentValues();v.put("status",status);getWritableDatabase().update("events",v,"id=?",new String[]{String.valueOf(id)});}
        void updateEventDetails(long id,String title,String description,String venue,long start,long end,String agenda,int reminder,String eventType,String audience,String deliveryMode){android.content.ContentValues v=new android.content.ContentValues();v.put("title",title);v.put("description",description);v.put("venue",venue);v.put("start_at",start);v.put("end_at",end);v.put("agenda",agenda);v.put("reminder_minutes",reminder);v.put("event_type",eventType);v.put("audience",audience);v.put("delivery_mode",deliveryMode);getWritableDatabase().update("events",v,"id=?",new String[]{String.valueOf(id)});}
        long addEventPerson(long eventId,String name,String phone,String personalId,String gender,String status,String note){android.content.ContentValues v=new android.content.ContentValues();v.put("event_id",eventId);v.put("name",name);v.put("phone",phone);v.put("personal_id",personalId);v.put("gender",gender);v.put("status",status);v.put("note",note);v.put("created_at",System.currentTimeMillis());return getWritableDatabase().insertOrThrow("event_people",null,v);}
        void updatePersonStatus(long id,String status){android.content.ContentValues v=new android.content.ContentValues();v.put("status",status);getWritableDatabase().update("event_people",v,"id=?",new String[]{String.valueOf(id)});}
        ArrayList<JSONObject> eventPeople(long eventId){ArrayList<JSONObject> out=new ArrayList<>();android.database.Cursor c=getReadableDatabase().query("event_people",null,"event_id=?",new String[]{String.valueOf(eventId)},null,null,"name COLLATE NOCASE ASC");try{while(c.moveToNext()){JSONObject o=new JSONObject();String[] cols={"id","event_id","name","phone","personal_id","gender","status","note","created_at"};for(String col:cols){int ix=c.getColumnIndex(col);if(ix>=0){if(col.equals("id")||col.equals("event_id")||col.equals("created_at"))o.put(col,c.getLong(ix));else o.put(col,c.getString(ix));}}out.add(o);}}catch(Exception ignored){}finally{c.close();}return out;}
        int eventPeopleCount(long eventId,String status){android.database.Cursor c=getReadableDatabase().query("event_people",new String[]{"id"},"event_id=? AND status=?",new String[]{String.valueOf(eventId),status},null,null,null);try{return c.getCount();}finally{c.close();}}
        int eventCountByStatus(String status){android.database.Cursor c=getReadableDatabase().query("events",new String[]{"id"},"status=?",new String[]{status},null,null,null);try{return c.getCount();}finally{c.close();}}
        int totalEventPeople(String status){android.database.Cursor c=getReadableDatabase().query("event_people",new String[]{"id"},"status=?",new String[]{status},null,null,null);try{return c.getCount();}finally{c.close();}}
        String formatStudentId(long id){return "STU_"+String.format(Locale.US,"%06d",id);}
        long insert(String name,String phone,JSONObject p){android.database.sqlite.SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{android.content.ContentValues v=new android.content.ContentValues();v.put("name",name);v.put("phone",phone);v.put("programme",p.optString("name"));v.put("program_json",p.toString());v.put("created_at",System.currentTimeMillis());v.put("stage","Enquiry received");long id=db.insertOrThrow("students",null,v);db.insert("journey_events",null,eventValues(id,"Enquiry received","Student registered"));String sid=formatStudentId(id);android.content.ContentValues u=new android.content.ContentValues();u.put("student_id",sid);u.putNull("ref");db.update("students",u,"id=?",new String[]{String.valueOf(id)});db.setTransactionSuccessful();return id;}finally{db.endTransaction();}}
        String nextUniqueReference(android.database.sqlite.SQLiteDatabase db){long max=0;android.database.Cursor c=db.rawQuery("SELECT ref FROM students WHERE ref IS NOT NULL",null);try{while(c.moveToNext()){String r=c.getString(0);if(r!=null&&r.matches("GME_[0-9]+")){try{max=Math.max(max,Long.parseLong(r.substring(4)));}catch(Exception ignored){}}}}finally{c.close();}long candidate=max+1;String ref;boolean used;do{ref="GME_"+String.format(Locale.US,"%06d",candidate++);android.database.Cursor check=db.query("students",new String[]{"id"},"ref=?",new String[]{ref},null,null,null);try{used=check.moveToFirst();}finally{check.close();}}while(used);return ref;}
        String getReference(long id){android.database.Cursor c=getReadableDatabase().query("students",new String[]{"ref"},"id=?",new String[]{String.valueOf(id)},null,null,null);try{return c.moveToFirst()?c.getString(0):"";}finally{c.close();}}
        JSONObject getStudentByStudentId(String studentId){android.database.Cursor c=getReadableDatabase().query("students",new String[]{"id"},"student_id=?",new String[]{studentId},null,null,null);try{return c.moveToFirst()?getStudent(c.getLong(0)):new JSONObject();}finally{c.close();}}
        String getStudentId(long id){android.database.Cursor c=getReadableDatabase().query("students",new String[]{"student_id"},"id=?",new String[]{String.valueOf(id)},null,null,null);try{return c.moveToFirst()?c.getString(0):formatStudentId(id);}finally{c.close();}}
        void insertLegacy(String name,String phone,String oldRef,String programme){android.database.sqlite.SQLiteDatabase db=getWritableDatabase();String normalized=oldRef==null?"":oldRef.replaceFirst("^GME-","GME_");android.database.Cursor c=db.query("students",new String[]{"id"},"ref=?",new String[]{normalized},null,null,null);boolean exists=c.moveToFirst();c.close();if(exists)return;android.content.ContentValues v=new android.content.ContentValues();v.put("ref",normalized);v.put("name",name);v.put("phone",phone);v.put("programme",programme);v.put("program_json","{}");v.put("created_at",System.currentTimeMillis());v.put("stage","Enquiry received");try{long id=db.insertOrThrow("students",null,v);db.insert("journey_events",null,eventValues(id,"Enquiry received","Legacy student record imported"));android.content.ContentValues u=new android.content.ContentValues();u.put("student_id",formatStudentId(id));db.update("students",u,"id=?",new String[]{String.valueOf(id)});}catch(Exception ignored){}}
        ArrayList<JSONObject> search(String term){ArrayList<JSONObject> out=new ArrayList<>();android.database.sqlite.SQLiteDatabase db=getReadableDatabase();android.database.Cursor c;if(term==null||term.trim().isEmpty())c=db.query("students",new String[]{"id","student_id","ref","name","phone","programme","program_json","created_at","stage","city","province","nationality","photo_uri","referred_by","referred_at","gender"},"record_status=?",new String[]{"ACTIVE"},null,null,"id DESC");else{String like="%"+term.trim().replace("%","\\%").replace("_","\\_")+"%";c=db.rawQuery("SELECT id,student_id,ref,name,phone,programme,program_json,created_at,stage,city,province,nationality,photo_uri,referred_by,referred_at,gender FROM students WHERE record_status='ACTIVE' AND (name LIKE ? OR student_id LIKE ? OR phone LIKE ? OR programme LIKE ? OR city LIKE ? OR province LIKE ? OR nationality LIKE ?) ORDER BY id DESC",new String[]{like,like,like,like,like,like,like});}try{while(c.moveToNext()){JSONObject o=new JSONObject();o.put("id",c.getLong(0));o.put("student_id",c.getString(1));o.put("ref",c.getString(2));o.put("name",c.getString(3));o.put("phone",c.getString(4));o.put("programme",c.getString(5));o.put("program_json",c.getString(6));o.put("created_at",c.getLong(7));o.put("stage",c.getString(8));o.put("city",c.getString(9));o.put("province",c.getString(10));o.put("nationality",c.getString(11));o.put("photo_uri",c.getString(12));o.put("referred_by",c.getString(13));o.put("referred_at",c.isNull(14)?0:c.getLong(14));o.put("gender",c.getString(15));out.add(o);}}catch(Exception ignored){}finally{c.close();}return out;}
        void updateLocation(long rowId,String city,String province){JSONObject before=getStudent(rowId);android.content.ContentValues v=new android.content.ContentValues();v.put("city",city);v.put("province",province);getWritableDatabase().update("students",v,"id=?",new String[]{String.valueOf(rowId)});JSONObject after=getStudent(rowId);audit("STUDENT",String.valueOf(rowId),"Student location updated",before.optString("city")+", "+before.optString("province"),after.optString("city")+", "+after.optString("province"),"Student profile field updated",auditActorName());}
        void updateStudentGender(long rowId,String gender){JSONObject before=getStudent(rowId);android.content.ContentValues v=new android.content.ContentValues();v.put("gender",gender);getWritableDatabase().update("students",v,"id=?",new String[]{String.valueOf(rowId)});audit("STUDENT",String.valueOf(rowId),"Student gender updated",before.optString("gender"),gender,"Student profile field updated",auditActorName());}
        void updateNationality(long rowId,String nationality){JSONObject before=getStudent(rowId);android.content.ContentValues v=new android.content.ContentValues();v.put("nationality",nationality);getWritableDatabase().update("students",v,"id=?",new String[]{String.valueOf(rowId)});audit("STUDENT",String.valueOf(rowId),"Student nationality updated",before.optString("nationality"),nationality,"Student profile field updated",auditActorName());}
        ArrayList<JSONObject> nationalitySummary(){ArrayList<JSONObject> out=new ArrayList<>();android.database.Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(NULLIF(TRIM(nationality),''),'Not recorded') AS n, COUNT(*) AS total FROM students GROUP BY n ORDER BY total DESC LIMIT 8",null);try{while(c.moveToNext()){JSONObject o=new JSONObject();o.put("nationality",c.getString(0));o.put("total",c.getInt(1));out.add(o);}}catch(Exception ignored){}finally{c.close();}return out;}
        ArrayList<JSONObject> areaRows(){ArrayList<JSONObject> out=new ArrayList<>();String sql="SELECT COALESCE(NULLIF(TRIM(city),''),'Not recorded') AS area_city, COALESCE(NULLIF(TRIM(province),''),'Not recorded') AS area_province, COUNT(*) AS total, SUM(CASE WHEN stage IN ('Admission confirmed','Visa Applied','Visa Approved','Flight Ticket Booked','Accommodation Booked','Arrived Airport','University Reported') THEN 1 ELSE 0 END) AS admitted FROM students GROUP BY area_province, area_city ORDER BY total DESC, admitted DESC";android.database.Cursor c=getReadableDatabase().rawQuery(sql,null);try{while(c.moveToNext()){JSONObject o=new JSONObject();o.put("city",c.getString(0));o.put("province",c.getString(1));o.put("total",c.getInt(2));o.put("admitted",c.getInt(3));out.add(o);}}catch(Exception ignored){}finally{c.close();}return out;}
        ArrayList<JSONObject> areaSummary(boolean byProvince){ArrayList<JSONObject> out=new ArrayList<>();String areaExpr=byProvince?"COALESCE(NULLIF(TRIM(province),''),'Not recorded')":"(COALESCE(NULLIF(TRIM(city),''),'Not recorded') || ', ' || COALESCE(NULLIF(TRIM(province),''),'Not recorded'))";String sql="SELECT "+areaExpr+" AS area, COUNT(*) AS total, SUM(CASE WHEN stage IN ('Admission confirmed','Visa Applied','Visa Approved','Flight Ticket Booked','Accommodation Booked','Arrived Airport','University Reported') THEN 1 ELSE 0 END) AS admitted FROM students GROUP BY area ORDER BY total DESC, admitted DESC LIMIT 8";android.database.Cursor c=getReadableDatabase().rawQuery(sql,null);try{while(c.moveToNext()){JSONObject o=new JSONObject();o.put("area",c.getString(0));o.put("total",c.getInt(1));o.put("admitted",c.getInt(2));out.add(o);}}catch(Exception ignored){}finally{c.close();}return out;}
        void updateProgramme(long rowId,JSONObject p){JSONObject before=getStudent(rowId);android.content.ContentValues v=new android.content.ContentValues();v.put("programme",p.optString("name"));v.put("program_json",p.toString());getWritableDatabase().update("students",v,"id=?",new String[]{String.valueOf(rowId)});audit("STUDENT",String.valueOf(rowId),"Student programme changed",before.optString("programme"),p.optString("name"),"Programme assigned or changed",auditActorName());}
        String normalizeNameForDuplicate(String value){if(value==null)return "";return value.trim().replaceAll("\\s+"," ").toLowerCase(Locale.ROOT);}
        String normalizePhoneForDuplicate(String value){if(value==null)return "";String d=value.replaceAll("\\D","");if(d.startsWith("00"))d=d.substring(2);if(d.startsWith("0")&&d.length()==10)d="263"+d.substring(1);return d;}
        ArrayList<JSONObject> findPotentialDuplicates(String name,String phone,String city,String nationality){ArrayList<JSONObject> out=new ArrayList<>();String n=normalizeNameForDuplicate(name),ph=normalizePhoneForDuplicate(phone),ct=normalizeNameForDuplicate(city),nat=normalizeNameForDuplicate(nationality);if(n.isEmpty())return out;android.database.Cursor c=getReadableDatabase().query("students",new String[]{"id"},null,null,null,null,"id DESC");try{while(c.moveToNext()){JSONObject st=getStudent(c.getLong(0));String sn=normalizeNameForDuplicate(st.optString("name")),sph=normalizePhoneForDuplicate(st.optString("phone")),sct=normalizeNameForDuplicate(st.optString("city")),snat=normalizeNameForDuplicate(st.optString("nationality"));boolean sameName=n.equals(sn),samePhone=!ph.isEmpty()&&!sph.isEmpty()&&ph.equals(sph),sameLocation=!ct.isEmpty()&&!sct.isEmpty()&&ct.equals(sct),sameNationality=!nat.isEmpty()&&!snat.isEmpty()&&nat.equals(snat);if(!sameName&&!samePhone)continue;boolean exact=sameName&&samePhone;String reason;if(exact)reason="Exact name + phone match";else if(samePhone)reason="Phone number matches an existing record";else if(sameName&&sameNationality&&sameLocation)reason="Name + nationality + location match";else if(sameName&&sameNationality)reason="Name + nationality match";else reason="Name matches an existing record";st.put("duplicate_exact",exact);st.put("duplicate_reason",reason);out.add(st);}}catch(Exception ignored){}finally{c.close();}Collections.sort(out,(a,b)->{boolean ae=a.optBoolean("duplicate_exact",false),be=b.optBoolean("duplicate_exact",false);if(ae!=be)return ae?-1:1;return Long.compare(b.optLong("id"),a.optLong("id"));});return out;}
        android.content.ContentValues eventValues(long studentRowId,String stage,String note){android.content.ContentValues v=new android.content.ContentValues();v.put("student_row_id",studentRowId);v.put("stage",stage);v.put("event_at",System.currentTimeMillis());v.put("note",note);return v;}
        int stageIndex(String stage){for(int i=0;i<journeyStages.length;i++)if(journeyStages[i].equalsIgnoreCase(stage==null?"":stage))return i;return 0;}
        void updateStage(long rowId,String stage,String note){android.database.sqlite.SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{String previous="Enquiry received";android.database.Cursor cur=db.query("students",new String[]{"stage"},"id=?",new String[]{String.valueOf(rowId)},null,null,null);try{if(cur.moveToFirst())previous=cur.getString(0)==null?"Enquiry received":cur.getString(0);}finally{cur.close();}int oldIndex=stageIndex(previous),newIndex=stageIndex(stage);if(newIndex>oldIndex){for(int i=Math.max(0,oldIndex+1);i<newIndex&&i<journeyStages.length;i++){db.insert("journey_events",null,eventValues(rowId,journeyStages[i],"Automatically marked completed because a later journey milestone was completed"));}}android.content.ContentValues v=new android.content.ContentValues();v.put("stage",stage);db.update("students",v,"id=?",new String[]{String.valueOf(rowId)});db.insert("journey_events",null,eventValues(rowId,stage,note));android.content.ContentValues av=new android.content.ContentValues();av.put("entity_type","STUDENT");av.put("entity_id",String.valueOf(rowId));av.put("action","Journey stage changed");av.put("before_json",previous);av.put("after_json",stage);av.put("reason",note);av.put("actor",auditActorName());av.put("created_at",System.currentTimeMillis());db.insert("audit_log",null,av);db.setTransactionSuccessful();}finally{db.endTransaction();}schedulePaymentDeadlineAlerts(getStudent(rowId));}
        void updateStageByStudentId(String studentId,String stage){android.database.Cursor c=getReadableDatabase().query("students",new String[]{"id","stage"},"student_id=?",new String[]{studentId},null,null,null);try{if(c.moveToFirst()&&!stage.equals(c.getString(1)))updateStage(c.getLong(0),stage,"Automatically updated when Programme Guidance Report was generated");}finally{c.close();}}
        ArrayList<JSONObject> events(long rowId){ArrayList<JSONObject> out=new ArrayList<>();android.database.Cursor c=getReadableDatabase().query("journey_events",new String[]{"stage","event_at","note"},"student_row_id=?",new String[]{String.valueOf(rowId)},null,null,"id DESC");try{while(c.moveToNext()){JSONObject o=new JSONObject();o.put("stage",c.getString(0));o.put("event_at",c.getLong(1));o.put("note",c.getString(2));out.add(o);}}catch(Exception ignored){}finally{c.close();}return out;}
        void setExpected(long rowId,double amount,String due){android.content.ContentValues v=new android.content.ContentValues();v.put("expected_amount",amount);v.put("due_date",due);getWritableDatabase().update("students",v,"id=?",new String[]{String.valueOf(rowId)});}
        long addPayment(long rowId,double amount,String currency,String method,String reference,String note){android.content.ContentValues v=new android.content.ContentValues();v.put("student_row_id",rowId);v.put("amount",amount);v.put("currency",currency);v.put("payment_date",System.currentTimeMillis());v.put("method",method);v.put("transaction_reference",reference);v.put("note",note);v.put("status","ACTIVE");return getWritableDatabase().insertOrThrow("payments",null,v);}
        void audit(String type,String id,String action,String before,String after,String reason,String actor){android.content.ContentValues v=new android.content.ContentValues();v.put("entity_type",type);v.put("entity_id",id);v.put("action",action);v.put("before_json",before);v.put("after_json",after);v.put("reason",reason);v.put("actor",actor);v.put("created_at",System.currentTimeMillis());getWritableDatabase().insert("audit_log",null,v);}
        JSONObject payment(long paymentId){JSONObject o=new JSONObject();android.database.Cursor c=getReadableDatabase().query("payments",new String[]{"id","student_row_id","amount","currency","payment_date","method","transaction_reference","note","status"},"id=?",new String[]{String.valueOf(paymentId)},null,null,null);try{if(c.moveToFirst()){o.put("id",c.getLong(0));o.put("student_row_id",c.getLong(1));o.put("amount",c.getDouble(2));o.put("currency",c.getString(3));o.put("payment_date",c.getLong(4));o.put("method",c.getString(5));o.put("transaction_reference",c.getString(6));o.put("note",c.getString(7));o.put("status",c.getString(8));}}catch(Exception ignored){}finally{c.close();}return o;}
        ArrayList<JSONObject> paymentsForStudent(long rowId){ArrayList<JSONObject> out=new ArrayList<>();android.database.Cursor c=getReadableDatabase().query("payments",new String[]{"id"},"student_row_id=?",new String[]{String.valueOf(rowId)},null,null,"id DESC");try{while(c.moveToNext())out.add(payment(c.getLong(0)));}finally{c.close();}return out;}
        void updatePayment(long pid,double amount,long date,String currency,String method,String reference,String note){android.content.ContentValues v=new android.content.ContentValues();v.put("amount",amount);v.put("payment_date",date);v.put("currency",currency);v.put("method",method);v.put("transaction_reference",reference);v.put("note",note);getWritableDatabase().update("payments",v,"id=? AND status='ACTIVE'",new String[]{String.valueOf(pid)});}
        void reversePayment(long pid){android.content.ContentValues v=new android.content.ContentValues();v.put("status","REVERSED");getWritableDatabase().update("payments",v,"id=? AND status='ACTIVE'",new String[]{String.valueOf(pid)});}
        boolean hasReceipts(long pid){android.database.Cursor c=getReadableDatabase().query("payment_receipts",new String[]{"id"},"payment_id=?",new String[]{String.valueOf(pid)},null,null,null);try{return c.getCount()>0;}finally{c.close();}}
        void supersedeReceipts(long pid){android.content.ContentValues v=new android.content.ContentValues();v.put("status","SUPERSEDED");getWritableDatabase().update("payment_receipts",v,"payment_id=? AND status='CURRENT'",new String[]{String.valueOf(pid)});}
        String registerReceipt(long pid){android.content.ContentValues old=new android.content.ContentValues();old.put("status","SUPERSEDED");getWritableDatabase().update("payment_receipts",old,"payment_id=? AND status='CURRENT'",new String[]{String.valueOf(pid)});String number="GME-RCPT-"+String.format(Locale.US,"%06d",System.currentTimeMillis()%1000000);android.content.ContentValues v=new android.content.ContentValues();v.put("payment_id",pid);v.put("receipt_number",number);v.put("status","CURRENT");v.put("created_at",System.currentTimeMillis());getWritableDatabase().insert("payment_receipts",null,v);return number;}
        void setRecordStatus(long sid,String status){android.content.ContentValues v=new android.content.ContentValues();v.put("record_status",status);getWritableDatabase().update("students",v,"id=?",new String[]{String.valueOf(sid)});schedulePaymentDeadlineAlerts(getStudent(sid));}
        boolean hasPayments(long sid){android.database.Cursor c=getReadableDatabase().query("payments",new String[]{"id"},"student_row_id=?",new String[]{String.valueOf(sid)},null,null,null);try{return c.getCount()>0;}finally{c.close();}}
        void deleteStudent(long sid){cancelPaymentDeadlineAlerts(sid);android.database.sqlite.SQLiteDatabase db=getWritableDatabase();db.delete("journey_events","student_row_id=?",new String[]{String.valueOf(sid)});db.delete("students","id=?",new String[]{String.valueOf(sid)});}
        ArrayList<JSONObject> auditForStudent(long sid){ArrayList<JSONObject> out=new ArrayList<>();android.database.Cursor c=getReadableDatabase().rawQuery("SELECT id,entity_type,entity_id,action,before_json,after_json,reason,actor,created_at FROM audit_log WHERE entity_id=? OR entity_id IN (SELECT CAST(id AS TEXT) FROM payments WHERE student_row_id=?) ORDER BY id DESC LIMIT 100",new String[]{String.valueOf(sid),String.valueOf(sid)});try{while(c.moveToNext()){JSONObject o=new JSONObject();o.put("id",c.getLong(0));o.put("entity_type",c.getString(1));o.put("entity_id",c.getString(2));o.put("action",c.getString(3));o.put("before_json",c.getString(4));o.put("after_json",c.getString(5));o.put("reason",c.getString(6));o.put("actor",c.getString(7));o.put("created_at",c.getLong(8));out.add(o);}}catch(Exception ignored){}finally{c.close();}return out;}
        ArrayList<JSONObject> allAudit(){ArrayList<JSONObject> out=new ArrayList<>();android.database.Cursor c=getReadableDatabase().rawQuery("SELECT entity_type,entity_id,action,reason,actor,created_at FROM audit_log ORDER BY id DESC LIMIT 200",null);try{while(c.moveToNext()){JSONObject o=new JSONObject();o.put("entity_type",c.getString(0));o.put("entity_id",c.getString(1));o.put("action",c.getString(2));o.put("reason",c.getString(3));o.put("actor",c.getString(4));o.put("created_at",c.getLong(5));out.add(o);}}catch(Exception ignored){}finally{c.close();}return out;}
        double paid(long rowId){android.database.Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM payments WHERE student_row_id=? AND currency='USD' AND status='ACTIVE'",new String[]{String.valueOf(rowId)});try{return c.moveToFirst()?c.getDouble(0):0;}finally{c.close();}}
        double totalExpected(){android.database.Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(expected_amount),0) FROM students",null);try{return c.moveToFirst()?c.getDouble(0):0;}finally{c.close();}}
        double totalPaid(){android.database.Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM payments WHERE currency='USD' AND status='ACTIVE'",null);try{return c.moveToFirst()?c.getDouble(0):0;}finally{c.close();}}
        int countStage(String stage){android.database.Cursor c=getReadableDatabase().query("students",new String[]{"id"},"stage=?",new String[]{stage},null,null,null);try{return c.getCount();}finally{c.close();}}
        int countAll(){android.database.Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM students",null);try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();}}
        ArrayList<JSONObject> popularProgrammes(){ArrayList<JSONObject> out=new ArrayList<>();android.database.Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(NULLIF(TRIM(programme),''),'Not selected') AS p, COUNT(*) AS total FROM students GROUP BY p ORDER BY total DESC LIMIT 6",null);try{while(c.moveToNext()){JSONObject o=new JSONObject();o.put("programme",c.getString(0));o.put("total",c.getInt(1));out.add(o);}}catch(Exception ignored){}finally{c.close();}return out;}
        ArrayList<JSONObject> programmeAdmissions(){ArrayList<JSONObject> out=new ArrayList<>();String sql="SELECT COALESCE(NULLIF(TRIM(programme),''),'Not selected') AS p, COUNT(*) AS total, SUM(CASE WHEN stage IN ('Admission confirmed','Visa Applied','Visa Approved','Flight Ticket Booked','Accommodation Booked','Arrived Airport','University Reported') THEN 1 ELSE 0 END) AS admitted FROM students GROUP BY p ORDER BY total DESC LIMIT 8";android.database.Cursor c=getReadableDatabase().rawQuery(sql,null);try{while(c.moveToNext()){JSONObject o=new JSONObject();o.put("programme",c.getString(0));o.put("total",c.getInt(1));o.put("admitted",c.getInt(2));out.add(o);}}catch(Exception ignored){}finally{c.close();}return out;}
        ArrayList<JSONObject> monthlyPayments(){ArrayList<JSONObject> out=new ArrayList<>();HashMap<String,Double> counts=new HashMap<>();android.database.Cursor c=getReadableDatabase().rawQuery("SELECT strftime('%Y-%m',payment_date/1000,'unixepoch','localtime') AS m, SUM(amount) FROM payments WHERE currency='USD' AND status='ACTIVE' AND payment_date>=? GROUP BY m ORDER BY m",new String[]{String.valueOf(System.currentTimeMillis()-183L*24*60*60*1000)});try{while(c.moveToNext())counts.put(c.getString(0),c.getDouble(1));}finally{c.close();}java.text.SimpleDateFormat keyFmt=new java.text.SimpleDateFormat("yyyy-MM",Locale.US),labelFmt=new java.text.SimpleDateFormat("MMM",Locale.US);java.util.Calendar cal=java.util.Calendar.getInstance();cal.set(java.util.Calendar.DAY_OF_MONTH,1);cal.add(java.util.Calendar.MONTH,-5);for(int i=0;i<6;i++){String key=keyFmt.format(cal.getTime());JSONObject o=new JSONObject();try{o.put("month",labelFmt.format(cal.getTime()));o.put("total",safeChartInt(counts.containsKey(key)?counts.get(key):0));out.add(o);}catch(Exception ignored){}cal.add(java.util.Calendar.MONTH,1);}return out;}
        ArrayList<JSONObject> monthlyAdmissions(){ArrayList<JSONObject> out=new ArrayList<>();android.database.Cursor c=getReadableDatabase().rawQuery("SELECT strftime('%Y-%m',created_at/1000,'unixepoch','localtime') AS m, COUNT(*) AS total FROM students WHERE created_at>=? GROUP BY m ORDER BY m",new String[]{String.valueOf(System.currentTimeMillis()-183L*24*60*60*1000)});HashMap<String,Integer> counts=new HashMap<>();try{while(c.moveToNext())counts.put(c.getString(0),c.getInt(1));}finally{c.close();}java.text.SimpleDateFormat keyFmt=new java.text.SimpleDateFormat("yyyy-MM",Locale.US),labelFmt=new java.text.SimpleDateFormat("MMM",Locale.US);java.util.Calendar cal=java.util.Calendar.getInstance();cal.set(java.util.Calendar.DAY_OF_MONTH,1);cal.add(java.util.Calendar.MONTH,-5);for(int i=0;i<6;i++){String key=keyFmt.format(cal.getTime());JSONObject o=new JSONObject();try{o.put("month",labelFmt.format(cal.getTime()));o.put("total",counts.containsKey(key)?counts.get(key):0);out.add(o);}catch(Exception ignored){}cal.add(java.util.Calendar.MONTH,1);}return out;}
        void updateStudentPhoto(long id,String uri){JSONObject before=getStudent(id);android.content.ContentValues v=new android.content.ContentValues();v.put("photo_uri",uri);getWritableDatabase().update("students",v,"id=?",new String[]{String.valueOf(id)});audit("STUDENT",String.valueOf(id),"Student photograph updated",before.optString("photo_uri").isEmpty()?"No photo":"Photo set","Photo updated","Student profile field updated",auditActorName());}
        void updateStudentReferrer(long id,String name){JSONObject before=getStudent(id);android.content.ContentValues v=new android.content.ContentValues();if(name==null||name.trim().isEmpty()){v.putNull("referred_by");v.putNull("referred_at");}else{v.put("referred_by",name.trim());v.put("referred_at",System.currentTimeMillis());}getWritableDatabase().update("students",v,"id=?",new String[]{String.valueOf(id)});audit("STUDENT",String.valueOf(id),"Student referral source changed",before.optString("referred_by"),name==null?"":name.trim(),"Referral source updated",auditActorName());}
        long addReferee(String name,String phone,String pid,String gender,String category){android.content.ContentValues v=new android.content.ContentValues();v.put("name",name.trim());v.put("phone",phone);v.put("personal_id",pid);v.put("gender",gender);v.put("category",category);v.put("created_at",System.currentTimeMillis());return getWritableDatabase().insertWithOnConflict("referees",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);}

        ArrayList<JSONObject> allReferees(){ArrayList<JSONObject> out=new ArrayList<>();android.database.Cursor c=getReadableDatabase().query("referees",null,null,null,null,null,"name COLLATE NOCASE ASC");try{while(c.moveToNext()){JSONObject o=new JSONObject();String[] cols={"id","name","phone","personal_id","gender","category","created_at"};for(String col:cols){int ix=c.getColumnIndex(col);if(ix>=0){if(col.equals("id")||col.equals("created_at"))o.put(col,c.getLong(ix));else o.put(col,c.getString(ix));}}out.add(o);}}catch(Exception ignored){}finally{c.close();}return out;}
        ArrayList<JSONObject> referralRankings(boolean thisMonth){ArrayList<JSONObject> out=new ArrayList<>();String sql="SELECT referred_by, COUNT(*) AS total, SUM(CASE WHEN stage IN ('Admission confirmed','Visa Applied','Visa Approved','Flight Ticket Booked','Accommodation Booked','Arrived Airport','University Reported') THEN 1 ELSE 0 END) AS admitted FROM students WHERE referred_by IS NOT NULL AND TRIM(referred_by)<>''";if(thisMonth)sql+=" AND referred_at>=?";sql+=" GROUP BY referred_by COLLATE NOCASE ORDER BY total DESC, admitted DESC, referred_by COLLATE NOCASE";android.database.Cursor c=thisMonth?getReadableDatabase().rawQuery(sql,new String[]{String.valueOf(monthStartMillis())}):getReadableDatabase().rawQuery(sql,null);try{while(c.moveToNext()){JSONObject o=new JSONObject();o.put("name",c.getString(0));o.put("total",c.getInt(1));o.put("admitted",c.getInt(2));out.add(o);}}catch(Exception ignored){}finally{c.close();}return out;}
        long monthStartMillis(){Calendar cal=Calendar.getInstance();cal.set(Calendar.DAY_OF_MONTH,1);cal.set(Calendar.HOUR_OF_DAY,0);cal.set(Calendar.MINUTE,0);cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);return cal.getTimeInMillis();}
        ArrayList<JSONObject> studentsByReferee(String referee){ArrayList<JSONObject> out=new ArrayList<>();android.database.Cursor c=getReadableDatabase().query("students",new String[]{"id"},"referred_by=? COLLATE NOCASE",new String[]{referee},null,null,"created_at DESC");try{while(c.moveToNext())out.add(getStudent(c.getLong(0)));}finally{c.close();}return out;}
        int referralCount(String referee){android.database.Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM students WHERE referred_by=? COLLATE NOCASE",new String[]{referee});try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();}}
        JSONObject getStudent(long rowId){android.database.Cursor c=getReadableDatabase().query("students",new String[]{"id","student_id","ref","name","phone","programme","program_json","created_at","stage","expected_amount","due_date","city","province","nationality","photo_uri","referred_by","referred_at","gender","record_status"},"id=?",new String[]{String.valueOf(rowId)},null,null,null);try{if(!c.moveToFirst())return new JSONObject();JSONObject o=new JSONObject();o.put("id",c.getLong(0));o.put("student_id",c.getString(1));o.put("ref",c.getString(2));o.put("name",c.getString(3));o.put("phone",c.getString(4));o.put("programme",c.getString(5));o.put("program_json",c.getString(6));o.put("created_at",c.getLong(7));o.put("stage",c.getString(8));o.put("expected_amount",c.getDouble(9));o.put("due_date",c.getString(10));o.put("city",c.getString(11));o.put("province",c.getString(12));o.put("nationality",c.getString(13));o.put("photo_uri",c.getString(14));o.put("referred_by",c.getString(15));o.put("referred_at",c.isNull(16)?0:c.getLong(16));o.put("gender",c.getString(17));o.put("record_status",c.getString(18));return o;}catch(Exception e){return new JSONObject();}finally{c.close();}}
        JSONObject latestPayment(long rowId){android.database.Cursor c=getReadableDatabase().query("payments",new String[]{"amount","currency","payment_date","method","note","id","transaction_reference","status"},"student_row_id=? AND status='ACTIVE'",new String[]{String.valueOf(rowId)},null,null,"id DESC","1");try{if(!c.moveToFirst())return new JSONObject();JSONObject o=new JSONObject();o.put("amount",c.getDouble(0));o.put("currency",c.getString(1));o.put("payment_date",c.getLong(2));o.put("method",c.getString(3));o.put("note",c.getString(4));o.put("id",c.getLong(5));o.put("transaction_reference",c.getString(6));o.put("status",c.getString(7));return o;}catch(Exception e){return new JSONObject();}finally{c.close();}}
        JSONObject getFollowup(long studentRowId){JSONObject o=new JSONObject();android.database.Cursor c=getReadableDatabase().query("payment_followups",new String[]{"status","last_contact_at","next_followup_date","notes","actor","updated_at"},"student_row_id=?",new String[]{String.valueOf(studentRowId)},null,null,null);try{if(c.moveToFirst()){o.put("status",c.getString(0));o.put("last_contact_at",c.getLong(1));o.put("next_followup_date",c.getString(2));o.put("notes",c.getString(3));o.put("actor",c.getString(4));o.put("updated_at",c.getLong(5));}}catch(Exception ignored){}finally{c.close();}if(!o.has("status"))try{o.put("status","Not Contacted");}catch(Exception ignored){}return o;}
        void saveFollowup(long studentRowId,String status,String nextDate,String notes,String actor){android.content.ContentValues v=new android.content.ContentValues();v.put("student_row_id",studentRowId);v.put("status",status);v.put("last_contact_at",System.currentTimeMillis());v.put("next_followup_date",nextDate);v.put("notes",notes);v.put("actor",actor);v.put("updated_at",System.currentTimeMillis());getWritableDatabase().insertWithOnConflict("payment_followups",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);}
        ArrayList<JSONObject> financeRows(){ArrayList<JSONObject> out=new ArrayList<>();android.database.Cursor c=getReadableDatabase().query("students",new String[]{"id"},"record_status=?",new String[]{"ACTIVE"},null,null,"id DESC");try{while(c.moveToNext())out.add(getStudent(c.getLong(0)));}finally{c.close();}return out;}
        ArrayList<JSONObject> lifecycleRows(){ArrayList<JSONObject> out=new ArrayList<>();android.database.Cursor c=getReadableDatabase().query("students",new String[]{"id"},"record_status<>?",new String[]{"ACTIVE"},null,null,"id DESC");try{while(c.moveToNext())out.add(getStudent(c.getLong(0)));}finally{c.close();}return out;}
    }
    String[] journeyStages={"Enquiry received","Counselling completed","Programme guidance issued","Student undertaking signed","Application submitted","Accepted","University decision received","Admission confirmed","Visa Applied","Visa Approved","Flight Ticket Booked","Accommodation Booked","Arrived Airport","University Reported"};
    String journeyGroupForStage(String stage){return journeyStages[Math.max(0,Math.min(journeyStages.length-1,studentDb.stageIndex(stage)))];}
    String journeyChipLabel(int index){String[] icons={"💬","🤝","🎓","✍️","📝","✅","🏛️","🎓","🛂","🛂","✈️","🏠","🛬","🏫"};return icons[index]+" "+journeyStages[index];}
    String[] journeyFilterLabels(){String[] labels=new String[journeyStages.length+1];labels[0]="All";for(int i=0;i<journeyStages.length;i++)labels[i+1]=journeyChipLabel(i);return labels;}
    int journeyFilterIndex(String stage){return Math.max(0,Math.min(journeyStages.length-1,studentDb.stageIndex(stage)))+1;}
    void journeyTracker(){
        base("Student Journey Tracker");
        String[] stageLabels={"Enquiry","Counselling","Guidance","Undertaking","Application","Accepted","Decision","Admitted","Visa applied","Visa approved","Travel booked","Arrived","Reported"};
        int[] stageValues={studentDb.countStage("Enquiry received"),studentDb.countStage("Counselling completed"),studentDb.countStage("Programme guidance issued"),studentDb.countStage("Student undertaking signed"),studentDb.countStage("Application submitted"),studentDb.countStage("Accepted"),studentDb.countStage("University decision received"),studentDb.countStage("Admission confirmed"),studentDb.countStage("Visa Applied"),studentDb.countStage("Visa Approved"),studentDb.countStage("Flight Ticket Booked")+studentDb.countStage("Accommodation Booked"),studentDb.countStage("Arrived Airport"),studentDb.countStage("University Reported")};
        chartCard("Students at each current journey stage",new DataChart(DataChart.BAR,stageLabels,stageValues));
        chartCard("Journey stage distribution",new DataChart(DataChart.PIE,stageLabels,stageValues));
        ArrayList<JSONObject> natRows=studentDb.nationalitySummary();String[] natLabels=new String[natRows.size()];int[] natValues=new int[natRows.size()];for(int ni=0;ni<natRows.size();ni++){natLabels[ni]=natRows.get(ni).optString("nationality");natValues[ni]=natRows.get(ni).optInt("total");}
        chartCard("Student nationality distribution",new DataChart(DataChart.PIE,natLabels,natValues));
        addText("STUDENT WORKLIST BY JOURNEY",12,purple);addText("Choose a journey milestone group using the horizontal filters.",12,Color.GRAY);
        EditText q=field("Search by name, ID, nationality or programme...");content.addView(q);LinearLayout chips=new LinearLayout(this);chips.setOrientation(LinearLayout.VERTICAL);content.addView(chips);TextView groupCount=new TextView(this);groupCount.setTextColor(Color.GRAY);groupCount.setPadding(4,2,4,8);content.addView(groupCount);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);
        final String[] groups=journeyFilterLabels();final int[] selected={0};final Runnable[] refreshRef={null};
        Runnable refresh=()->{list.removeAllViews();ArrayList<JSONObject> matches=studentDb.search(q.getText().toString());int[] totals=new int[groups.length];totals[0]=matches.size();for(JSONObject st:matches)totals[journeyFilterIndex(st.optString("stage","Enquiry received"))]++;chips.removeAllViews();horizontalFilterChips(chips,groups,totals,selected[0],ix->{selected[0]=ix;if(refreshRef[0]!=null)refreshRef[0].run();});int shown=0;for(JSONObject st:matches){if(selected[0]!=0&&selected[0]!=journeyFilterIndex(st.optString("stage","Enquiry received")))continue;shown++;addReferralStamp(list,st.optString("referred_by"));addStudentListRow(list,st,st.optString("name")+" • "+st.optString("student_id")+"\nStage: "+st.optString("stage","Enquiry received")+"\nNationality: "+(st.optString("nationality").isEmpty()?"Not recorded":st.optString("nationality")));}groupCount.setText(shown+" student record"+(shown==1?"":"s")+" shown");if(shown==0)addTextToContainer(list,"No active student records at this milestone.",14,Color.GRAY);};
        refreshRef[0]=refresh;q.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){}public void onTextChanged(CharSequence s,int a,int b,int c){refresh.run();}public void afterTextChanged(android.text.Editable e){}});refresh.run();
    }
    void studentJourneyDetails(JSONObject st){
        long id=st.optLong("id");JSONObject fresh=studentDb.getStudent(id);base("Student Journey");setRefreshAction(()->studentJourneyDetails(studentDb.getStudent(id)));pinStudentContext(fresh);
        addReferralStamp(content,fresh.optString("referred_by"));addText(fresh.optString("name"),20,Color.DKGRAY);addText(fresh.optString("student_id"),13,purple);
        addText("Current stage: "+fresh.optString("stage"),16,Color.DKGRAY);
        int progressIndex=studentDb.stageIndex(fresh.optString("stage"));
        int progressPct=Math.max(0,Math.min(100,Math.round((progressIndex+1)*100f/journeyStages.length)));
        addText("OVERALL JOURNEY COMPLETION",12,purple);
        TextView pctLabel=new TextView(this);pctLabel.setText(progressPct+"% complete • "+(progressIndex+1)+" of "+journeyStages.length+" milestones reached");pctLabel.setTextSize(14);pctLabel.setTypeface(null,1);pctLabel.setTextColor(ink);pctLabel.setPadding(0,dp(5),0,dp(7));content.addView(pctLabel);
        ProgressBar journeyProgress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);journeyProgress.setMax(100);journeyProgress.setProgress(progressPct);journeyProgress.setProgressTintList(android.content.res.ColorStateList.valueOf(purple));LinearLayout.LayoutParams jpp=new LinearLayout.LayoutParams(-1,dp(10));jpp.setMargins(0,0,0,dp(16));content.addView(journeyProgress,jpp);
        addText("MILESTONE PROGRESS",17,purple);addText("Each milestone shows its completion status and its contribution to the overall journey.",12,Color.GRAY);
        for(int mi=0;mi<journeyStages.length;mi++){
            final int milestoneIndex=mi;boolean completed=mi<=progressIndex;int milestonePct=Math.round((mi+1)*100f/journeyStages.length);
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackground(shape(Color.WHITE,completed?Color.rgb(202,180,225):Color.rgb(232,225,239)));LinearLayout.LayoutParams clp=new LinearLayout.LayoutParams(-1,-2);clp.setMargins(0,dp(3),0,dp(5));content.addView(card,clp);
            LinearLayout top=new LinearLayout(this);top.setOrientation(LinearLayout.HORIZONTAL);top.setGravity(Gravity.CENTER_VERTICAL);card.addView(top,new LinearLayout.LayoutParams(-1,-2));
            TextView marker=new TextView(this);marker.setText(completed?"✓":"○");marker.setTextSize(18);marker.setTypeface(null,1);marker.setTextColor(completed?Color.rgb(43,135,83):Color.GRAY);marker.setGravity(Gravity.CENTER);top.addView(marker,new LinearLayout.LayoutParams(dp(30),-2));
            LinearLayout labels=new LinearLayout(this);labels.setOrientation(LinearLayout.VERTICAL);labels.setPadding(dp(7),0,0,0);top.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
            TextView name=new TextView(this);name.setText(journeyStages[mi]);name.setTextSize(14);name.setTypeface(null,1);name.setTextColor(ink);labels.addView(name);
            TextView state=new TextView(this);state.setText(completed?"COMPLETED":"NOT YET COMPLETED");state.setTextSize(10);state.setTypeface(null,1);state.setTextColor(completed?Color.rgb(43,135,83):Color.GRAY);state.setPadding(0,dp(2),0,0);labels.addView(state);
            TextView contribution=new TextView(this);contribution.setText(milestonePct+"% journey point");contribution.setTextSize(12);contribution.setTypeface(null,1);contribution.setTextColor(purple);top.addView(contribution);
            ProgressBar milestoneBar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);milestoneBar.setMax(100);milestoneBar.setProgress(completed?100:0);milestoneBar.setProgressTintList(android.content.res.ColorStateList.valueOf(completed?Color.rgb(73,153,104):purple));LinearLayout.LayoutParams mbp=new LinearLayout.LayoutParams(-1,dp(5));mbp.setMargins(dp(37),dp(7),0,0);card.addView(milestoneBar,mbp);
        }
        addText("MILESTONE CONTROLS",12,purple);Button update=btn("Update Journey Stage");content.addView(update);update.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Select completed milestone").setItems(journeyStages,(d,which)->{studentDb.updateStage(id,journeyStages[which],"Milestone recorded by staff");toast("Journey stage updated");studentJourneyDetails(studentDb.getStudent(id));}).show());
        addText("Journey History",17,purple);for(JSONObject ev:studentDb.events(id))addText(dateTime(ev.optLong("event_at"))+" • "+ev.optString("stage")+(ev.optString("note").isEmpty()?"":"\n"+ev.optString("note")),13,Color.DKGRAY);
        Button back=btn("← Back to journey tracker");content.addView(back);back.setOnClickListener(v->journeyTracker());
    }
    String dateTime(long millis){return new SimpleDateFormat("dd MMM yyyy, HH:mm",Locale.ENGLISH).format(new Date(millis));}
    String eventDateTime(long millis){return new SimpleDateFormat("EEE, dd MMM yyyy • HH:mm",Locale.ENGLISH).format(new Date(millis));}
    String countdown(long millis){long diff=millis-System.currentTimeMillis();if(diff<0)return "Started " + dateTime(millis);long days=diff/86400000L;long hours=(diff%86400000L)/3600000L;long mins=(diff%3600000L)/60000L;if(days>0)return days+"d "+hours+"h to go";if(hours>0)return hours+"h "+mins+"m to go";return mins+"m to go";}
    void eventsDashboard(){base("Events & Engagement");ArrayList<JSONObject> evs=studentDb.allEvents();int upcoming=0,completed=0,registered=0,coming=0,attended=0;for(JSONObject e:evs){if("Upcoming".equals(e.optString("status"))&&e.optLong("start_at")>=System.currentTimeMillis())upcoming++;if("Completed".equals(e.optString("status")))completed++;for(JSONObject person:studentDb.eventPeople(e.optLong("id"))){String st=person.optString("status");if(st.equals("Registered"))registered++;else if(st.equals("Confirmed"))coming++;else if(st.equals("Attended"))attended++;}}
        addText("EVENT COMMAND CENTRE",12,purple);addText("Plan meaningful connections, track participation and turn events into measurable community engagement.",14,Color.DKGRAY);LinearLayout metrics=new LinearLayout(this);metrics.setOrientation(LinearLayout.HORIZONTAL);String[][] metric={{"UPCOMING",String.valueOf(upcoming)},{"REGISTERED",String.valueOf(registered)},{"CONFIRMED",String.valueOf(coming)},{"ATTENDED",String.valueOf(attended)}};for(String[] m:metric){LinearLayout tile=new LinearLayout(this);tile.setOrientation(LinearLayout.VERTICAL);tile.setPadding(dp(8),dp(12),dp(8),dp(12));tile.setGravity(Gravity.CENTER);tile.setBackground(shape(Color.WHITE,Color.rgb(232,225,239)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(2),dp(3),dp(2),dp(8));metrics.addView(tile,lp);TextView n=new TextView(this);n.setText(m[1]);n.setTextSize(22);n.setTypeface(null,1);n.setTextColor(purple);tile.addView(n);TextView l=new TextView(this);l.setText(m[0]);l.setTextSize(9);l.setTextColor(ink);tile.addView(l);}content.addView(metrics);chartCard("Event portfolio",new DataChart(DataChart.PIE,new String[]{"Upcoming","Completed"},new int[]{upcoming,completed}));chartCard("Guest participation status",new DataChart(DataChart.BAR,new String[]{"Registered","Confirmed","Attended"},new int[]{registered,coming,attended}));Button create=btn("＋  Create an event");content.addView(create);create.setOnClickListener(v->createEvent());addGap();addText("EVENT CALENDAR",18,purple);if(evs.isEmpty())addText("No events yet. Create your first event to start building an engagement calendar.",14,Color.GRAY);for(JSONObject e:evs){long id=e.optLong("id"),start=e.optLong("start_at");String status=e.optString("status");LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(14),dp(12),dp(14),dp(12));card.setBackground(shape(Color.WHITE,Color.rgb(229,221,237)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(9));content.addView(card,lp);TextView name=new TextView(this);name.setText((status.equals("Completed")?"✓  ":"◉  ")+e.optString("title"));name.setTextSize(17);name.setTypeface(null,1);name.setTextColor(purpleDark);card.addView(name);TextView date=new TextView(this);date.setText("🗓  "+eventDateTime(start)+"\n📍  "+e.optString("venue","Venue not set")+"\n"+e.optString("event_type","Community event")+" • "+e.optString("audience","Everyone")+" • "+e.optString("delivery_mode","Physical"));date.setTextSize(12);date.setTextColor(ink);date.setPadding(0,dp(5),0,dp(4));card.addView(date);TextView count=new TextView(this);count.setText(status.equals("Completed")?"EVENT COMPLETED":countdown(start)+"  •  "+studentDb.eventPeople(id).size()+" people on guest list");count.setTextColor(status.equals("Completed")?Color.GRAY:purple);count.setTypeface(null,1);count.setTextSize(12);card.addView(count);Button open=btn("Open event workspace  ›");card.addView(open);open.setOnClickListener(v->eventDetails(id));card.setOnClickListener(v->eventDetails(id));}Button back=btn("← Home");content.addView(back);back.setOnClickListener(v->dashboard());}
    void createEvent(){base("Create an Event");EditText name=field("Event title / name *"),desc=field("Purpose and description"),venue=field("Venue, address or online meeting link");content.addView(name);content.addView(desc);content.addView(venue);addText("EVENT PURPOSE, AUDIENCE & FORMAT",12,purple);Spinner type=new Spinner(this);String[] types={"Community event","Student information session","Admissions event","Orientation","Business meeting","Networking event","Workshop / training","Other"};type.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,types));content.addView(type);Spinner audience=new Spinner(this);String[] audiences={"Everyone","Enquiring students","Admitted students","Students already in India","Former / alumni students","Business partners / meeting guests","Staff only","Custom invite list"};audience.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,audiences));content.addView(audience);Spinner mode=new Spinner(this);String[] modes={"Physical","Online","Hybrid"};mode.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,modes));content.addView(mode);addText("For physical events, enter the venue and address. For online events, enter the meeting link and access instructions in the venue field.",12,Color.GRAY);addText("EVENT DATE & TIMING",12,purple);final long[] start={System.currentTimeMillis()+86400000L},end={System.currentTimeMillis()+90000000L};Button startBtn=btn("Starts: "+eventDateTime(start[0]));Button endBtn=btn("Ends: "+eventDateTime(end[0]));content.addView(startBtn);content.addView(endBtn);startBtn.setOnClickListener(v->pickEventDateTime(start[0],val->{start[0]=val;if(end[0]<val)end[0]=val+3600000L;startBtn.setText("Starts: "+eventDateTime(start[0]));endBtn.setText("Ends: "+eventDateTime(end[0]));}));endBtn.setOnClickListener(v->pickEventDateTime(end[0],val->{end[0]=val;endBtn.setText("Ends: "+eventDateTime(end[0]));}));EditText agenda=multiField("Agenda: add topics, speakers, sessions and expected timings");content.addView(agenda);addText("Reminder before event",12,purple);final int[] reminder={60};Spinner rem=new Spinner(this);String[] opts={"At event time","15 minutes before","1 hour before","1 day before"};rem.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,opts));rem.setSelection(2);content.addView(rem);rem.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){reminder[0]=new int[]{0,15,60,1440}[pos];}});Button save=btn("Save Event & Schedule Reminder");content.addView(save);save.setOnClickListener(v->{if(name.getText().toString().trim().isEmpty()){name.setError("Event title is required");return;}if(end[0]<=start[0]){toast("End time must be after start time");return;}try{long id=studentDb.addEvent(name.getText().toString().trim(),desc.getText().toString().trim(),venue.getText().toString().trim(),start[0],end[0],agenda.getText().toString().trim(),reminder[0],type.getSelectedItem().toString(),audience.getSelectedItem().toString(),mode.getSelectedItem().toString());scheduleEventReminder(id,name.getText().toString().trim(),start[0]-reminder[0]*60000L);toast("Event saved");eventDetails(id);}catch(Exception ex){toast("Could not save event: "+ex.getMessage());}});Button cancel=btn("Cancel");content.addView(cancel);cancel.setOnClickListener(v->eventsDashboard());}
    interface TimeResult{void accept(long millis);}void pickEventDateTime(long initial,TimeResult result){Calendar c=Calendar.getInstance();c.setTimeInMillis(initial);new DatePickerDialog(this,(view,y,m,d)->{Calendar picked=Calendar.getInstance();picked.set(y,m,d);Calendar old=Calendar.getInstance();old.setTimeInMillis(initial);new TimePickerDialog(this,(tv,hour,min)->{picked.set(Calendar.HOUR_OF_DAY,hour);picked.set(Calendar.MINUTE,min);picked.set(Calendar.SECOND,0);result.accept(picked.getTimeInMillis());},old.get(Calendar.HOUR_OF_DAY),old.get(Calendar.MINUTE),true).show();},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH));DatePickerDialog picker=new DatePickerDialog(this,(view,y,m,d)->{lpuDobValue=String.format(Locale.ROOT,"%02d/%02d/%04d",d,m+1,y);if(lpuDobButton!=null)lpuDobButton.setText("Select date of birth: "+lpuDobValue);},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH));picker.getDatePicker().setMaxDate(System.currentTimeMillis());picker.show();}
    String upper(String value){return value==null?"":value.trim().toUpperCase(Locale.ROOT);}
    void applyUppercaseInput(EditText edit){if(edit==null)return;edit.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.AllCaps()});}
    EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(14);e.setTextColor(ink);e.setHintTextColor(Color.rgb(105,98,113));e.setSingleLine(true);e.setPadding(dp(12),dp(10),dp(12),dp(10));e.setBackground(shape(Color.WHITE,Color.rgb(225,216,234)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(8));e.setLayoutParams(lp);return e;}
    EditText multiField(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(14);e.setTextColor(ink);e.setHintTextColor(Color.rgb(105,98,113));e.setGravity(Gravity.TOP|Gravity.START);e.setMinLines(3);e.setPadding(dp(12),dp(10),dp(12),dp(10));e.setBackground(shape(Color.WHITE,Color.rgb(225,216,234)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(8));e.setLayoutParams(lp);return e;}
    void eventDetails(long eventId){JSONObject e=studentDb.getEvent(eventId);if(e.length()==0){eventsDashboard();return;}base("Event Workspace");long start=e.optLong("start_at");addText(e.optString("title"),22,purpleDark);addText(e.optString("description"),14,Color.DKGRAY);addText("EVENT TYPE: "+e.optString("event_type","Community event")+"\nFOR: "+e.optString("audience","Everyone")+"\nFORMAT: "+e.optString("delivery_mode","Physical")+"\n\n📅 START\n"+eventDateTime(start)+"\n\n🏁 END\n"+eventDateTime(e.optLong("end_at"))+"\n\n📍 VENUE / MEETING LINK\n"+e.optString("venue","Not specified"),14,ink);addText("⏳ COUNTDOWN",12,purple);addText(e.optString("status").equals("Completed")?"This event has been marked completed.":countdown(start),22,purpleDark);addText("AGENDA & SESSION PLAN",16,purple);addText(e.optString("agenda").isEmpty()?"No agenda added yet.":e.optString("agenda"),14,ink);ArrayList<JSONObject> people=studentDb.eventPeople(eventId);int reg=studentDb.eventPeopleCount(eventId,"Registered"),confirmed=studentDb.eventPeopleCount(eventId,"Confirmed"),attended=studentDb.eventPeopleCount(eventId,"Attended"),absent=studentDb.eventPeopleCount(eventId,"Absent");chartCard("Attendance & RSVP",new DataChart(DataChart.PIE,new String[]{"Registered","Confirmed","Attended","Absent"},new int[]{reg,confirmed,attended,absent}));addText("PEOPLE & ATTENDANCE",17,purple);addText("Registered: "+reg+"  •  Confirmed coming: "+confirmed+"  •  Attended: "+attended+"  •  Absent: "+absent,13,Color.DKGRAY);Button edit=btn("✎ Edit event details, timing, venue or agenda");content.addView(edit);edit.setOnClickListener(v->editEvent(eventId));Button add=btn("＋ Register a person / guest");content.addView(add);add.setOnClickListener(v->addEventPerson(eventId));Button existing=btn("＋ Add an existing Global Minds student");content.addView(existing);existing.setOnClickListener(v->addExistingStudentToEvent(eventId));Button complete=btn(e.optString("status").equals("Completed")?"Event marked completed":"✓ Mark event completed");content.addView(complete);complete.setOnClickListener(v->{studentDb.updateEventStatus(eventId,"Completed");eventDetails(eventId);});Button reminder=btn("🔔 Reschedule event reminder");content.addView(reminder);reminder.setOnClickListener(v->scheduleEventReminder(eventId,e.optString("title"),Math.max(System.currentTimeMillis()+5000,start-e.optLong("reminder_minutes")*60000L)));Button batch=btn("▣ Generate passes / invitations for all listed people");content.addView(batch);batch.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Generate event documents").setMessage("Create a separate gate pass for each person for physical events, or an online meeting invitation for each person for online events. Each file can be shared or sent using your preferred app.").setPositiveButton("Generate documents",(d,w)->{try{File archive=generateEventDocumentBundle(e,studentDb.eventPeople(eventId));share(archive);}catch(Exception ex){toast("Could not package event documents");}}).setNegativeButton("Cancel",null).show());for(JSONObject person:people){LinearLayout pc=new LinearLayout(this);pc.setOrientation(LinearLayout.VERTICAL);pc.setPadding(dp(12),dp(10),dp(12),dp(10));pc.setBackground(shape(Color.WHITE,Color.rgb(232,225,239)));LinearLayout.LayoutParams pl=new LinearLayout.LayoutParams(-1,-2);pl.setMargins(0,dp(3),0,dp(6));content.addView(pc,pl);TextView pn=new TextView(this);pn.setText(person.optString("name")+"  •  "+person.optString("status"));pn.setTextSize(15);pn.setTypeface(null,1);pn.setTextColor(purpleDark);pc.addView(pn);TextView pd=new TextView(this);pd.setText("Contact: "+person.optString("phone","Not provided")+"\nID: "+person.optString("personal_id","Not provided")+"\nGender: "+person.optString("gender","Not provided")+(person.optString("note").isEmpty()?"":"\nNotes: "+person.optString("note")));pd.setTextSize(12);pd.setTextColor(ink);pc.addView(pd);Button doc=btn(e.optString("delivery_mode","Physical").equals("Online")?"✉ Generate online meeting invitation":"▣ Generate gate pass / event invitation");pc.addView(doc);doc.setOnClickListener(v->{if(e.optString("delivery_mode","Physical").equals("Hybrid")){new AlertDialog.Builder(this).setTitle("Choose participant document").setItems(new String[]{"Generate physical gate pass","Generate online meeting invitation"},(dlg,which)->{try{JSONObject copy=new JSONObject(e.toString());copy.put("delivery_mode",which==0?"Physical":"Online");share(generateEventDocument(copy,person));}catch(Exception ex){toast("Could not generate document");}}).show();}else{try{share(generateEventDocument(e,person));}catch(Exception ex){toast("Could not generate event document");}}});Button status=btn("Update RSVP / attendance status");pc.addView(status);status.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Update status for "+person.optString("name")).setItems(new String[]{"Registered","Confirmed — coming","Attended","Absent","Cancelled"},(d,which)->{String[] values={"Registered","Confirmed","Attended","Absent","Cancelled"};studentDb.updatePersonStatus(person.optLong("id"),values[which]);eventDetails(eventId);}).show());}Button back=btn("← Events");content.addView(back);back.setOnClickListener(v->eventsDashboard());}
    void editEvent(long eventId){JSONObject e=studentDb.getEvent(eventId);base("Edit Event");EditText name=field("Event title *"),desc=field("Purpose and description"),venue=field("Venue / address / online link");name.setText(e.optString("title"));desc.setText(e.optString("description"));venue.setText(e.optString("venue"));content.addView(name);content.addView(desc);content.addView(venue);addText("Event type",12,purple);Spinner type=new Spinner(this);String[] types={"Community event","Student information session","Admissions event","Orientation","Business meeting","Networking event","Workshop / training","Other"};type.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,types));type.setSelection(Math.max(0,Arrays.asList(types).indexOf(e.optString("event_type","Community event"))));content.addView(type);addText("Audience",12,purple);Spinner audience=new Spinner(this);String[] audiences={"Everyone","Enquiring students","Admitted students","Students already in India","Former / alumni students","Business partners / meeting guests","Staff only","Custom invite list"};audience.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,audiences));audience.setSelection(Math.max(0,Arrays.asList(audiences).indexOf(e.optString("audience","Everyone"))));content.addView(audience);addText("Format",12,purple);Spinner mode=new Spinner(this);String[] modes={"Physical","Online","Hybrid"};mode.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,modes));mode.setSelection(Math.max(0,Arrays.asList(modes).indexOf(e.optString("delivery_mode","Physical"))));content.addView(mode);final long[] start={e.optLong("start_at")},end={e.optLong("end_at")};Button sb=btn("Starts: "+eventDateTime(start[0])),eb=btn("Ends: "+eventDateTime(end[0]));content.addView(sb);content.addView(eb);sb.setOnClickListener(v->pickEventDateTime(start[0],val->{start[0]=val;sb.setText("Starts: "+eventDateTime(val));}));eb.setOnClickListener(v->pickEventDateTime(end[0],val->{end[0]=val;eb.setText("Ends: "+eventDateTime(val));}));EditText agenda=multiField("Agenda / speakers / session timings");agenda.setText(e.optString("agenda"));content.addView(agenda);addText("Reminder lead time",12,purple);Spinner rem=new Spinner(this);String[] options={"At event time","15 minutes before","1 hour before","1 day before"};rem.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,options));int current=e.optInt("reminder_minutes",60);rem.setSelection(current==0?0:current==15?1:current==1440?3:2);content.addView(rem);Button save=btn("Save Event Changes & Update Reminder");content.addView(save);save.setOnClickListener(v->{if(name.getText().toString().trim().isEmpty()){name.setError("Event title is required");return;}if(end[0]<=start[0]){toast("End time must be after start time");return;}int mins=new int[]{0,15,60,1440}[rem.getSelectedItemPosition()];studentDb.updateEventDetails(eventId,name.getText().toString().trim(),desc.getText().toString().trim(),venue.getText().toString().trim(),start[0],end[0],agenda.getText().toString().trim(),mins,type.getSelectedItem().toString(),audience.getSelectedItem().toString(),mode.getSelectedItem().toString());scheduleEventReminder(eventId,name.getText().toString().trim(),start[0]-mins*60000L);eventDetails(eventId);});Button cancel=btn("Cancel");content.addView(cancel);cancel.setOnClickListener(v->eventDetails(eventId));}
    void addExistingStudentToEvent(long eventId){ArrayList<JSONObject> all=studentDb.search("");JSONObject ev=studentDb.getEvent(eventId);String audience=ev.optString("audience","Everyone");ArrayList<JSONObject> students=new ArrayList<>();for(JSONObject st:all){String stage=st.optString("stage","").toLowerCase(Locale.ROOT);boolean admitted=stage.contains("admission confirmed")||stage.contains("visa")||stage.contains("flight ticket")||stage.contains("accommodation")||stage.contains("arrived")||stage.contains("university reported");boolean inIndia=stage.contains("arrived")||stage.contains("university reported");boolean enquiry=!admitted;if(audience.equals("Enquiring students")&&!enquiry)continue;if(audience.equals("Admitted students")&&!admitted)continue;if(audience.equals("Students already in India")&&!inIndia)continue;if(audience.equals("Business partners / meeting guests")||audience.equals("Staff only"))continue;students.add(st);}if(students.isEmpty()){toast("No matching student records found for audience: "+audience+". You can register a guest manually.");return;}String[] labels=new String[students.size()];for(int i=0;i<students.size();i++)labels[i]=students.get(i).optString("name")+" • "+students.get(i).optString("student_id")+" • "+students.get(i).optString("phone");new AlertDialog.Builder(this).setTitle("Add an existing student to this event").setItems(labels,(dialog,which)->{JSONObject st=students.get(which);boolean duplicate=false;for(JSONObject p:studentDb.eventPeople(eventId)){if(p.optString("personal_id").equals(st.optString("student_id"))&&!st.optString("student_id").isEmpty())duplicate=true;}if(duplicate){toast("This student is already on the event list");return;}studentDb.addEventPerson(eventId,st.optString("name"),st.optString("phone"),st.optString("student_id"),"Not recorded","Registered","Linked from student records • Journey stage: "+st.optString("stage"));eventDetails(eventId);}).setNegativeButton("Cancel",null).show();}
    void addEventPerson(long eventId){base("Register Event Guest");EditText name=field("Full name *"),phone=field("Contact number"),pid=field("National ID / passport / other ID"),note=multiField("Notes, organisation, role or special requirements");content.addView(name);content.addView(phone);content.addView(pid);addText("Gender (optional)",12,purple);Spinner gender=new Spinner(this);gender.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Prefer not to say","Female","Male","Other"}));content.addView(gender);Button save=btn("Save guest registration");content.addView(save);save.setOnClickListener(v->{if(name.getText().toString().trim().isEmpty()){name.setError("Name is required");return;}String g=gender.getSelectedItem().toString();if(g.equals("Prefer not to say"))g="Not provided";studentDb.addEventPerson(eventId,name.getText().toString().trim(),phone.getText().toString().trim(),pid.getText().toString().trim(),g,"Registered",note.getText().toString().trim());eventDetails(eventId);});Button cancel=btn("Cancel");content.addView(cancel);cancel.setOnClickListener(v->eventDetails(eventId));}
    File generateEventDocument(JSONObject e,JSONObject person)throws Exception{
        boolean online=e.optString("delivery_mode","Physical").equals("Online");String docTitle=online?"ONLINE MEETING INVITATION":"EVENT GATE PASS";PdfDocument doc=new PdfDocument();PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());Canvas c=page.getCanvas();c.drawColor(Color.WHITE);Paint p=new Paint(3);p.setColor(purple);c.drawRect(0,0,595,125,p);p.setColor(Color.WHITE);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(19);c.drawText("GLOBAL MINDS EDUCATION",36,42,p);p.setTextSize(21);c.drawText(docTitle,36,82,p);p.setTextSize(10);c.drawText("Transforming Education • Empowering Futures",36,105,p);p.setColor(ink);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(13);float y=165;JSONObject linkedStudent=studentDb.getStudentByStudentId(person.optString("personal_id"));String eventPhoto=linkedStudent.optString("photo_uri");if(!eventPhoto.isEmpty()){try{Bitmap bm=BitmapFactory.decodeStream(getContentResolver().openInputStream(Uri.parse(eventPhoto)));if(bm!=null){Paint phPaint=new Paint(3);Rect src=new Rect(0,0,bm.getWidth(),bm.getHeight());Rect dst=new Rect(455,145,555,245);c.drawBitmap(bm,src,dst,phPaint);y=260;}}catch(Exception ignored){}}String[][] fields={{"EVENT",e.optString("title")},{"EVENT TYPE",e.optString("event_type","Community event")},{"PARTICIPANT",person.optString("name")},{"PARTICIPANT ID",person.optString("personal_id","Not provided")},{"CONTACT",person.optString("phone","Not provided")},{"EVENT DATE",eventDateTime(e.optLong("start_at"))},{"END TIME",eventDateTime(e.optLong("end_at"))},{online?"ONLINE MEETING LINK":"VENUE / ADDRESS",e.optString("venue","To be confirmed")},{"AUDIENCE",e.optString("audience","Everyone")},{"REGISTRATION STATUS",person.optString("status","Registered")}};for(String[] f:fields){p.setColor(purpleDark);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(10);c.drawText(f[0],40,y,p);p.setColor(ink);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setTextSize(12);String value=f[1]==null?"":f[1];for(String line:wrapText(value,68)){c.drawText(line,190,y,p);y+=17;}y+=8;}y+=5;p.setColor(purple);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(12);c.drawText(online?"MEETING INSTRUCTIONS":"GATE ENTRY INSTRUCTIONS",40,y,p);y+=22;p.setColor(ink);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setTextSize(10);String instruction=online?"Please join using the meeting link above at the scheduled time. Keep this invitation available for reference.":"Please present this pass to the event registration or security desk. Entry is subject to identity verification and the event organiser's confirmation.";for(String line:wrapText(instruction,90)){c.drawText(line,40,y,p);y+=16;}y+=22;p.setColor(Color.GRAY);p.setTextSize(8);c.drawText("Generated: "+dateTime(System.currentTimeMillis())+" • Issued for the named participant only",40,Math.min(810,y),p);doc.finishPage(page);File f=new File(getCacheDir(),"GME_Event_"+e.optLong("id")+"_"+safe(person.optString("name"))+"_"+(online?"Invitation":"GatePass")+".pdf");FileOutputStream out=new FileOutputStream(f);doc.writeTo(out);out.close();doc.close();return f;
    }
    File generateEventDocumentBundle(JSONObject e,ArrayList<JSONObject> people)throws Exception{if(people.isEmpty())throw new IllegalStateException("No registered people to generate documents for");File zip=new File(getCacheDir(),"GME_Event_"+e.optLong("id")+"_Documents.zip");java.util.zip.ZipOutputStream zos=new java.util.zip.ZipOutputStream(new FileOutputStream(zip));try{for(JSONObject person:people){ArrayList<File> docs=new ArrayList<>();if(e.optString("delivery_mode","Physical").equals("Hybrid")){JSONObject physical=new JSONObject(e.toString());physical.put("delivery_mode","Physical");docs.add(generateEventDocument(physical,person));JSONObject online=new JSONObject(e.toString());online.put("delivery_mode","Online");docs.add(generateEventDocument(online,person));}else docs.add(generateEventDocument(e,person));for(File pdf:docs){java.util.zip.ZipEntry entry=new java.util.zip.ZipEntry(pdf.getName());zos.putNextEntry(entry);FileInputStream in=new FileInputStream(pdf);byte[] buffer=new byte[4096];int n;while((n=in.read(buffer))>0)zos.write(buffer,0,n);in.close();zos.closeEntry();}}}finally{zos.close();}return zip;}
    ArrayList<String> wrapText(String text,int max){ArrayList<String> lines=new ArrayList<>();if(text==null||text.trim().isEmpty()){lines.add("Not provided");return lines;}for(String paragraph:text.split("\\n")){StringBuilder line=new StringBuilder();for(String word:paragraph.split("\\s+")){if(line.length()+word.length()+1>max&&line.length()>0){lines.add(line.toString());line.setLength(0);}if(line.length()>0)line.append(' ');line.append(word);}lines.add(line.toString());}return lines;}
    void scheduleEventReminder(long eventId,String titleText,long when){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},7301);if(when<System.currentTimeMillis())when=System.currentTimeMillis()+5000L;try{Intent i=new Intent(this,EventReminderReceiver.class);i.putExtra("title",titleText);i.putExtra("event_id",eventId);PendingIntent pi=PendingIntent.getBroadcast(this,(int)(eventId%Integer.MAX_VALUE),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);if(am!=null)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);toast("Reminder scheduled on this device");}catch(Exception ex){toast("Event saved; reminder could not be scheduled on this device");}}
    void ceoDashboard(){
        base("CEO Dashboard");int total=studentDb.countAll();double expected=studentDb.totalExpected(),paid=studentDb.totalPaid();
        addText("Organisation Overview",18,purple);addText("Total registered students: "+total,17,Color.DKGRAY);
        addText("Active applications / in progress: "+Math.max(0,total-studentDb.countStage("University Reported")),15,Color.DKGRAY);
        addText("Admission confirmed: "+studentDb.countStage("Admission confirmed"),15,Color.DKGRAY);
        addText("Awaiting university decision: "+studentDb.countStage("Application submitted"),15,Color.DKGRAY);
        addText("Preparing to travel: "+(studentDb.countStage("Visa Approved")+studentDb.countStage("Flight Ticket Booked")+studentDb.countStage("Accommodation Booked")),15,Color.DKGRAY);
        addGap();addText("Student Journey Distribution",17,purple);
        int[] journeyValues={studentDb.countStage("Enquiry received"),studentDb.countStage("Counselling completed"),studentDb.countStage("Programme guidance issued"),studentDb.countStage("Student undertaking signed"),studentDb.countStage("Application submitted"),studentDb.countStage("Accepted"),studentDb.countStage("University decision received"),studentDb.countStage("Admission confirmed"),studentDb.countStage("Visa Applied")+studentDb.countStage("Visa Approved"),studentDb.countStage("Flight Ticket Booked")+studentDb.countStage("Accommodation Booked"),studentDb.countStage("Arrived Airport")+studentDb.countStage("University Reported")};
        String[] journeyLabels={"Enquiry","Counselling","Guidance","Undertaking","Application","Accepted","Decision","Admitted","Visa","Travel prep","Arrived / reported"};
        chartCard("Students by current stage",new DataChart(DataChart.PIE,journeyLabels,journeyValues));
        addGap();addText("Admissions Growth",17,purple);ArrayList<JSONObject> monthly=studentDb.monthlyAdmissions();String[] months=new String[monthly.size()];int[] monthlyValues=new int[monthly.size()];for(int i=0;i<monthly.size();i++){months[i]=monthly.get(i).optString("month");monthlyValues[i]=monthly.get(i).optInt("total");}chartCard("New student records by month",new DataChart(DataChart.LINE,months,monthlyValues));
        addGap();addText("Programme Popularity",17,purple);ArrayList<JSONObject> popular=studentDb.popularProgrammes();String[] progs=new String[popular.size()];int[] progValues=new int[popular.size()];for(int i=0;i<popular.size();i++){progs[i]=popular.get(i).optString("programme");progValues[i]=popular.get(i).optInt("total");}chartCard("Top programmes by student count",new DataChart(DataChart.BAR,progs,progValues));ArrayList<JSONObject> progAdmissions=studentDb.programmeAdmissions();String[] paLabels=new String[progAdmissions.size()];int[] paValues=new int[progAdmissions.size()];for(int i=0;i<progAdmissions.size();i++){paLabels[i]=progAdmissions.get(i).optString("programme");paValues[i]=progAdmissions.get(i).optInt("admitted");}chartCard("Admissions by programme",new DataChart(DataChart.BAR,paLabels,paValues));
        addGap();addText("Student Nationality Intelligence",17,purple);ArrayList<JSONObject> nationalityRows=studentDb.nationalitySummary();String[] nationalityLabels=new String[nationalityRows.size()];int[] nationalityValues=new int[nationalityRows.size()];for(int ni=0;ni<nationalityRows.size();ni++){nationalityLabels[ni]=nationalityRows.get(ni).optString("nationality");nationalityValues[ni]=nationalityRows.get(ni).optInt("total");}chartCard("Registered students by nationality",new DataChart(DataChart.PIE,nationalityLabels,nationalityValues));
        addGap();addText("Events & Community Engagement",18,purple);int upcomingEvents=studentDb.eventCountByStatus("Upcoming"),completedEvents=studentDb.eventCountByStatus("Completed"),eventRegistered=studentDb.totalEventPeople("Registered"),eventConfirmed=studentDb.totalEventPeople("Confirmed"),eventAttended=studentDb.totalEventPeople("Attended"),eventAbsent=studentDb.totalEventPeople("Absent");addText("Events scheduled: "+upcomingEvents+" upcoming • "+completedEvents+" completed",15,Color.DKGRAY);addText("Guest pipeline: "+eventRegistered+" registered • "+eventConfirmed+" confirmed • "+eventAttended+" attended • "+eventAbsent+" marked absent",14,Color.DKGRAY);double attendanceRate=(eventAttended+eventAbsent)>0?100.0*eventAttended/(eventAttended+eventAbsent):0;addText("Attendance rate among guests marked attended or absent: "+String.format(Locale.US,"%.1f%%",attendanceRate),14,purpleDark);chartCard("Event portfolio",new DataChart(DataChart.PIE,new String[]{"Upcoming","Completed"},new int[]{upcomingEvents,completedEvents}));chartCard("Event guest funnel",new DataChart(DataChart.BAR,new String[]{"Registered","Confirmed","Attended","Absent"},new int[]{eventRegistered,eventConfirmed,eventAttended,eventAbsent}));
        addGap();addText("Financial Snapshot (USD records)",18,purple);addText("Expected / recorded fees: "+money(expected),15,Color.DKGRAY);addText("Payments recorded: "+money(paid),15,Color.DKGRAY);addText("Outstanding balance: "+money(Math.max(0,expected-paid)),15,Color.DKGRAY);
        chartCard("Expected fees vs payments vs balance",new DataChart(DataChart.BAR,new String[]{"Expected","Paid","Pending"},new int[]{safeChartInt(expected),safeChartInt(paid),safeChartInt(Math.max(0,expected-paid))}));
        addGap();addText("Charts use records saved on this device. Add or update student records to refresh the dashboard. Financial chart values are rounded to whole USD for visual comparison.",12,Color.GRAY);Button back=btn("← Home");content.addView(back);back.setOnClickListener(v->dashboard());
    }
    int safeChartInt(double v){return (int)Math.min(1000000000,Math.max(0,Math.round(v)));}
    int chartTextColor(){return darkMode?Color.rgb(242,238,248):ink;}
    int chartMutedColor(){return darkMode?Color.rgb(190,182,204):Color.rgb(105,98,113);}
    int chartGridColor(){return darkMode?Color.rgb(76,69,88):Color.rgb(225,218,233);}
    int chartSurfaceColor(){return darkMode?Color.rgb(35,32,41):Color.WHITE;}
    void chartCard(String heading,DataChart chart){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(12),dp(10),dp(12),dp(12));card.setBackground(shape(chartSurfaceColor(),darkMode?Color.rgb(82,72,96):Color.rgb(232,225,239)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(8));card.setLayoutParams(lp);TextView h=new TextView(this);h.setText(heading);h.setTextSize(13);h.setTextColor(chartTextColor());h.setTypeface(null,1);card.addView(h);int wide=Math.max(getResources().getDisplayMetrics().widthPixels-dp(72),dp(Math.max(340,chart.labels.length*92)));HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(true);hs.setFillViewport(false);ChartView cv=new ChartView(chart);cv.setBackgroundColor(chartSurfaceColor());hs.addView(cv,new HorizontalScrollView.LayoutParams(wide,dp(chart.type==DataChart.PIE?290:245)));card.addView(hs);TextView hint=new TextView(this);hint.setText("Swipe horizontally for more data  •  Tap to expand");hint.setTextSize(10);hint.setTextColor(chartMutedColor());hint.setPadding(0,dp(5),0,0);card.addView(hint);card.setOnClickListener(v->showExpandedChart(heading,chart));content.addView(card);}
    void showExpandedChart(String heading,DataChart chart){int wide=Math.max(getResources().getDisplayMetrics().widthPixels-dp(56),dp(Math.max(420,chart.labels.length*112)));HorizontalScrollView hs=new HorizontalScrollView(this);hs.setFillViewport(false);ChartView cv=new ChartView(chart);cv.setBackgroundColor(chartSurfaceColor());hs.addView(cv,new HorizontalScrollView.LayoutParams(wide,dp(chart.type==DataChart.PIE?420:390)));new AlertDialog.Builder(this).setTitle(heading).setView(hs).setPositiveButton("Close",null).show();}
    class DataChart{static final int PIE=0,BAR=1,LINE=2;int type;String[] labels;int[] values;DataChart(int t,String[] l,int[] v){type=t;labels=l==null?new String[0]:l;values=v==null?new int[0]:v;int n=Math.min(labels.length,values.length);if(n!=labels.length)labels=Arrays.copyOf(labels,n);if(n!=values.length)values=Arrays.copyOf(values,n);}}
    class ChartView extends View{
        DataChart data;Paint p=new Paint(3);int[] palette={Color.rgb(91,42,134),Color.rgb(135,84,177),Color.rgb(184,145,213),Color.rgb(92,139,185),Color.rgb(73,157,143),Color.rgb(231,167,80),Color.rgb(211,104,126),Color.rgb(100,112,139),Color.rgb(166,184,111),Color.rgb(196,174,145)};
        ChartView(DataChart d){super(MainActivity.this);data=d;setLayerType(View.LAYER_TYPE_SOFTWARE,null);setWillNotDraw(false);setMinimumWidth(dp(Math.max(340,d.labels.length*92)));setMinimumHeight(dp(d.type==DataChart.PIE?290:245));setBackgroundColor(chartSurfaceColor());}
        @Override protected void onMeasure(int widthMeasureSpec,int heightMeasureSpec){int desiredW=dp(Math.max(340,data.labels.length*92));int desiredH=dp(data.type==DataChart.PIE?290:245);int w=MeasureSpec.getMode(widthMeasureSpec)==MeasureSpec.EXACTLY?MeasureSpec.getSize(widthMeasureSpec):resolveSize(desiredW,widthMeasureSpec);int h=MeasureSpec.getMode(heightMeasureSpec)==MeasureSpec.EXACTLY?MeasureSpec.getSize(heightMeasureSpec):resolveSize(desiredH,heightMeasureSpec);setMeasuredDimension(Math.max(dp(240),w),Math.max(dp(180),h));}
        protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setTextSize(dp(10));p.setColor(chartMutedColor());if(data.labels.length==0||data.values.length==0){c.drawText("Add student records to see chart data.",dp(10),dp(30),p);return;}if(data.type==DataChart.PIE)drawPie(c,w,h);else if(data.type==DataChart.BAR)drawBars(c,w,h);else drawLine(c,w,h);}
        void drawPie(Canvas c,float w,float h){int total=0;for(int v:data.values)total+=v;if(total<=0){p.setColor(chartMutedColor());c.drawText("No student data available yet.",dp(10),dp(28),p);return;}float size=Math.min(dp(150),h*.56f),cx=w/2,cy=size/2+dp(12),r=size/2;float start=-90;for(int i=0;i<data.values.length;i++){if(data.values[i]<=0)continue;p.setColor(palette[i%palette.length]);c.drawArc(cx-r,cy-r,cx+r,cy+r,start,start+360f*data.values[i]/total,true,p);start+=360f*data.values[i]/total;}float y=size+dp(26),left=dp(4),colw=(w-dp(8))/2;for(int i=0;i<data.values.length;i++){if(i>=10)break;int col=i%2,row=i/2;float x=left+col*colw,yy=y+row*dp(20);p.setColor(palette[i%palette.length]);c.drawRoundRect(x,yy-dp(8),x+dp(9),yy+dp(1),dp(2),dp(2),p);p.setColor(chartTextColor());p.setTextSize(dp(10));String label=data.labels[i]+": "+data.values[i];if(label.length()>27)label=label.substring(0,26)+"…";c.drawText(label,x+dp(14),yy,p);}}
        void drawBars(Canvas c,float w,float h){int max=1;for(int v:data.values)max=Math.max(max,v);float left=dp(12),right=w-dp(12),top=dp(14),bottom=h-dp(48),available=Math.max(dp(10),bottom-top);p.setColor(chartGridColor());c.drawLine(left,bottom,right,bottom,p);int n=data.values.length;float slot=(right-left)/Math.max(1,n),bw=Math.min(dp(34),slot*.55f);for(int i=0;i<n;i++){float bh=available*data.values[i]/max,x=left+i*slot+(slot-bw)/2;p.setColor(palette[i%palette.length]);c.drawRoundRect(x,bottom-bh,x+bw,bottom,dp(4),dp(4),p);p.setColor(chartTextColor());p.setTextSize(dp(10));String val=String.valueOf(data.values[i]);c.drawText(val,x+bw/2-p.measureText(val)/2,bottom-bh-dp(5),p);String label=data.labels[i]==null?"":data.labels[i];if(label.length()>12)label=label.substring(0,11)+"…";c.save();c.rotate(-30,x+bw/2,bottom+dp(15));c.drawText(label,x+bw/2-p.measureText(label)/2,bottom+dp(15),p);c.restore();}}
        void drawLine(Canvas c,float w,float h){int max=1;for(int v:data.values)max=Math.max(max,v);float left=dp(24),right=w-dp(18),top=dp(22),bottom=h-dp(44),usable=Math.max(dp(10),bottom-top);p.setColor(chartGridColor());p.setStrokeWidth(dp(1));for(int g=0;g<4;g++){float y=top+usable*g/3f;c.drawLine(left,y,right,y,p);}if(data.values.length==1){p.setColor(palette[0]);c.drawCircle((left+right)/2,bottom-usable*data.values[0]/max,dp(5),p);}else if(data.values.length>1){float slot=(right-left)/(data.values.length-1);p.setColor(purple);p.setStrokeWidth(dp(2.5f));for(int i=0;i<data.values.length-1;i++){float x1=left+i*slot,y1=bottom-usable*data.values[i]/max,x2=left+(i+1)*slot,y2=bottom-usable*data.values[i+1]/max;c.drawLine(x1,y1,x2,y2,p);}for(int i=0;i<data.values.length;i++){float x=left+i*slot,y=bottom-usable*data.values[i]/max;p.setColor(palette[0]);c.drawCircle(x,y,dp(4),p);p.setColor(chartTextColor());p.setTextSize(dp(10));c.drawText(String.valueOf(data.values[i]),x-dp(5),y-dp(8),p);}}int n=data.labels.length;for(int i=0;i<n;i++){float x=n<=1?(left+right)/2:left+i*(right-left)/(n-1);String label=data.labels[i]==null?"":data.labels[i];if(label.length()>7)label=label.substring(0,7);p.setColor(chartMutedColor());p.setTextSize(dp(9));c.drawText(label,x-p.measureText(label)/2,bottom+dp(22),p);}}
    }
    String money(double amount){return String.format(Locale.US,"USD %.2f",amount);}

    long paymentDeadlineMillis(String raw){
        if(raw==null||raw.trim().isEmpty())return 0;
        String[] patterns={"yyyy-MM-dd","dd MMM yyyy","d MMM yyyy","dd/MM/yyyy","d/M/yyyy"};
        for(String pattern:patterns)try{
            SimpleDateFormat f=new SimpleDateFormat(pattern,Locale.ENGLISH);f.setLenient(false);f.setTimeZone(TimeZone.getDefault());
            Date parsed=f.parse(raw.trim());if(parsed==null)continue;
            Calendar local=Calendar.getInstance();local.setTime(parsed);
            Calendar utc=new GregorianCalendar(TimeZone.getTimeZone("UTC"),Locale.US);utc.clear();
            utc.set(local.get(Calendar.YEAR),local.get(Calendar.MONTH),local.get(Calendar.DAY_OF_MONTH),0,0,0);
            return utc.getTimeInMillis();
        }catch(Exception ignored){}
        return 0;
    }
    int deadlineDays(long due){
        Calendar nowLocal=Calendar.getInstance();Calendar todayUtc=new GregorianCalendar(TimeZone.getTimeZone("UTC"),Locale.US);todayUtc.clear();
        todayUtc.set(nowLocal.get(Calendar.YEAR),nowLocal.get(Calendar.MONTH),nowLocal.get(Calendar.DAY_OF_MONTH),0,0,0);
        return (int)Math.floorDiv(due-todayUtc.getTimeInMillis(),86400000L);
    }

    static int paymentAlertRequestCode(long studentId,int leadDays){return (int)((studentId*37L+leadDays*13L)&0x7fffffff);}
    void requestPaymentNotificationPermission(){
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED){
            try{requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},7312);}catch(Exception ignored){}
        }
    }
    void cancelPaymentDeadlineAlerts(long studentId){
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);if(am==null)return;
        for(int lead:new int[]{7,1})try{
            Intent i=new Intent(this,PaymentDeadlineReceiver.class);i.setAction("com.globalminds.admission.PAYMENT_DEADLINE");
            PendingIntent pi=PendingIntent.getBroadcast(this,paymentAlertRequestCode(studentId,lead),i,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);
            if(pi!=null){am.cancel(pi);pi.cancel();}
        }catch(Exception ignored){}
    }
    void schedulePaymentDeadlineAlerts(JSONObject student){
        if(student==null)return;long id=student.optLong("id");if(id<=0)return;cancelPaymentDeadlineAlerts(id);
        String stage=student.optString("stage","");double remaining=Math.max(0,student.optDouble("expected_amount")-studentDb.paid(id));
        long due=paymentDeadlineMillis(student.optString("due_date"));
        if(!"ACTIVE".equalsIgnoreCase(student.optString("record_status","ACTIVE"))||studentDb.stageIndex(stage)<studentDb.stageIndex("Accepted")||remaining<=0||due<=0)return;
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);if(am==null)return;
        for(int lead:new int[]{7,1}){
            long trigger=due-lead*86400000L+9L*60L*60L*1000L;
            if(trigger<=System.currentTimeMillis())continue;
            Intent i=new Intent(this,PaymentDeadlineReceiver.class);i.setAction("com.globalminds.admission.PAYMENT_DEADLINE");
            i.putExtra("student_id",id);i.putExtra("student_name",student.optString("name"));i.putExtra("student_code",student.optString("student_id"));i.putExtra("due_date",student.optString("due_date"));i.putExtra("lead_days",lead);i.putExtra("remaining",remaining);
            PendingIntent pi=PendingIntent.getBroadcast(this,paymentAlertRequestCode(id,lead),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            try{am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,trigger,pi);}catch(SecurityException ignored){}
        }
    }
    void syncAllPaymentDeadlineAlerts(){
        if(studentDb==null)return;
        for(JSONObject st:studentDb.financeRows())schedulePaymentDeadlineAlerts(st);
    }
    String deadlineGroup(int days){if(days<0)return "OVERDUE";if(days==0)return "DUE TODAY";if(days==1)return "DUE TOMORROW";if(days<=7)return "DUE WITHIN 7 DAYS";return "ON TRACK";}
    ArrayList<JSONObject> deadlineRows(){ArrayList<JSONObject> rows=new ArrayList<>();for(JSONObject st:studentDb.financeRows()){String stage=st.optString("stage","");if(studentDb.stageIndex(stage)<studentDb.stageIndex("Accepted"))continue;double remaining=Math.max(0,st.optDouble("expected_amount")-studentDb.paid(st.optLong("id")));if(remaining<=0)continue;long due=paymentDeadlineMillis(st.optString("due_date"));if(due<=0)continue;try{st.put("remaining",remaining);st.put("due_millis",due);st.put("days_left",deadlineDays(due));st.put("deadline_group",deadlineGroup(deadlineDays(due)));st.put("followup",studentDb.getFollowup(st.optLong("id")));rows.add(st);}catch(Exception ignored){}}Collections.sort(rows,(a,b)->Long.compare(a.optLong("due_millis"),b.optLong("due_millis")));return rows;}
    void paymentDeadlines(){base("Payment Deadline Management");setRefreshAction(()->paymentDeadlines());ArrayList<JSONObject> rows=deadlineRows();int overdue=0,tomorrow=0,week=0,ontrack=0,today=0;double overdueAmt=0,tomorrowAmt=0,weekAmt=0;for(JSONObject st:rows){int d=st.optInt("days_left");if(d<0){overdue++;overdueAmt+=st.optDouble("remaining");}else if(d==0)today++;else if(d==1){tomorrow++;tomorrowAmt+=st.optDouble("remaining");}else if(d<=7){week++;weekAmt+=st.optDouble("remaining");}else ontrack++;}
        addText("Accepted students with outstanding balances, grouped by recorded payment deadline.",13,Color.DKGRAY);
        addText("FOLLOW-UP ALERTS",12,purple);
        if(tomorrow>0)addText("⚠️ 1-DAY NOTICE: "+tomorrow+" student(s) have payment deadlines tomorrow. Outstanding: "+money(tomorrowAmt),16,Color.rgb(176,55,30));
        if(week>0)addText("🔔 7-DAY NOTICE: "+week+" student(s) have payment deadlines within the next 7 days. Outstanding: "+money(weekAmt),16,Color.rgb(160,100,10));
        if(overdue>0)addText("🚨 OVERDUE: "+overdue+" student(s) require immediate follow-up. Outstanding: "+money(overdueAmt),16,Color.rgb(176,35,35));
        if(tomorrow+week+overdue==0)addText("No urgent payment deadline follow-ups at this time.",14,Color.rgb(35,125,70));
        chartCard("Students by payment deadline group",new DataChart(DataChart.PIE,new String[]{"Overdue","Due today","Tomorrow","Within 7 days","On track"},new int[]{overdue,today,tomorrow,week,ontrack}));
        chartCard("Outstanding balance by urgency (USD)",new DataChart(DataChart.BAR,new String[]{"Overdue","Tomorrow","Within 7 days"},new int[]{safeChartInt(overdueAmt),safeChartInt(tomorrowAmt),safeChartInt(weekAmt)}));
        addText("STUDENT FOLLOW-UP LIST",18,purple);
        final String[] groups={"All","OVERDUE","DUE TODAY","DUE TOMORROW","DUE WITHIN 7 DAYS","ON TRACK"};final int[] selected={0};LinearLayout chips=new LinearLayout(this);chips.setOrientation(LinearLayout.VERTICAL);content.addView(chips);LinearLayout followups=new LinearLayout(this);followups.setOrientation(LinearLayout.VERTICAL);content.addView(followups);int[] groupCounts=new int[groups.length];for(JSONObject st:rows){int gi=Arrays.asList(groups).indexOf(st.optString("deadline_group"));if(gi>0)groupCounts[gi]++;}groupCounts[0]=rows.size();final Runnable[] render={null};render[0]=()->{followups.removeAllViews();chips.removeAllViews();horizontalFilterChips(chips,groups,groupCounts,selected[0],ix->{selected[0]=ix;if(render[0]!=null)render[0].run();});int shown=0;for(JSONObject st:rows){String g=st.optString("deadline_group");if(selected[0]!=0&&!groups[selected[0]].equals(g))continue;shown++;JSONObject f=st.optJSONObject("followup");String status=f==null?"Not Contacted":f.optString("status","Not Contacted");Button item=btn(st.optString("name")+" • "+st.optString("student_id")+"\nDeadline: "+st.optString("due_date")+" ("+(st.optInt("days_left")<0?Math.abs(st.optInt("days_left"))+" day(s) overdue":st.optInt("days_left")+" day(s) left")+")\nOutstanding: "+money(st.optDouble("remaining"))+"\nFollow-up: "+status+"\n"+st.optString("phone"));item.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);followups.addView(item);item.setOnClickListener(v->deadlineFollowup(st));}if(shown==0)addTextToContainer(followups,"No students in this deadline group.",14,Color.GRAY);};render[0].run();
        Button back=btn("← Finance Dashboard");content.addView(back);back.setOnClickListener(v->financialDashboard());}
    void deadlineFollowup(JSONObject st){long id=st.optLong("id");JSONObject f=studentDb.getFollowup(id);LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(22,8,22,8);Spinner status=new Spinner(this);String[] statuses={"Not Contacted","Contacted","Awaiting Response","Payment Promised","Paid","Escalate"};status.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,statuses));for(int i=0;i<statuses.length;i++)if(statuses[i].equals(f.optString("status")))status.setSelection(i);EditText next=field("Next follow-up date (e.g. 12 Nov 2026)");next.setText(f.optString("next_followup_date",""));EditText notes=field("Follow-up notes");notes.setText(f.optString("notes",""));EditText actor=field("Staff name / ID");actor.setText(f.optString("actor",""));form.addView(status);form.addView(next);form.addView(notes);form.addView(actor);new AlertDialog.Builder(this).setTitle("Payment follow-up • "+st.optString("name")).setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save follow-up",(d,w)->{if(actor.getText().toString().trim().isEmpty()){toast("Enter staff name / ID");return;}studentDb.saveFollowup(id,status.getSelectedItem().toString(),next.getText().toString().trim(),notes.getText().toString().trim(),actor.getText().toString().trim());studentDb.audit("PAYMENT_FOLLOWUP",String.valueOf(id),"Payment follow-up updated","",status.getSelectedItem().toString(),notes.getText().toString().trim(),actor.getText().toString().trim());toast("Follow-up saved");paymentDeadlines();}).show();}

    void requestFinanceAccess(Runnable onSuccess){
        if(biometricAvailable()){
            new AlertDialog.Builder(this).setTitle("🔐 Finance Dashboard Security").setMessage("Authenticate before viewing confidential financial records.").setPositiveButton("Use fingerprint / face",(d,w)->startFinanceBiometric(onSuccess)).setNegativeButton("Use app password",(d,w)->showFinancePasswordDialog(onSuccess)).setNeutralButton("Cancel",null).show();
        }else showFinancePasswordDialog(onSuccess);
    }
    void startFinanceBiometric(Runnable onSuccess){
        showingBiometric=true;BiometricPrompt prompt=new BiometricPrompt(this,ContextCompat.getMainExecutor(this),new BiometricPrompt.AuthenticationCallback(){
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result){showingBiometric=false;onSuccess.run();}
            @Override public void onAuthenticationFailed(){toast("Biometric not recognised. Try again or use your app password.");}
            @Override public void onAuthenticationError(int code,CharSequence message){showingBiometric=false;if(code!=BiometricPrompt.ERROR_USER_CANCELED&&code!=BiometricPrompt.ERROR_CANCELED)toast("Biometric unavailable. Reopen Finance and choose app password.");}
        });
        BiometricPrompt.PromptInfo info=new BiometricPrompt.PromptInfo.Builder().setTitle("Unlock Finance Dashboard").setSubtitle("Confirm your identity to view financial information").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK).setNegativeButtonText("Cancel").build();
        try{prompt.authenticate(info);}catch(Exception e){showingBiometric=false;showFinancePasswordDialog(onSuccess);}
    }
    void showFinancePasswordDialog(Runnable onSuccess){
        EditText pass=passwordField("Enter GlobalMinds app password");LinearLayout box=new LinearLayout(this);box.setPadding(dp(20),dp(8),dp(20),0);box.addView(pass);AlertDialog dialog=new AlertDialog.Builder(this).setTitle("🔐 Finance Dashboard Password").setMessage("Enter your app password to access confidential finance records.").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Unlock",null).create();dialog.setOnShowListener(v->{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(w->{try{if(verifyPassword(pass.getText().toString())){dialog.dismiss();onSuccess.run();}else{pass.setError("Incorrect password");pass.setText("");}}catch(Exception e){pass.setError("Unable to verify password");}});});dialog.show();
    }
    void financialDashboard(){requestFinanceAccess(()->showFinancialDashboard());}
    void showFinancialDashboard(){base("Financial Dashboard");setRefreshAction(()->financialDashboard());double expected=studentDb.totalExpected(),paid=studentDb.totalPaid();addText("Recorded expected fees: "+money(expected),18,purple);addText("Total payments recorded: "+money(paid),17,Color.DKGRAY);addText("Pending balance: "+money(Math.max(0,expected-paid)),17,Color.DKGRAY);Button add=btn("➕ Find Student / Record Payment");content.addView(add);add.setOnClickListener(v->students());addGap();double pending=Math.max(0,expected-paid);chartCard("Payments received vs remaining balance (USD)",new DataChart(DataChart.PIE,new String[]{"Paid","Pending"},new int[]{safeChartInt(paid),safeChartInt(pending)}));chartCard("Expected fees compared with payments (USD)",new DataChart(DataChart.BAR,new String[]{"Expected","Paid","Pending"},new int[]{safeChartInt(expected),safeChartInt(paid),safeChartInt(pending)}));ArrayList<JSONObject> paymentMonths=studentDb.monthlyPayments();String[] paymentLabels=new String[paymentMonths.size()];int[] paymentValues=new int[paymentMonths.size()];for(int i=0;i<paymentMonths.size();i++){paymentLabels[i]=paymentMonths.get(i).optString("month");paymentValues[i]=paymentMonths.get(i).optInt("total");}chartCard("Payments recorded by month (USD)",new DataChart(DataChart.LINE,paymentLabels,paymentValues));addGap();addText("Student Accounts",18,purple);for(JSONObject st:studentDb.financeRows()){long id=st.optLong("id");double ex=st.optDouble("expected_amount"),pd=studentDb.paid(id);Button b=btn(st.optString("name")+" • "+st.optString("student_id")+"\nJourney: "+st.optString("stage","Enquiry received")+"\nExpected: "+money(ex)+" | Paid: "+money(pd)+" | Pending: "+money(Math.max(0,ex-pd))+"\nDeadline: "+(st.optString("due_date").isEmpty()?"Not set":st.optString("due_date")));b.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);content.addView(b);b.setOnClickListener(v->studentFinance(st));}Button back=btn("← Home");content.addView(back);back.setOnClickListener(v->dashboard());}
    void studentFinance(JSONObject st){requestFinanceAccess(()->showStudentFinance(st));}
    void showStudentFinance(JSONObject st){long id=st.optLong("id");JSONObject fresh=studentDb.getStudent(id);base("Student Finance");setRefreshAction(()->studentFinance(studentDb.getStudent(id)));pinStudentContext(fresh);addReferralStamp(content,fresh.optString("referred_by"));addText(fresh.optString("name")+" • "+fresh.optString("student_id"),18,purple);double expected=fresh.optDouble("expected_amount"),paid=studentDb.paid(id);addText("Expected amount: "+money(expected),15,Color.DKGRAY);addText("Paid: "+money(paid),15,Color.DKGRAY);addText("Pending: "+money(Math.max(0,expected-paid)),15,Color.DKGRAY);addText("Payment deadline: "+(fresh.optString("due_date").isEmpty()?"Not set":fresh.optString("due_date")),14,Color.GRAY);Button set=btn("Set Expected Amount and Deadline");content.addView(set);set.setOnClickListener(v->editExpected(id,expected,fresh.optString("due_date")));Button payment=btn("Record Payment");content.addView(payment);payment.setOnClickListener(v->recordPayment(id));Button invoice=btn("Generate Invoice");content.addView(invoice);invoice.setOnClickListener(v->generateSimpleDoc(fresh,"Invoice"));Button receipt=btn("Generate Payment Receipt");content.addView(receipt);receipt.setOnClickListener(v->generateSimpleDoc(fresh,"Payment Receipt"));Button history=btn("Payment History • Edit / Reverse");content.addView(history);history.setOnClickListener(v->paymentHistory(id));Button back=btn("← Financial Dashboard");content.addView(back);back.setOnClickListener(v->financialDashboard());}
    void editExpected(long id,double current,String due){
        LinearLayout form=new LinearLayout(this);form.setPadding(24,8,24,8);form.setOrientation(LinearLayout.VERTICAL);
        EditText amount=field("Expected amount in USD");amount.setInputType(8194);amount.setText(current==0?"":String.valueOf(current));
        TextView deadlineValue=new TextView(this);deadlineValue.setTextColor(ink);deadlineValue.setTextSize(15);deadlineValue.setPadding(dp(12),dp(12),dp(12),dp(12));deadlineValue.setBackground(shape(Color.WHITE,Color.rgb(225,216,234)));
        String initialDue=due==null?"":due.trim();long initialMillis=paymentDeadlineMillis(initialDue);final Calendar selected=Calendar.getInstance();
        if(initialMillis>0){selected.setTimeInMillis(initialMillis);deadlineValue.setText(new SimpleDateFormat("dd MMM yyyy",Locale.ENGLISH).format(selected.getTime()));}else deadlineValue.setText("No payment deadline selected");
        Button chooseDate=btn("Choose payment deadline");form.addView(amount);form.addView(new TextView(this){{setText("PAYMENT DEADLINE");setTextColor(purple);setTextSize(12);setPadding(0,dp(8),0,dp(4));}});form.addView(deadlineValue);form.addView(chooseDate);
        chooseDate.setOnClickListener(v->{Calendar now=Calendar.getInstance();new DatePickerDialog(this,(picker,y,m,d)->{selected.set(y,m,d,0,0,0);selected.set(Calendar.MILLISECOND,0);deadlineValue.setText(new SimpleDateFormat("dd MMM yyyy",Locale.ENGLISH).format(selected.getTime()));},selected.get(Calendar.YEAR),selected.get(Calendar.MONTH),selected.get(Calendar.DAY_OF_MONTH)).show();});
        EditText reason=field("Reason for change (required)");EditText actor=field("Your name / staff ID (required)");form.addView(reason);form.addView(actor);
        new AlertDialog.Builder(this).setTitle("Student account settings").setMessage("Select the actual payment deadline. This date drives the Finance deadline groups, analysis and reminders.").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{try{
            double value=Double.parseDouble(amount.getText().toString().trim());if(value<0)throw new Exception("Enter a valid amount");
            if(deadlineValue.getText().toString().startsWith("No payment"))throw new Exception("Select the student's payment deadline using the calendar");
            if(reason.getText().toString().trim().isEmpty()||actor.getText().toString().trim().isEmpty())throw new Exception("Enter your name and reason");
            String savedDue=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(selected.getTime());JSONObject before=new JSONObject();before.put("expected_amount",current);before.put("due_date",due);
            JSONObject after=new JSONObject();after.put("expected_amount",value);after.put("due_date",savedDue);studentDb.setExpected(id,value,savedDue);
            schedulePaymentDeadlineAlerts(studentDb.getStudent(id));
            studentDb.audit("STUDENT_FINANCE",String.valueOf(id),"Expected amount / deadline changed",before.toString(),after.toString(),reason.getText().toString().trim(),actor.getText().toString().trim());
            toast("Student account and payment deadline updated");studentFinance(studentDb.getStudent(id));
        }catch(Exception e){toast(e.getMessage()==null?"Enter a valid non-negative amount":e.getMessage());}}).show();
    }
    void paymentHistory(long studentId){JSONObject st=studentDb.getStudent(studentId);base("Payment History & Corrections");pinStudentContext(st);addText(st.optString("name")+" • "+st.optString("student_id"),17,purple);addText("Active payments contribute to the balance. Reversed entries remain visible for audit purposes but do not count toward totals.",12,Color.GRAY);ArrayList<JSONObject> payments=studentDb.paymentsForStudent(studentId);if(payments.isEmpty())addText("No payments recorded.",14,Color.GRAY);for(JSONObject pay:payments){String status=pay.optString("status","ACTIVE");Button b=btn("Payment #"+pay.optLong("id")+" • "+money(pay.optDouble("amount"))+" "+pay.optString("currency")+"\n"+dateText(pay.optLong("payment_date"))+" • "+pay.optString("method")+"\nReference: "+pay.optString("transaction_reference")+" • "+status);b.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);content.addView(b);b.setOnClickListener(v->{if(!"ACTIVE".equals(status)){toast("This payment is already reversed and cannot be edited.");return;}String[] opts={"Edit / correct payment","Void / reverse payment"};new AlertDialog.Builder(this).setTitle("Payment #"+pay.optLong("id")).setItems(opts,(d,w)->{if(w==0)editPaymentDialog(studentId,pay);else reversePaymentDialog(studentId,pay);}).setNegativeButton("Cancel",null).show();});}Button log=btn("View Activity & Audit Log");content.addView(log);log.setOnClickListener(v->showStudentAudit(studentId));Button back=btn("← Student Finance");content.addView(back);back.setOnClickListener(v->studentFinance(studentDb.getStudent(studentId)));}
    void editPaymentDialog(long studentId,JSONObject pay){LinearLayout f=new LinearLayout(this);f.setPadding(24,8,24,8);f.setOrientation(LinearLayout.VERTICAL);EditText amount=field("Amount");amount.setInputType(8194);amount.setText(String.valueOf(pay.optDouble("amount")));EditText date=field("Payment date (dd MMM yyyy)");date.setText(dateText(pay.optLong("payment_date")));EditText currency=field("Currency");currency.setText(pay.optString("currency","USD"));EditText method=field("Payment method");method.setText(pay.optString("method"));EditText reference=field("Transaction reference");reference.setText(pay.optString("transaction_reference"));EditText note=multiField("Notes");note.setText(pay.optString("note"));EditText reason=multiField("Reason for correction (required)");EditText actor=field("Your name / staff ID (required)");for(View v:new View[]{amount,date,currency,method,reference,note,reason,actor})f.addView(v);new AlertDialog.Builder(this).setTitle("Correct payment #"+pay.optLong("id")).setMessage("A correction is audited. If a receipt exists, it will be marked SUPERSEDED; generate a corrected receipt afterwards.").setView(f).setNegativeButton("Cancel",null).setPositiveButton("Review correction",(d,w)->{try{double val=Double.parseDouble(amount.getText().toString().trim());if(val<=0)throw new Exception("Amount must be positive");if(reason.getText().toString().trim().isEmpty()||actor.getText().toString().trim().isEmpty())throw new Exception("Enter your name and a reason");Date parsed=new SimpleDateFormat("dd MMM yyyy",Locale.ENGLISH).parse(date.getText().toString().trim());if(parsed==null)throw new Exception("Invalid date");JSONObject before=studentDb.payment(pay.optLong("id"));JSONObject after=new JSONObject();after.put("id",pay.optLong("id"));after.put("student_row_id",studentId);after.put("amount",val);after.put("currency",currency.getText().toString().trim().toUpperCase(Locale.US));after.put("payment_date",parsed.getTime());after.put("method",method.getText().toString().trim());after.put("transaction_reference",reference.getText().toString().trim());after.put("note",note.getText().toString().trim());boolean dateChanged=before.optLong("payment_date")!=parsed.getTime();boolean amountChanged=Math.abs(before.optDouble("amount")-val)>0.0001;boolean refChanged=!before.optString("transaction_reference").equals(reference.getText().toString().trim());String impact=(amountChanged||dateChanged||refChanged)?"Important financial fields are changing. Confirm this correction?":"Confirm these payment corrections?";new AlertDialog.Builder(this).setTitle("Confirm payment correction").setMessage(impact+"\n\nOriginal: "+money(before.optDouble("amount"))+" on "+dateText(before.optLong("payment_date"))+"\nNew: "+money(val)+" on "+dateText(parsed.getTime())+"\nReason: "+reason.getText().toString().trim()).setNegativeButton("Go back",null).setPositiveButton("Confirm & Save",(dd,ww)->{studentDb.updatePayment(pay.optLong("id"),val,parsed.getTime(),currency.getText().toString().trim().toUpperCase(Locale.US),method.getText().toString().trim(),reference.getText().toString().trim(),note.getText().toString().trim());boolean receipt=studentDb.hasReceipts(pay.optLong("id"));if(receipt)studentDb.supersedeReceipts(pay.optLong("id"));studentDb.audit("PAYMENT",String.valueOf(pay.optLong("id")),"Payment corrected",before.toString(),after.toString(),reason.getText().toString().trim()+(receipt?" | Existing receipt marked SUPERSEDED; generate corrected receipt":""),actor.getText().toString().trim());schedulePaymentDeadlineAlerts(studentDb.getStudent(studentId));toast(receipt?"Payment corrected. Previous receipt is superseded; generate a corrected receipt.":"Payment corrected and audit history saved.");studentFinance(studentDb.getStudent(studentId));}).show();}catch(Exception ex){toast("Correction not saved: "+ex.getMessage());}}).show();}
    void reversePaymentDialog(long studentId,JSONObject pay){LinearLayout f=new LinearLayout(this);f.setPadding(24,8,24,8);f.setOrientation(LinearLayout.VERTICAL);EditText reason=multiField("Reason for void / reversal (required)");EditText actor=field("Your name / staff ID (required)");f.addView(reason);f.addView(actor);new AlertDialog.Builder(this).setTitle("Void / reverse payment #"+pay.optLong("id")).setMessage("This removes the amount from active totals but preserves the original entry and audit trail.").setView(f).setNegativeButton("Cancel",null).setPositiveButton("Review",(d,w)->{if(reason.getText().toString().trim().isEmpty()||actor.getText().toString().trim().isEmpty()){toast("Enter your name and a reason");return;}new AlertDialog.Builder(this).setTitle("Confirm reversal").setMessage("Reverse "+money(pay.optDouble("amount"))+"? This will recalculate the student's balance.").setNegativeButton("Cancel",null).setPositiveButton("Confirm reversal",(dd,ww)->{JSONObject before=studentDb.payment(pay.optLong("id"));studentDb.reversePayment(pay.optLong("id"));boolean receipt=studentDb.hasReceipts(pay.optLong("id"));if(receipt)studentDb.supersedeReceipts(pay.optLong("id"));studentDb.audit("PAYMENT",String.valueOf(pay.optLong("id")),"Payment reversed",before.toString(),"{\"status\":\"REVERSED\"}",reason.getText().toString().trim()+(receipt?" | Existing receipt marked SUPERSEDED":""),actor.getText().toString().trim());schedulePaymentDeadlineAlerts(studentDb.getStudent(studentId));toast("Payment reversed. Balance recalculated.");paymentHistory(studentId);}).show();}).show();}
    void inactiveStudents(){base("Archived / Withdrawn Records");setRefreshAction(()->inactiveStudents());addText("These records are hidden from normal working lists. History is retained and records can be reactivated.",12,Color.GRAY);ArrayList<JSONObject> rows=studentDb.lifecycleRows();if(rows.isEmpty())addText("No archived or withdrawn students.",14,Color.GRAY);for(JSONObject st:rows){Button b=btn(st.optString("name")+" • "+st.optString("student_id")+"\nStatus: "+st.optString("record_status")+"\nJourney: "+st.optString("stage"));b.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);content.addView(b);b.setOnClickListener(v->{String[] choices={"Open student record","Reactivate student"};new AlertDialog.Builder(this).setTitle(st.optString("name")).setItems(choices,(d,w)->{if(w==0)savedStudentDetails(st);else reactivateStudent(st);}).setNegativeButton("Cancel",null).show();});}Button back=btn("← Student Search");content.addView(back);back.setOnClickListener(v->students());}
    void reactivateStudent(JSONObject st){LinearLayout f=new LinearLayout(this);f.setPadding(24,8,24,8);f.setOrientation(LinearLayout.VERTICAL);EditText reason=multiField("Reason for reactivation (required)");EditText actor=field("Your name / staff ID (required)");f.addView(reason);f.addView(actor);new AlertDialog.Builder(this).setTitle("Reactivate student").setView(f).setNegativeButton("Cancel",null).setPositiveButton("Review",(d,w)->{if(reason.getText().toString().trim().isEmpty()||actor.getText().toString().trim().isEmpty()){toast("Enter your name and reason");return;}new AlertDialog.Builder(this).setTitle("Confirm reactivation").setMessage("Return "+st.optString("name")+" to active working lists?").setNegativeButton("Cancel",null).setPositiveButton("Reactivate",(dd,ww)->{studentDb.setRecordStatus(st.optLong("id"),"ACTIVE");studentDb.audit("STUDENT",String.valueOf(st.optLong("id")),"Student reactivated",st.optString("record_status"),"ACTIVE",reason.getText().toString().trim(),actor.getText().toString().trim());inactiveStudents();}).show();}).show();}
    String auditActorName(){return getSharedPreferences("gme_audit_settings",MODE_PRIVATE).getString("actor_name","App user (name not configured)");}
    void setAuditUser(){EditText actor=field("Staff name / ID");actor.setText(getSharedPreferences("gme_audit_settings",MODE_PRIVATE).getString("actor_name",""));new AlertDialog.Builder(this).setTitle("Audit identity").setMessage("Set the staff identity used for automatic audit entries. Financial corrections still ask for confirmation and a reason.").setView(actor).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{String value=actor.getText().toString().trim();if(value.isEmpty()){toast("Enter a staff name or ID");return;}getSharedPreferences("gme_audit_settings",MODE_PRIVATE).edit().putString("actor_name",value).apply();toast("Audit identity saved");dashboard();}).show();}
    void showGlobalAudit(){base("Activity & Audit Log");addText("Recent recorded changes across student and finance operations. This is a local-device log; back up the app data regularly.",12,Color.GRAY);ArrayList<JSONObject> logs=studentDb.allAudit();if(logs.isEmpty())addText("No audit events recorded yet.",14,Color.GRAY);for(JSONObject l:logs){addText(l.optString("action")+" • "+l.optString("entity_type")+" #"+l.optString("entity_id"),14,purpleDark);addText(dateTime(l.optLong("created_at"))+"\nBy: "+l.optString("actor")+"\nReason: "+l.optString("reason"),12,Color.DKGRAY);addGap();}Button back=btn("← Home");content.addView(back);back.setOnClickListener(v->dashboard());}
    void studentLifecycleActions(JSONObject st){long id=st.optLong("id");String[] choices={"Archive student (hide from active lists)","Mark withdrawn / inactive","Delete record (only if no payment history)"};new AlertDialog.Builder(this).setTitle("Student record actions").setItems(choices,(d,w)->{if(w==0)confirmStudentStatus(st,"ARCHIVED","Archive student","The record will be hidden from normal student lists; its history remains stored.");else if(w==1)confirmStudentStatus(st,"WITHDRAWN","Mark student withdrawn","The student remains in records with a withdrawn/inactive status.");else confirmDeleteStudent(st);}).setNegativeButton("Cancel",null).show();}
    void confirmStudentStatus(JSONObject st,String status,String title,String message){LinearLayout f=new LinearLayout(this);f.setPadding(24,8,24,8);f.setOrientation(LinearLayout.VERTICAL);EditText reason=multiField("Reason (required)");EditText actor=field("Your name / staff ID (required)");f.addView(reason);f.addView(actor);new AlertDialog.Builder(this).setTitle(title).setMessage(message).setView(f).setNegativeButton("Cancel",null).setPositiveButton("Review",(d,w)->{if(reason.getText().toString().trim().isEmpty()||actor.getText().toString().trim().isEmpty()){toast("Enter your name and a reason");return;}new AlertDialog.Builder(this).setTitle("Confirm "+title.toLowerCase(Locale.ROOT)).setMessage(st.optString("name")+" • "+st.optString("student_id")+"\n"+message).setNegativeButton("Cancel",null).setPositiveButton("Confirm",(dd,ww)->{String before=st.optString("record_status","ACTIVE");studentDb.setRecordStatus(st.optLong("id"),status);studentDb.audit("STUDENT",String.valueOf(st.optLong("id")),title,before,status,reason.getText().toString().trim(),actor.getText().toString().trim());toast("Student status updated: "+status);students();}).show();}).show();}
    void confirmDeleteStudent(JSONObject st){long id=st.optLong("id");if(studentDb.hasPayments(id)){toast("This student has payment history. Permanent deletion is blocked; archive the student instead.");return;}LinearLayout f=new LinearLayout(this);f.setPadding(24,8,24,8);f.setOrientation(LinearLayout.VERTICAL);EditText reason=multiField("Reason for deletion (required)");EditText actor=field("Your name / staff ID (required)");EditText confirm=field("Type DELETE to confirm");f.addView(reason);f.addView(actor);f.addView(confirm);new AlertDialog.Builder(this).setTitle("Permanently delete student?").setMessage("Only use this for a genuine duplicate or record entered by mistake. No payment records may be linked.").setView(f).setNegativeButton("Cancel",null).setPositiveButton("Delete record",(d,w)->{if(!"DELETE".equals(confirm.getText().toString().trim())||reason.getText().toString().trim().isEmpty()||actor.getText().toString().trim().isEmpty()){toast("Deletion cancelled. Enter DELETE, your name and a reason.");return;}new AlertDialog.Builder(this).setTitle("Final confirmation").setMessage("Permanently delete "+st.optString("name")+" ("+st.optString("student_id")+")? This cannot be undone.").setNegativeButton("Cancel",null).setPositiveButton("Permanently delete",(dd,ww)->{studentDb.audit("STUDENT",String.valueOf(id),"Student permanently deleted",st.toString(),"",reason.getText().toString().trim(),actor.getText().toString().trim());studentDb.deleteStudent(id);toast("Student record deleted and audit entry retained.");students();}).show();}).show();}
    void showStudentAudit(long studentId){JSONObject st=studentDb.getStudent(studentId);base("Student Activity & Audit History");pinStudentContext(st);addText(st.optString("name")+" • "+st.optString("student_id"),17,purple);ArrayList<JSONObject> logs=studentDb.auditForStudent(studentId);if(logs.isEmpty())addText("No audit events recorded yet.",14,Color.GRAY);for(JSONObject l:logs){addText(l.optString("action")+" • "+dateTime(l.optLong("created_at")),14,purpleDark);addText("By: "+l.optString("actor")+"\nReason: "+l.optString("reason"),12,Color.DKGRAY);if(!l.optString("before_json").isEmpty())addText("Before: "+l.optString("before_json"),10,Color.GRAY);if(!l.optString("after_json").isEmpty())addText("After: "+l.optString("after_json"),10,Color.GRAY);addGap();}Button back=btn("← Student Record");content.addView(back);back.setOnClickListener(v->savedStudentDetails(studentDb.getStudent(studentId)));}
    void recordPayment(long id){LinearLayout form=new LinearLayout(this);form.setPadding(24,8,24,8);form.setOrientation(LinearLayout.VERTICAL);EditText amount=field("Payment amount");amount.setInputType(8194);EditText currency=field("Currency (USD recommended)");currency.setText("USD");EditText method=field("Payment method (cash, bank, transfer, etc.)");EditText reference=field("Transaction reference (optional)");EditText note=field("Note (optional)");EditText actor=field("Recorded by — your name / staff ID");form.addView(amount);form.addView(currency);form.addView(method);form.addView(reference);form.addView(note);form.addView(actor);new AlertDialog.Builder(this).setTitle("Record student payment").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save Payment",(d,w)->{try{double value=Double.parseDouble(amount.getText().toString().trim());if(value<=0)throw new Exception();if(actor.getText().toString().trim().isEmpty())throw new Exception("Enter your name / staff ID");long paymentId=studentDb.addPayment(id,value,currency.getText().toString().trim().toUpperCase(Locale.US),method.getText().toString().trim(),reference.getText().toString().trim(),note.getText().toString().trim());studentDb.audit("PAYMENT",String.valueOf(paymentId),"Payment recorded","",studentDb.payment(paymentId).toString(),"Initial payment entry",actor.getText().toString().trim());JSONObject paidStudent=studentDb.getStudent(id);if(studentDb.stageIndex(paidStudent.optString("stage"))<studentDb.stageIndex("Admission confirmed"))studentDb.updateStage(id,"Admission confirmed","Automatically marked Admission confirmed when a student payment was recorded");schedulePaymentDeadlineAlerts(studentDb.getStudent(id));toast("Payment saved. Student marked Admission confirmed.");studentFinance(studentDb.getStudent(id));}catch(Exception e){toast(e.getMessage()==null?"Enter a valid payment amount":e.getMessage());}}).show();}
    void documentCentre(){base("Document Centre");setRefreshAction(()->documentCentre());addText("Create polished, student-specific documents from saved records. Registration confirmations are generated temporarily and shared immediately; they are not stored in the app's Documents section. Referral stamps are kept internal and are never printed on student-facing documents.",13,Color.GRAY);Button branding=btn("✍  Office Signatory, Signature & Stamp Settings");content.addView(branding);branding.setOnClickListener(v->documentBrandingSettings());EditText q=field("Search by student name, ID or nationality");content.addView(q);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);Runnable refresh=()->{list.removeAllViews();for(JSONObject st:studentDb.search(q.getText().toString())){LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setPadding(dp(8),dp(5),dp(8),dp(5));list.addView(item);addReferralStamp(item,st.optString("referred_by"));addStudentListRow(item,st,st.optString("name")+" • "+st.optString("student_id")+"\n"+st.optString("programme")+"\n"+(st.optString("nationality").isEmpty()?"Nationality not recorded":st.optString("nationality")));}};q.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){}public void onTextChanged(CharSequence s,int a,int b,int c){refresh.run();}public void afterTextChanged(android.text.Editable e){}});refresh.run();}
    void documentBrandingSettings(){
        android.content.SharedPreferences prefs=getSharedPreferences("gme_document_branding",MODE_PRIVATE);
        base("Office Document Branding");
        addText("Upload your authorised signature and company stamp once. They are saved on this device and reused automatically on supported student-facing PDFs, including Programme Guidance reports, checklists, arrival reports, invoices and receipts. Upload a replacement at any time to use the new image on future documents.",13,Color.GRAY);
        EditText signatory=field("Signatory full name");signatory.setText(prefs.getString("signatory_name",""));
        EditText role=field("Office title / designation");role.setText(prefs.getString("signatory_role","Global Minds Education"));
        content.addView(signatory);content.addView(role);
        addText("AUTHORised SIGNATURE",12,purple);
        String sigUri=prefs.getString("signature_uri","");addText(sigUri.isEmpty()?"Status: No signature uploaded":"Status: Signature saved on this device • Reused on generated documents",13,sigUri.isEmpty()?Color.rgb(160,75,45):Color.rgb(40,120,70));
        if(!sigUri.isEmpty())addBrandingPreview(sigUri,"Saved signature preview");
        Button signature=btn(sigUri.isEmpty()?"Upload Signature":"Replace Saved Signature");content.addView(signature);signature.setOnClickListener(v->pickBrandingImage(7413));
        if(!sigUri.isEmpty()){Button removeSig=btn("Remove Saved Signature");content.addView(removeSig);removeSig.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Remove signature?").setMessage("Future documents will no longer include the saved signature until you upload one again.").setNegativeButton("Cancel",null).setPositiveButton("Remove",(d,w)->{prefs.edit().remove("signature_uri").apply();toast("Saved signature removed");documentBrandingSettings();}).show());}
        addText("COMPANY STAMP",12,purple);
        String stampUri=prefs.getString("stamp_uri","");addText(stampUri.isEmpty()?"Status: No company stamp uploaded":"Status: Company stamp saved on this device • Reused on generated documents",13,stampUri.isEmpty()?Color.rgb(160,75,45):Color.rgb(40,120,70));
        if(!stampUri.isEmpty())addBrandingPreview(stampUri,"Saved company stamp preview");
        Button stamp=btn(stampUri.isEmpty()?"Upload Company Stamp":"Replace Saved Company Stamp");content.addView(stamp);stamp.setOnClickListener(v->pickBrandingImage(7414));
        if(!stampUri.isEmpty()){Button removeStamp=btn("Remove Saved Company Stamp");content.addView(removeStamp);removeStamp.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Remove company stamp?").setMessage("Future documents will no longer include the saved stamp until you upload one again.").setNegativeButton("Cancel",null).setPositiveButton("Remove",(d,w)->{prefs.edit().remove("stamp_uri").apply();toast("Saved company stamp removed");documentBrandingSettings();}).show());}
        Button save=btn("Save Signatory Details");content.addView(save);save.setOnClickListener(v->{prefs.edit().putString("signatory_name",signatory.getText().toString().trim()).putString("signatory_role",role.getText().toString().trim()).apply();toast("Signatory details saved for reuse");documentBrandingSettings();});
        Button back=btn("← Document Centre");content.addView(back);back.setOnClickListener(v->documentCentre());
    }
    void addBrandingPreview(String uriText,String description){try{ImageView image=new ImageView(this);image.setContentDescription(description);image.setImageURI(Uri.parse(uriText));image.setAdjustViewBounds(true);image.setScaleType(ImageView.ScaleType.FIT_CENTER);image.setBackground(shape(Color.WHITE,Color.rgb(225,216,234)));image.setPadding(dp(8),dp(8),dp(8),dp(8));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(110));lp.setMargins(0,dp(3),0,dp(8));content.addView(image,lp);}catch(Exception e){addText("Preview unavailable; the saved image will be tried when generating a document.",12,Color.GRAY);}}

    void pickBrandingImage(int request){Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);pick.addCategory(Intent.CATEGORY_OPENABLE);pick.setType("image/*");startActivityForResult(pick,request);}
    // Removes light, near-neutral paper backgrounds from uploaded signature/stamp images and saves a transparent PNG for reuse.
    String removeLightBackgroundAndSave(Uri sourceUri,String prefKey)throws IOException{
        BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;InputStream boundsIn=getContentResolver().openInputStream(sourceUri);if(boundsIn==null)throw new IOException("Unable to open image");try{BitmapFactory.decodeStream(boundsIn,null,bounds);}finally{boundsIn.close();}
        int sample=1;while((bounds.outWidth/sample)>1800||(bounds.outHeight/sample)>1800)sample*=2;
        BitmapFactory.Options opts=new BitmapFactory.Options();opts.inSampleSize=sample;opts.inPreferredConfig=Bitmap.Config.ARGB_8888;
        InputStream imageIn=getContentResolver().openInputStream(sourceUri);if(imageIn==null)throw new IOException("Unable to open image");Bitmap original;try{original=BitmapFactory.decodeStream(imageIn,null,opts);}finally{imageIn.close();}if(original==null)throw new IOException("Unsupported image format");
        Bitmap transparent=original.copy(Bitmap.Config.ARGB_8888,true);original.recycle();int width=transparent.getWidth(),height=transparent.getHeight();int[] pixels=new int[width*height];transparent.getPixels(pixels,0,width,0,0,width,height);
        for(int i=0;i<pixels.length;i++){int px=pixels[i];int a=Color.alpha(px),r=Color.red(px),g=Color.green(px),b=Color.blue(px);int min=Math.min(r,Math.min(g,b)),max=Math.max(r,Math.max(g,b));if(a==0)continue;int spread=max-min;
            // Target white/off-white paper and neutral grey scan backgrounds, while preserving coloured stamp ink.
            if(min>180&&spread<48){int newAlpha;if(min>=246)newAlpha=0;else if(min>=220)newAlpha=Math.max(0,Math.min(255,(245-min)*10));else newAlpha=Math.min(255,(245-min)*4);pixels[i]=Color.argb((a*newAlpha)/255,r,g,b);}
        }
        transparent.setPixels(pixels,0,width,0,0,width,height);Arrays.fill(pixels,0);File outFile=new File(getFilesDir(),prefKey.equals("signature_uri")?"office_signature_transparent.png":"office_stamp_transparent.png");FileOutputStream out=new FileOutputStream(outFile);try{if(!transparent.compress(Bitmap.CompressFormat.PNG,100,out))throw new IOException("PNG save failed");out.flush();}finally{out.close();transparent.recycle();}return Uri.fromFile(outFile).toString();
    }
    // Draw uploaded signature/stamp at a clearly visible size while preserving its exact aspect ratio.
    // Transparent margins are cropped before fitting so the actual ink/signature is not made tiny by
    // empty space in the source PNG. No stretching or deformation is applied.
    void drawBrandingImage(Canvas canvas,String prefKey,float left,float top,float right,float bottom){
        try{
            String uri=getSharedPreferences("gme_document_branding",MODE_PRIVATE).getString(prefKey,"");
            if(uri.isEmpty())return;
            InputStream in=getContentResolver().openInputStream(Uri.parse(uri));
            if(in==null)return;
            Bitmap source=BitmapFactory.decodeStream(in);
            in.close();
            if(source==null)return;

            Bitmap bitmap=source;
            // Trim transparent margins around the uploaded artwork. This is especially important for
            // scanned signatures/stamps whose PNG canvas can be much larger than the visible ink.
            int w=source.getWidth(), h=source.getHeight();
            int minX=w, minY=h, maxX=-1, maxY=-1;
            for(int yy=0;yy<h;yy+=2){
                for(int xx=0;xx<w;xx+=2){
                    if(Color.alpha(source.getPixel(xx,yy))>12){
                        if(xx<minX)minX=xx; if(xx>maxX)maxX=xx;
                        if(yy<minY)minY=yy; if(yy>maxY)maxY=yy;
                    }
                }
            }
            if(maxX>=minX && maxY>=minY){
                int padX=Math.max(2,(maxX-minX+1)/30);
                int padY=Math.max(2,(maxY-minY+1)/30);
                int cropL=Math.max(0,minX-padX), cropT=Math.max(0,minY-padY);
                int cropR=Math.min(w-1,maxX+padX), cropB=Math.min(h-1,maxY+padY);
                if(cropR-cropL+1 < w || cropB-cropT+1 < h){
                    bitmap=Bitmap.createBitmap(source,cropL,cropT,cropR-cropL+1,cropB-cropT+1);
                    source.recycle();
                }
            }

            float boxW=Math.max(1f,right-left), boxH=Math.max(1f,bottom-top);
            float bw=Math.max(1,bitmap.getWidth()), bh=Math.max(1,bitmap.getHeight());
            float scale=Math.min(boxW/bw,boxH/bh); // aspect-ratio preserving FIT_CENTER
            float drawW=bw*scale, drawH=bh*scale;
            float drawLeft=left+(boxW-drawW)/2f;
            float drawTop=top+(boxH-drawH)/2f;
            RectF dst=new RectF(drawLeft,drawTop,drawLeft+drawW,drawTop+drawH);

            Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG|Paint.DITHER_FLAG);
            paint.setFilterBitmap(true);
            canvas.drawBitmap(bitmap,null,dst,paint);
            bitmap.recycle();
        }catch(Exception ignored){}
    }


    String visaPrefKey(long studentId,String field){return "visa_"+studentId+"_"+field;}
    String visaSaved(long studentId,String field,String fallback){
        return getSharedPreferences("gme_visa_undertaking",MODE_PRIVATE).getString(visaPrefKey(studentId,field),fallback==null?"":fallback);
    }
    void visaUndertakingForm(JSONObject st){
        JSONObject fresh=studentDb.getStudent(st.optLong("id"));
        long sid=fresh.optLong("id");
        android.content.SharedPreferences prefs=getSharedPreferences("gme_visa_undertaking",MODE_PRIVATE);
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(8),dp(4),dp(8),dp(4));
        EditText date=field("Date (DD/MM/YYYY)");date.setText(visaSaved(sid,"date",new SimpleDateFormat("dd/MM/yyyy",Locale.ENGLISH).format(new Date())));
        EditText name=field("Applicant full name");name.setText(fresh.optString("name"));
        EditText passport=field("Passport Number");passport.setText(visaSaved(sid,"passport",""));
        EditText issuePlace=field("Passport issued at (place)");issuePlace.setText(visaSaved(sid,"issue_place",""));
        EditText issueDate=field("Passport issued on (date)");issueDate.setText(visaSaved(sid,"issue_date",""));
        EditText course=field("Name of Course / Degree");course.setText(visaSaved(sid,"course",fresh.optString("programme")));
        EditText university=field("Name of Indian University / Institution");university.setText(visaSaved(sid,"university",""));
        EditText state=field("State, India");state.setText(visaSaved(sid,"state",""));
        EditText startYear=field("Start Year");startYear.setText(visaSaved(sid,"start_year",""));
        EditText endYear=field("End Year");endYear.setText(visaSaved(sid,"end_year",""));
        EditText sponsor=field("Name of Sponsor");sponsor.setText(visaSaved(sid,"sponsor",""));
        EditText sponsorAddress=multiField("Sponsor Address");sponsorAddress.setText(visaSaved(sid,"sponsor_address",""));
        EditText sponsorPhone=field("Sponsor Phone Number");sponsorPhone.setText(visaSaved(sid,"sponsor_phone",""));
        EditText address=multiField("Applicant Address");String defaultAddress=fresh.optString("city");if(!fresh.optString("province").isEmpty())defaultAddress+=(defaultAddress.isEmpty()?"":", ")+fresh.optString("province");address.setText(visaSaved(sid,"address",defaultAddress));
        EditText phone=field("Applicant Phone Number");phone.setText(visaSaved(sid,"phone",fresh.optString("phone")));
        TextView info=new TextView(this);info.setText("Student details already stored in the app are pre-filled. Edit any field before generating. The completed PDF is saved locally and can be shared.");info.setTextSize(12);info.setTextColor(Color.GRAY);info.setPadding(0,0,0,dp(10));form.addView(info);
        EditText[] fields={date,name,passport,issuePlace,issueDate,course,university,state,startYear,endYear,sponsor,sponsorAddress,sponsorPhone,address,phone};
        for(EditText e:fields)form.addView(e);
        ScrollView scroll=new ScrollView(this);scroll.addView(form);
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Student Visa Undertaking Form").setView(scroll).setNegativeButton("Cancel",null).setPositiveButton("Generate PDF",null).create();
        dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String[] keys={"date","name","passport","issue_place","issue_date","course","university","state","start_year","end_year","sponsor","sponsor_address","sponsor_phone","address","phone"};
            String[] vals=new String[fields.length];
            boolean missing=false;
            for(int i=0;i<fields.length;i++){vals[i]=fields[i].getText().toString().trim();if(i>0&&vals[i].isEmpty())missing=true;}
            if(vals[1].isEmpty()||vals[2].isEmpty()||vals[5].isEmpty()||vals[6].isEmpty()||vals[7].isEmpty()||vals[8].isEmpty()||vals[9].isEmpty()||vals[10].isEmpty()||vals[11].isEmpty()||vals[12].isEmpty()){toast("Please complete the required visa undertaking details.");return;}
            android.content.SharedPreferences.Editor ed=prefs.edit();for(int i=0;i<keys.length;i++)ed.putString(visaPrefKey(sid,keys[i]),vals[i]);ed.apply();
            try{generateVisaUndertakingPdf(fresh,vals);dlg.dismiss();}catch(Exception e){toast("Could not generate the visa undertaking: "+e.getMessage());}
        }));dlg.show();
    }
    void generateVisaUndertakingPdf(JSONObject st,String[] v)throws Exception{
        // v: date,name,passport,issue_place,issue_date,course,university,state,start_year,end_year,sponsor,sponsor_address,sponsor_phone,address,phone
        PdfDocument doc=new PdfDocument();PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());Canvas c=page.getCanvas();Paint p=new Paint(3);
        c.drawColor(Color.WHITE);p.setColor(pdfPurple);c.drawRect(0,0,595,9,p);
        float y=38;float left=42,right=553,width=right-left;
        p.setColor(pdfPurple);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(17);c.drawText("VISA UNDERTAKING FORM",left,y,p);y+=22;
        p.setColor(pdfInk);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setTextSize(9.5f);c.drawText("Date: "+v[0],left,y,p);y+=20;
        p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));c.drawText("To,",left,y,p);y+=14;p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));c.drawText("The Visa Officer,",left,y,p);y+=13;c.drawText("Embassy of India,",left,y,p);y+=13;c.drawText("Harare, Zimbabwe.",left,y,p);y+=22;
        p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));c.drawText("Subject: Undertaking for Indian Student Visa Application",left,y,p);y+=20;
        p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
        y=visaParagraph(c,p,"Respected Sir/Madam, I, "+v[1]+", a citizen of Zimbabwe holding Passport Number "+v[2]+", issued at "+v[3]+" on "+v[4]+", do hereby solemnly affirm and declare the following:",left,y,width,9.2f,12.2f);
        y=visaParagraph(c,p,"My sole purpose for travelling to India is to pursue higher education. I have been granted admission to the "+v[5]+" at "+v[6]+" in "+v[7]+" for the academic duration of "+v[8]+" to "+v[9]+".",left,y,width,9.2f,12.2f);
        y=visaBullet(c,p,"I guarantee that all expenses related to my tuition fees, accommodation, medical insurance, and living costs in India will be fully covered by "+v[10]+". Sponsor address: "+v[11]+". Sponsor phone: "+v[12]+".",left,y,width,9.0f,11.8f);
        y=visaBullet(c,p,"I strictly undertake to abide by all the laws, rules, and regulations of the Government of India, as well as the code of conduct established by my hosting educational institution.",left,y,width,9.0f,11.8f);
        y=visaBullet(c,p,"I declare that I will not engage in any commercial employment, business, or unauthorized journalistic activities during my stay in India.",left,y,width,9.0f,11.8f);
        y=visaBullet(c,p,"I confirm that I am not involved in any criminal activities and have no pending legal cases against me in Zimbabwe or elsewhere.",left,y,width,9.0f,11.8f);
        y=visaBullet(c,p,"I undertake to leave India immediately upon the completion of my studies or the expiration of my student visa, whichever occurs first.",left,y,width,9.0f,11.8f);
        y=visaParagraph(c,p,"I hereby certify that all information provided in this undertaking and my visa application is true and correct to the best of my knowledge. I accept full responsibility for any consequences arising from any false statements. Thank you for considering my visa application.",left,y,width,9.2f,12.2f);
        y+=8;p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setTextSize(9.2f);c.drawText("Yours faithfully,",left,y,p);y+=28;c.drawLine(left,y,left+180,y,p);y+=15;c.drawText(v[1],left,y,p);y+=15;c.drawText("Address: "+v[13],left,y,p);y+=15;c.drawText("Phone Number: "+v[14],left,y,p);
        
        doc.finishPage(page);File f=new File(getCacheDir(),safe(st.optString("student_id"))+"_Student_Visa_Undertaking.pdf");FileOutputStream out=new FileOutputStream(f);doc.writeTo(out);out.close();doc.close();share(f);
    }
    float visaParagraph(Canvas c,Paint p,String text,float x,float y,float width,float size,float leading){
        p.setTextSize(size);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));String line="";for(String word:text.split("\\s+")){String candidate=line.isEmpty()?word:line+" "+word;if(p.measureText(candidate)>width&&!line.isEmpty()){c.drawText(line,x,y,p);y+=leading;line=word;}else line=candidate;}if(!line.isEmpty()){c.drawText(line,x,y,p);y+=leading;}return y+2;
    }
    float visaBullet(Canvas c,Paint p,String text,float x,float y,float width,float size,float leading){
        float bulletWidth=14;p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(size);c.drawText("•",x,y,p);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));String line="";float tx=x+bulletWidth;for(String word:text.split("\\s+")){String candidate=line.isEmpty()?word:line+" "+word;if(p.measureText(candidate)>width-bulletWidth&&!line.isEmpty()){c.drawText(line,tx,y,p);y+=leading;line=word;}else line=candidate;}if(!line.isEmpty()){c.drawText(line,tx,y,p);y+=leading;}return y+1;
    }
    void documentChoices(JSONObject st){base("Generate Student Document");JSONObject fresh=studentDb.getStudent(st.optLong("id"));pinStudentContext(fresh);addReferralStamp(content,fresh.optString("referred_by"));addText(fresh.optString("name")+" • "+fresh.optString("student_id"),17,purple);addText("Nationality: "+(fresh.optString("nationality").isEmpty()?"Not recorded":fresh.optString("nationality"))+" • Referee: "+(fresh.optString("referred_by").isEmpty()?"Not recorded":fresh.optString("referred_by")),12,Color.DKGRAY);String[] docs={"Programme Guidance Report","Application Checklist","Travel-readiness Checklist","Student Arrival and Follow-up Report","Invoice","Payment Receipt","Invoice and Payment Summary"};for(String doc:docs){Button b=btn(doc);content.addView(b);b.setOnClickListener(v->{if(doc.equals("Programme Guidance Report")){savedStudentDetails(fresh);}else generateSimpleDoc(fresh,doc);});}Button lpu=btn("📄 Generate LPU Application Form");content.addView(lpu);lpu.setOnClickListener(v->lpuOpen(fresh));Button visa=btn("🛂 Student Visa Undertaking Form");content.addView(visa);visa.setOnClickListener(v->visaUndertakingForm(fresh));Button back=btn("← Document Centre");content.addView(back);back.setOnClickListener(v->documentCentre());}

    // LPU application workflow: each student's generated form and supporting files are stored privately on this device.
    static final int LPU_PICK_PHOTO=7500, LPU_PICK_BASE=7510;
    long lpuStudentId=-1; String lpuPendingType=""; ImageView lpuPhotoPreview; Uri lpuPhotoUri=null;
    EditText[] lpuFieldViews;
    String[] lpuFieldKeys={"App_No","Previous_Programme","Cgpa_grades","Programme_applied","Student_Name","Father_Name","Mother_Name","Student_gender","Date_of_Birth","Student_Email_address","Guardian_Email_address","Mobile_No","Guardian_Mobile_No","Telephone_No","Code","Passport_OR_ID_No","Nationality","Country","Province","City_Town","Postal_code","Residential_address"};
    String[] lpuFieldLabels={"Application No.","Previous Programme / Level of Study","Percentage / CGPA / GPA","Programme Applied For","Applicant Name (as on Passport / National ID)","Father's Name","Mother's Name","Gender","Date of Birth","Applicant Email","Parent / Guardian Email","Applicant Mobile","Parent / Guardian Mobile","Telephone No.","Country Code","Passport / National ID No.","Nationality","Residential Country","Residential Province / State","City / Town","Postal Code","Residential Address"};
    String[] lpuDocTypes={"O Level Certificate","O Level Statement of Entry","A Level Certificate","A Level Results Slip","A Level Statement of Entry","Diploma Transcript","Degree Transcript","Passport","National ID"};
    Spinner lpuPreviousSpinner,lpuGenderSpinner; Button lpuDobButton; String lpuDobValue="";
    JSONObject lpuData=new JSONObject();
    File lpuFolder(long sid){File f=new File(getFilesDir(),"lpu_applications/"+sid);if(!f.exists())f.mkdirs();return f;}
    File lpuIndex(long sid){return new File(lpuFolder(sid),"documents.json");}
    JSONObject lpuLoadIndex(long sid){try{File f=lpuIndex(sid);if(f.exists()){try(FileInputStream in=new FileInputStream(f);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);return new JSONObject(new String(out.toByteArray(),"UTF-8"));}}}catch(Exception ignored){}return new JSONObject();}
    void lpuSaveIndex(long sid,JSONObject j){try(FileOutputStream o=new FileOutputStream(lpuIndex(sid))){o.write(j.toString(2).getBytes("UTF-8"));}catch(Exception e){toast("Could not save document list.");}}
    String lpuProgrammeLevel(String programme){String p=programme==null?"":programme.toLowerCase(Locale.ROOT);if(p.contains("master")||p.contains("mba")||p.contains("msc")||p.contains("m.tech")||p.contains("mphil"))return "MASTERS";if(p.contains("phd")||p.contains("doctor of philosophy"))return "PHD";if(p.contains("degree")||p.contains("bachelor")||p.contains("honours")||p.contains("b.tech")||p.contains("bsc")||p.contains("bba")||p.contains("undergraduate"))return "DEGREE";return "DIPLOMA";}
    boolean lpuIsDegree(String programme){return "DEGREE".equals(lpuProgrammeLevel(programme));}
    String[] lpuRequiredDocuments(String programme){String level=lpuProgrammeLevel(programme);if("MASTERS".equals(level))return new String[]{"O Level Certificate","A Level Results Slip or Diploma Transcript","Degree Transcript","Passport or National ID"};if("DEGREE".equals(level))return new String[]{"O Level Certificate","A Level Results Slip or A Level Statement of Entry or Diploma Transcript","Passport or National ID"};if("PHD".equals(level))return new String[]{"PHD document requirements not yet specified — confirm with admissions"};return new String[]{"O Level Certificate or O Level Statement of Entry","Passport or National ID"};}
    void lpuOpen(JSONObject student){
        JSONObject fresh=studentDb.getStudent(student.optLong("id"));lpuStudentId=fresh.optLong("id");lpuData=new JSONObject();lpuPhotoUri=null;
        base("Generate LPU Application Form");
        addText("Complete or review the LPU application details, add the applicant photograph, then generate the official form and upload supporting documents. The supplied LPU master template is retained.",13,Color.GRAY);
        String programme=fresh.optString("programme");
        addText("Programme on student record: "+(programme.isEmpty()?"Not recorded":programme),13,purple);
        lpuFieldViews=new EditText[lpuFieldKeys.length];
        JSONObject saved=lpuLoadIndex(lpuStudentId).optJSONObject("form_data");if(saved==null)saved=new JSONObject();
        String nat=fresh.optString("nationality").toUpperCase(Locale.ROOT);
        String[] defaults={peekLpuApplicationNumber(),"ORDINARY LEVEL", "",programme,fresh.optString("name").toUpperCase(Locale.ROOT),"","",fresh.optString("gender"),"","","",fresh.optString("phone"),"","",lpuDefaultCountryCode(nat),"",nat,fresh.optString("country",nat),fresh.optString("province").toUpperCase(Locale.ROOT),fresh.optString("city").toUpperCase(Locale.ROOT),("ZIMBABWE".equals(nat)?"00000":""),""};
        lpuPreviousSpinner=null;lpuGenderSpinner=null;lpuDobButton=null;lpuDobValue=saved.optString("Date_of_Birth","");
        for(int i=0;i<lpuFieldKeys.length;i++){
            addText(lpuFieldLabels[i],12,purpleDark);
            String val=(i==3?programme:saved.optString(lpuFieldKeys[i],defaults[i]));if(i==0&&val.isEmpty())val=defaults[i];
            if(i==1){lpuPreviousSpinner=new Spinner(this);String[] opts={"ORDINARY LEVEL","ADVANCED LEVEL","UNDERGRADUATE","MASTERS","PHD"};lpuPreviousSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,opts));lpuPreviousSpinner.setSelection(Math.max(0,Arrays.asList(opts).indexOf(val.toUpperCase(Locale.ROOT))));content.addView(lpuPreviousSpinner);lpuFieldViews[i]=field(lpuFieldLabels[i]);lpuFieldViews[i].setVisibility(View.GONE);}
            else if(i==7){lpuGenderSpinner=new Spinner(this);String[] opts={"MALE","FEMALE","TRANSGENDER"};lpuGenderSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,opts));lpuGenderSpinner.setSelection(Math.max(0,Arrays.asList(opts).indexOf(val.toUpperCase(Locale.ROOT))));content.addView(lpuGenderSpinner);lpuFieldViews[i]=field(lpuFieldLabels[i]);lpuFieldViews[i].setVisibility(View.GONE);}
            else if(i==8){lpuDobButton=btn("Select date of birth: "+(val.isEmpty()?"Not selected":val));content.addView(lpuDobButton);lpuDobButton.setOnClickListener(v->lpuPickDob());lpuFieldViews[i]=field(lpuFieldLabels[i]);lpuFieldViews[i].setVisibility(View.GONE);}
            else {EditText e=(i==21)?multiField(lpuFieldLabels[i]):field(lpuFieldLabels[i]);e.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.AllCaps()});e.setText(val.toUpperCase(Locale.ROOT));if(i==3)e.setEnabled(false);lpuFieldViews[i]=e;content.addView(e);}
        }
        EditText nationalityView=lpuFieldViews[16],postalView=lpuFieldViews[20],codeView=lpuFieldViews[14];
        final String initialNationality=nationalityView.getText().toString().trim().toUpperCase(Locale.ROOT);
        nationalityView.addTextChangedListener(new android.text.TextWatcher(){String prior=initialNationality;public void beforeTextChanged(CharSequence x,int st,int count,int after){}public void onTextChanged(CharSequence x,int st,int before,int count){String n=x.toString().trim().toUpperCase(Locale.ROOT);String suggested=lpuDefaultCountryCode(n);if(!suggested.isEmpty()&&(codeView.getText().toString().trim().isEmpty()||codeView.getText().toString().equals(prior.isEmpty()?"":lpuDefaultCountryCode(prior))))codeView.setText(suggested);if("ZIMBABWE".equals(n))postalView.setText("00000");prior=n;}public void afterTextChanged(android.text.Editable e){}});
        if("ZIMBABWE".equals(nat))postalView.setText("00000");
        Button photo=btn("Upload / Replace Applicant Photograph");content.addView(photo);
        lpuPhotoPreview=new ImageView(this);lpuPhotoPreview.setAdjustViewBounds(true);lpuPhotoPreview.setScaleType(ImageView.ScaleType.FIT_CENTER);lpuPhotoPreview.setBackground(shape(Color.WHITE,Color.rgb(225,216,234)));LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(126),dp(150));pp.setMargins(0,dp(4),0,dp(10));content.addView(lpuPhotoPreview,pp);
        String oldPhoto=lpuLoadIndex(lpuStudentId).optString("photo_path","");if(!oldPhoto.isEmpty()&&new File(oldPhoto).exists()){lpuPhotoPreview.setImageURI(Uri.fromFile(new File(oldPhoto)));lpuPhotoUri=Uri.fromFile(new File(oldPhoto));}
        photo.setOnClickListener(v->{lpuSaveFormData();Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);pick.addCategory(Intent.CATEGORY_OPENABLE);pick.setType("image/*");startActivityForResult(pick,LPU_PICK_PHOTO);});
        Button generate=btn("Generate LPU Application Form");content.addView(generate);generate.setOnClickListener(v->lpuGenerate());
        addText("SUPPORTING DOCUMENTS",14,purple);
        addText("PROGRAMME LEVEL: "+lpuProgrammeLevel(programme)+"\nREQUIRED SUPPORTING DOCUMENTS: "+android.text.TextUtils.join("; ",lpuRequiredDocuments(programme))+"\nOnly the listed alternatives are accepted for this programme level. Other uploads remain optional.",12,Color.GRAY);
        for(int i=0;i<lpuDocTypes.length;i++){final int ix=i;Button b=btn("Upload "+lpuDocTypes[i]);content.addView(b);b.setOnClickListener(v->{lpuSaveFormData();lpuPendingType=lpuDocTypes[ix];Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);pick.addCategory(Intent.CATEGORY_OPENABLE);pick.setType("*/*");pick.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/pdf","application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document","image/jpeg","image/png","image/webp"});startActivityForResult(pick,LPU_PICK_BASE+ix);});}
        lpuRenderDocumentStatus();
        Button email=btn("Prepare Email with Application & Supporting Documents");content.addView(email);email.setOnClickListener(v->lpuPrepareEmail());
        Button back=btn("← Student Documents");content.addView(back);back.setOnClickListener(v->documentChoices(fresh));
    }
    String peekLpuApplicationNumber(){android.content.SharedPreferences p=getSharedPreferences("gme_lpu_sequence",MODE_PRIVATE);return String.format(Locale.ROOT,"LPU-%06d",p.getInt("next",1));}
    void commitLpuApplicationNumber(){android.content.SharedPreferences p=getSharedPreferences("gme_lpu_sequence",MODE_PRIVATE);p.edit().putInt("next",p.getInt("next",1)+1).putInt("successful_generations",p.getInt("successful_generations",0)+1).apply();}
    String lpuDefaultCountryCode(String nationality){String n=nationality==null?"":nationality.trim().toUpperCase(Locale.ROOT);String[][] codes={{"ZIMBABWE","263"},{"INDIA","91"},{"ZAMBIA","260"},{"SOUTH AFRICA","27"},{"MALAWI","265"},{"BOTSWANA","267"},{"MOZAMBIQUE","258"},{"NIGERIA","234"},{"KENYA","254"},{"UGANDA","256"},{"TANZANIA","255"},{"GHANA","233"},{"RWANDA","250"},{"BURUNDI","257"},{"LESOTHO","266"},{"ESWATINI","268"},{"NAMIBIA","264"},{"ANGOLA","244"},{"DR CONGO","243"},{"DEMOCRATIC REPUBLIC OF THE CONGO","243"},{"CONGO","242"},{"ETHIOPIA","251"},{"SOMALIA","252"},{"SUDAN","249"},{"SOUTH SUDAN","211"},{"EGYPT","20"},{"MOROCCO","212"},{"ALGERIA","213"},{"TUNISIA","216"},{"SENEGAL","221"},{"CAMEROON","237"},{"IVORY COAST","225"},{"COTE D'IVOIRE","225"},{"UNITED STATES","1"},{"USA","1"},{"CANADA","1"},{"UNITED KINGDOM","44"},{"UK","44"},{"IRELAND","353"},{"AUSTRALIA","61"},{"NEW ZEALAND","64"},{"CHINA","86"},{"PAKISTAN","92"},{"BANGLADESH","880"},{"NEPAL","977"},{"SRI LANKA","94"},{"UNITED ARAB EMIRATES","971"},{"UAE","971"},{"SAUDI ARABIA","966"},{"QATAR","974"},{"OMAN","968"},{"TURKEY","90"},{"GERMANY","49"},{"FRANCE","33"},{"ITALY","39"},{"SPAIN","34"},{"PORTUGAL","351"},{"NETHERLANDS","31"},{"BELGIUM","32"},{"SWEDEN","46"},{"NORWAY","47"},{"SWITZERLAND","41"},{"BRAZIL","55"},{"MEXICO","52"},{"JAPAN","81"},{"SOUTH KOREA","82"}};for(String[] row:codes)if(n.equals(row[0])||n.contains(row[0]))return row[1];return "";}
    String lpuFieldValue(int i){if(i==1&&lpuPreviousSpinner!=null)return lpuPreviousSpinner.getSelectedItem().toString();if(i==7&&lpuGenderSpinner!=null)return lpuGenderSpinner.getSelectedItem().toString();if(i==8)return lpuDobValue;return lpuFieldViews[i].getText().toString().trim().toUpperCase(Locale.ROOT);}
    void lpuPickDob(){Calendar c=Calendar.getInstance();if(!lpuDobValue.isEmpty())try{c.setTime(new SimpleDateFormat("dd/MM/yyyy",Locale.ROOT).parse(lpuDobValue));}catch(Exception ignored){}DatePickerDialog picker=new DatePickerDialog(this,(view,y,m,d)->{lpuDobValue=String.format(Locale.ROOT,"%02d/%02d/%04d",d,m+1,y);if(lpuDobButton!=null)lpuDobButton.setText("Select date of birth: "+lpuDobValue);},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH));picker.getDatePicker().setMaxDate(System.currentTimeMillis());picker.show();}
    void lpuSaveFormData(){try{JSONObject d=new JSONObject();for(int i=0;i<lpuFieldKeys.length;i++)d.put(lpuFieldKeys[i],lpuFieldValue(i));if("ZIMBABWE".equalsIgnoreCase(d.optString("Nationality")))d.put("Postal_code","00000");JSONObject ix=lpuLoadIndex(lpuStudentId);ix.put("form_data",d);lpuSaveIndex(lpuStudentId,ix);lpuData=d;}catch(Exception ignored){}}
    void lpuGenerate(){
        try{
            if(lpuFieldViews!=null&&lpuFieldViews.length>0)lpuFieldViews[0].setText(peekLpuApplicationNumber());
            lpuSaveFormData();if(lpuPhotoUri==null){String old=lpuLoadIndex(lpuStudentId).optString("photo_path","");if(!old.isEmpty()&&new File(old).exists())lpuPhotoUri=Uri.fromFile(new File(old));}
            if(lpuData.optString("Student_Name").trim().isEmpty()||lpuData.optString("Programme_applied").trim().isEmpty()){toast("Applicant name and programme applied for are required.");return;}
            File out=new File(lpuFolder(lpuStudentId),"LPU Application Form for "+lpuSafe(lpuData.optString("Student_Name","Applicant"))+".pdf");
            lpuCreatePdf(out,lpuData,lpuPhotoUri);
            commitLpuApplicationNumber();
            JSONObject ix=lpuLoadIndex(lpuStudentId);ix.put("generated_form",out.getAbsolutePath());ix.put("generated_at",System.currentTimeMillis());lpuSaveIndex(lpuStudentId,ix);
            toast("LPU Application Form PDF generated successfully.");lpuRenderDocumentStatus();
        }catch(Exception e){toast("Could not generate LPU form: "+e.getMessage());}
    }
    String lpuSafe(String s){String v=(s==null?"Applicant":s).trim().replaceAll("[^A-Za-z0-9 _-]","").replaceAll("\\s+"," ");return v.isEmpty()?"Applicant":v;}
    // Render the supplied LPU master artwork and applicant details into a real, single-page PDF.
    // The DOCX remains the source template in assets; the generated/submitted document is PDF only.
    void lpuCreatePdf(File out,JSONObject data,Uri photoUri)throws Exception{
        // Use the exact 2026 LPU PDF artwork supplied for alignment, rather than
        // extracting an older image from the DOCX template.
        Bitmap page;
        try(InputStream template=getAssets().open("lpu_master_template_2026.png")){
            page=BitmapFactory.decodeStream(template);
        }
        if(page==null)throw new IOException("Could not read the 2026 LPU application form artwork");
        final int pw=page.getWidth(),ph=page.getHeight();
        PdfDocument pdf=new PdfDocument();
        PdfDocument.PageInfo info=new PdfDocument.PageInfo.Builder(612,790,1).create();
        PdfDocument.Page pg=pdf.startPage(info);Canvas c=pg.getCanvas();
        c.drawColor(Color.WHITE);c.save();c.scale(612f/pw,790f/ph);
        Paint bitmapPaint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
        c.drawBitmap(page,new Rect(0,0,pw,ph),new RectF(0,0,2580,3330),bitmapPaint);page.recycle();
        if(photoUri!=null){
            Bitmap photo=null;try(InputStream pin=getContentResolver().openInputStream(photoUri)){photo=BitmapFactory.decodeStream(pin);}catch(Exception ignored){}
            if(photo!=null){int x=2085,y=609,w=323,h=359;float ratio=(float)w/h,pr=(float)photo.getWidth()/photo.getHeight();Bitmap crop;
                if(pr>ratio){int nw=Math.max(1,(int)(photo.getHeight()*ratio));crop=Bitmap.createBitmap(photo,(photo.getWidth()-nw)/2,0,nw,photo.getHeight());}
                else{int nh=Math.max(1,(int)(photo.getWidth()/ratio));crop=Bitmap.createBitmap(photo,0,(photo.getHeight()-nh)/2,photo.getWidth(),nh);}
                Bitmap scaled=Bitmap.createScaledBitmap(crop,w,h,true);c.drawBitmap(scaled,x,y,bitmapPaint);photo.recycle();crop.recycle();scaled.recycle();
            }
        }
        Paint text=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.SUBPIXEL_TEXT_FLAG);
        text.setColor(Color.rgb(20,20,20));text.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
        // All coordinates below are measured on the supplied 2580 x 3330 form.
        // Larger bold type is used, with clipping constrained to each printed field.
        // Baselines are placed just above the printed rules or vertically centred in boxes.
        // Admission particulars: align text to the three corresponding writing rules.
        lpuPdfText(c,text,data.optString("App_No"),2080,160,430,45);
        lpuPdfText(c,text,data.optString("Previous_Programme"),785,660,1050,48);
        lpuPdfText(c,text,data.optString("Cgpa_grades"),1430,735,700,46);
        lpuPdfText(c,text,data.optString("Programme_applied"),650,805,1770,48);
        // Personal names: lift text clear of the printed underlines and use a stronger size.
        lpuPdfText(c,text,data.optString("Student_Name"),165,1075,2240,54);
        lpuPdfText(c,text,data.optString("Father_Name"),165,1230,2240,54);
        lpuPdfText(c,text,data.optString("Mother_Name"),165,1365,2240,54);
        lpuPdfDate(c,text,data.optString("Date_of_Birth"));
        lpuPdfGender(c,data.optString("Student_gender"));
        // Address and identity fields are aligned to the actual 2026 form rules.
        // Contact fields: values begin after the printed field labels and sit on the corresponding rules.
        lpuPdfText(c,text,data.optString("Residential_address").toUpperCase(Locale.ROOT),185,1720,2200,50);
        lpuPdfText(c,text,data.optString("City_Town").toUpperCase(Locale.ROOT),1100,1820,560,50);
        lpuPdfText(c,text,data.optString("Province").toUpperCase(Locale.ROOT),460,1895,450,48);
        lpuPdfText(c,text,data.optString("Country").toUpperCase(Locale.ROOT),1220,1895,570,48);
        lpuPdfCellText(c,text,data.optString("Postal_code"),1855,2390,2000,7,40,false);
        lpuPdfCellText(c,text,data.optString("Nationality"),370,1525,2000,15,39,true);
        lpuPdfText(c,text,data.optString("Passport_OR_ID_No").toUpperCase(Locale.ROOT),2045,2000,350,46);
        String code=lpuDigits(data.optString("Code"));if(code.startsWith("00"))code=code.substring(2);
        lpuPdfCellText(c,text,code,815,1055,2180,3,43,false);
        String telephone=lpuLocalPhone(data.optString("Telephone_No"),code);
        String mobile=lpuLocalPhone(data.optString("Mobile_No"),code);
        String parentMobile=lpuLocalPhone(data.optString("Guardian_Mobile_No"),code);
        lpuPdfCellText(c,text,telephone,1145,2075,2180,12,41,false);
        lpuPdfCellText(c,text,mobile,245,1020,2320,10,41,false);
        lpuPdfCellText(c,text,parentMobile,1250,2020,2320,10,41,false);
        lpuPdfCellText(c,text,data.optString("Student_Email_address").toUpperCase(Locale.ROOT),370,2365,2500,26,35,false);
        lpuPdfCellText(c,text,data.optString("Guardian_Email_address").toUpperCase(Locale.ROOT),520,2365,2590,24,35,false);
        // The form's Residential Facility Required choice is always No.
        lpuPdfTick(c,1335,2775);
        c.restore();pdf.finishPage(pg);
        try(FileOutputStream fos=new FileOutputStream(out)){pdf.writeTo(fos);}finally{pdf.close();}
    }
    String lpuDigits(String value){
        return value==null?"":value.replaceAll("[^0-9]","");
    }
    String lpuLocalPhone(String value,String countryCode){
        String digits=lpuDigits(value);
        String cc=lpuDigits(countryCode);
        if(!cc.isEmpty()&&digits.startsWith(cc)&&digits.length()>cc.length())digits=digits.substring(cc.length());
        return digits;
    }
    void lpuPdfDate(Canvas c,Paint p,String raw){
        if(raw==null||raw.trim().isEmpty())return;
        String[] parts=raw.trim().split("[/.-]");
        if(parts.length==3){
            if(parts[0].length()==4){String year=parts[0];parts=new String[]{parts[2],parts[1],year};}
            lpuPdfCellText(c,p,parts[0],470,625,1500,2,39,false);
            lpuPdfCellText(c,p,parts[1],660,815,1500,2,39,false);
            lpuPdfCellText(c,p,parts[2],850,1160,1500,4,39,false);
        }
    }
    void lpuPdfCellText(Canvas c,Paint p,String raw,float left,float right,float baseline,int cells,float size,boolean uppercase){
        if(raw==null||raw.trim().isEmpty()||cells<=0)return;
        String value=uppercase?raw.trim().toUpperCase(Locale.ROOT):raw.trim();
        value=value.replaceAll("\\s+","");
        int count=Math.min(value.length(),cells);
        if(count==0)return;
        float cell=(right-left)/cells;
        p.setTextAlign(Paint.Align.CENTER);
        float fit=Math.min(size,cell*0.72f);
        p.setTextSize(fit);
        c.save();c.clipRect(left,baseline-fit-8,right,baseline+8);
        for(int i=0;i<count;i++){
            String ch=String.valueOf(value.charAt(i));
            float cx=left+cell*(i+0.5f);
            float fs=fit;
            while(p.measureText(ch)>cell*0.78f&&fs>24f){fs-=1f;p.setTextSize(fs);}
            c.drawText(ch,cx,baseline,p);
            p.setTextSize(fit);
        }
        c.restore();p.setTextAlign(Paint.Align.LEFT);
    }
    void lpuPdfTick(Canvas c,float cx,float cy){
        Paint mark=new Paint(Paint.ANTI_ALIAS_FLAG);mark.setColor(Color.rgb(25,25,25));mark.setStyle(Paint.Style.STROKE);mark.setStrokeWidth(7f);mark.setStrokeCap(Paint.Cap.ROUND);mark.setStrokeJoin(Paint.Join.ROUND);
        Path tick=new Path();tick.moveTo(cx-17,cy);tick.lineTo(cx-3,cy+15);tick.lineTo(cx+22,cy-17);c.drawPath(tick,mark);
    }
    void lpuPdfCenteredText(Canvas c,Paint p,String value,float centerX,float baseline,float maxWidth,float size){
        if(value==null||value.trim().isEmpty())return;
        String v=value.trim();p.setTextAlign(Paint.Align.CENTER);p.setTextSize(size);
        while(p.measureText(v)>maxWidth&&p.getTextSize()>26f)p.setTextSize(p.getTextSize()-1f);
        c.save();c.clipRect(centerX-maxWidth/2,baseline-p.getTextSize()-8,centerX+maxWidth/2,baseline+8);c.drawText(v,centerX,baseline,p);c.restore();p.setTextAlign(Paint.Align.LEFT);
    }
    void lpuPdfGender(Canvas c,String gender){
        if(gender==null)return;String g=gender.trim().toLowerCase(Locale.ROOT);int x=g.startsWith("f")?1935:(g.startsWith("t")?2310:1585);Paint mark=new Paint(Paint.ANTI_ALIAS_FLAG);mark.setColor(Color.rgb(35,35,35));mark.setStyle(Paint.Style.STROKE);mark.setStrokeWidth(7f);mark.setStrokeCap(Paint.Cap.ROUND);mark.setStrokeJoin(Paint.Join.ROUND);Path tick=new Path();tick.moveTo(x-15,1470);tick.lineTo(x-3,1484);tick.lineTo(x+20,1455);c.drawPath(tick,mark);
    }
    void lpuPdfText(Canvas c,Paint p,String value,float x,float baseline,float maxWidth,float size){
        if(value==null||value.trim().isEmpty())return;String v=value.trim();p.setTextSize(size);float width=p.measureText(v);
        if(width>maxWidth){float factor=maxWidth/width;p.setTextSize(Math.max(27f,size*factor));}
        c.save();c.clipRect(x,baseline-p.getTextSize()-8,x+maxWidth,baseline+8);c.drawText(v,x,baseline,p);c.restore();
    }
    void lpuCreateDocx(File out,JSONObject data,Uri photoUri)throws Exception{
        File temp=new File(getCacheDir(),"lpu_template_work.docx");try(InputStream in=getAssets().open("lpu_master_template.docx");FileOutputStream o=new FileOutputStream(temp)){byte[] b=new byte[32768];int n;while((n=in.read(b))>0)o.write(b,0,n);}
        byte[] photoPng=null;
        if(photoUri!=null){
            byte[] imageBytes;try(ZipFile zin=new ZipFile(temp)){java.util.zip.ZipEntry im=zin.getEntry("word/media/image1.png");if(im==null)throw new IOException("Template artwork not found");try(InputStream in=zin.getInputStream(im);ByteArrayOutputStream bo=new ByteArrayOutputStream()){byte[] b=new byte[32768];int n;while((n=in.read(b))>0)bo.write(b,0,n);imageBytes=bo.toByteArray();}}
            Bitmap base=BitmapFactory.decodeByteArray(imageBytes,0,imageBytes.length);if(base==null)throw new IOException("Could not read LPU template artwork");
            BitmapFactory.Options photoBounds=new BitmapFactory.Options();photoBounds.inJustDecodeBounds=true;try(InputStream pin=getContentResolver().openInputStream(photoUri)){BitmapFactory.decodeStream(pin,null,photoBounds);}int sample=1;while(photoBounds.outWidth/sample>1200||photoBounds.outHeight/sample>1200)sample*=2;BitmapFactory.Options photoOptions=new BitmapFactory.Options();photoOptions.inSampleSize=sample;photoOptions.inPreferredConfig=Bitmap.Config.ARGB_8888;Bitmap photo;try(InputStream pin=getContentResolver().openInputStream(photoUri)){photo=BitmapFactory.decodeStream(pin,null,photoOptions);}if(photo==null)throw new IOException("Could not read applicant photograph");
            int x=2085,y=609,w=323,h=359;float ratio=(float)w/h,pr=(float)photo.getWidth()/photo.getHeight();Bitmap crop;
            if(pr>ratio){int nw=Math.max(1,(int)(photo.getHeight()*ratio));crop=Bitmap.createBitmap(photo,(photo.getWidth()-nw)/2,0,nw,photo.getHeight());}else{int nh=Math.max(1,(int)(photo.getWidth()/ratio));crop=Bitmap.createBitmap(photo,0,(photo.getHeight()-nh)/2,photo.getWidth(),nh);}
            Bitmap scaled=Bitmap.createScaledBitmap(crop,w,h,true);Canvas cv=new Canvas(base);cv.drawBitmap(scaled,x,y,new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG));photo.recycle();crop.recycle();scaled.recycle();
            ByteArrayOutputStream png=new ByteArrayOutputStream();base.compress(Bitmap.CompressFormat.PNG,100,png);base.recycle();photoPng=png.toByteArray();
        }
        try(ZipInputStream in=new ZipInputStream(new FileInputStream(temp));ZipOutputStream zout=new ZipOutputStream(new FileOutputStream(out))){
            ZipEntry ent;byte[] buf=new byte[32768];while((ent=in.getNextEntry())!=null){ByteArrayOutputStream bytes=new ByteArrayOutputStream();int n;while((n=in.read(buf))>0)bytes.write(buf,0,n);byte[] raw=bytes.toByteArray();
                if("word/document.xml".equals(ent.getName()))raw=lpuReplaceXml(raw,data);
                if("word/media/image1.png".equals(ent.getName())&&photoPng!=null)raw=photoPng;
                ZipEntry ne=new ZipEntry(ent.getName());zout.putNextEntry(ne);zout.write(raw);zout.closeEntry();in.closeEntry();
            }
        }finally{temp.delete();}
    }
    byte[] lpuReplaceXml(byte[] raw,JSONObject data)throws Exception{
        javax.xml.parsers.DocumentBuilderFactory f=javax.xml.parsers.DocumentBuilderFactory.newInstance();f.setNamespaceAware(true);org.w3c.dom.Document doc=f.newDocumentBuilder().parse(new java.io.ByteArrayInputStream(raw));
        org.w3c.dom.NodeList all=doc.getElementsByTagNameNS("*","txbx");for(int i=0;i<all.getLength();i++){org.w3c.dom.Element box=(org.w3c.dom.Element)all.item(i);lpuReplaceBox(box,data);}
        org.w3c.dom.NodeList vml=doc.getElementsByTagNameNS("urn:schemas-microsoft-com:vml","textbox");for(int i=0;i<vml.getLength();i++)lpuReplaceBox((org.w3c.dom.Element)vml.item(i),data);
        javax.xml.transform.TransformerFactory tf=javax.xml.transform.TransformerFactory.newInstance();javax.xml.transform.Transformer t=tf.newTransformer();t.setOutputProperty(javax.xml.transform.OutputKeys.ENCODING,"UTF-8");t.setOutputProperty(javax.xml.transform.OutputKeys.STANDALONE,"yes");ByteArrayOutputStream o=new ByteArrayOutputStream();t.transform(new javax.xml.transform.dom.DOMSource(doc),new javax.xml.transform.stream.StreamResult(o));return o.toByteArray();
    }
    void lpuReplaceBox(org.w3c.dom.Element box,JSONObject data){org.w3c.dom.NodeList ts=box.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","t");StringBuilder joined=new StringBuilder();for(int j=0;j<ts.getLength();j++)joined.append(ts.item(j).getTextContent());String text=joined.toString();if(text.startsWith("{{")&&text.endsWith("}}")){String key=text.substring(2,text.length()-2);if(data.has(key)){for(int j=0;j<ts.getLength();j++)ts.item(j).setTextContent(j==0?data.optString(key,""):"");}}}
    void lpuRenderDocumentStatus(){
        JSONObject ix=lpuLoadIndex(lpuStudentId);String generated=ix.optString("generated_form","");addText(generated.isEmpty()?"LPU Application Form: Not generated":"✓ LPU Application Form PDF: Generated",12,generated.isEmpty()?Color.rgb(160,75,45):Color.rgb(40,120,70));
        JSONObject form=ix.optJSONObject("form_data");String programme=form==null?"":form.optString("Programme_applied","");JSONObject docs=ix.optJSONObject("documents");if(docs==null)docs=new JSONObject();
        for(String type:lpuDocTypes){String file=docs.optString(type,"");boolean required=lpuDocumentTypeRequired(type,programme);addText(type+(required?" *":"")+": "+(file.isEmpty()?"Not uploaded":"✓ "+new File(file).getName()),11,file.isEmpty()?(required?Color.rgb(160,75,45):Color.GRAY):Color.rgb(40,120,70));}
        addText("* Required for this programme level. Upload one of the stated alternatives where applicable.",10,Color.GRAY);
    }
    boolean lpuDocumentTypeRequired(String type,String programme){String level=lpuProgrammeLevel(programme);if(type.equals("O Level Certificate"))return true;if(type.equals("O Level Statement of Entry"))return "DIPLOMA".equals(level);if(type.equals("Passport")||type.equals("National ID"))return true;if("DEGREE".equals(level))return type.equals("A Level Results Slip")||type.equals("A Level Statement of Entry")||type.equals("Diploma Transcript");if("MASTERS".equals(level)||"PHD".equals(level))return type.equals("A Level Results Slip")||type.equals("Diploma Transcript")||type.equals("Degree Transcript");return false;
    }
    String lpuExtension(Uri uri){try{String n="";android.database.Cursor c=getContentResolver().query(uri,null,null,null,null);if(c!=null){if(c.moveToFirst()){int k=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);if(k>=0)n=c.getString(k);}c.close();}int d=n.lastIndexOf(".");return d>=0?n.substring(d).toLowerCase(Locale.ROOT):".jpg";}catch(Exception e){return ".jpg";}}
    void lpuStoreDocument(Uri uri,String type)throws Exception{
        String name="";try(android.database.Cursor c=getContentResolver().query(uri,null,null,null,null)){if(c!=null&&c.moveToFirst()){int ix=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);if(ix>=0)name=c.getString(ix);}}
        String ext="";int dot=name.lastIndexOf('.');if(dot>=0)ext=name.substring(dot).toLowerCase(Locale.ROOT);if(!ext.matches("\\.(pdf|doc|docx|jpg|jpeg|png|webp)"))throw new IOException("Supported formats: PDF, Word, JPG, PNG and WEBP.");
        JSONObject form=lpuLoadIndex(lpuStudentId).optJSONObject("form_data");String student=form==null?"Applicant":form.optString("Student_Name","Applicant");
        String filename=type+" for "+lpuSafe(student)+ext;File dest=new File(lpuFolder(lpuStudentId),filename);
        try(InputStream in=getContentResolver().openInputStream(uri);FileOutputStream o=new FileOutputStream(dest)){if(in==null)throw new IOException("Cannot open selected file");byte[] b=new byte[32768];int n;while((n=in.read(b))>0)o.write(b,0,n);}
        JSONObject ix=lpuLoadIndex(lpuStudentId);JSONObject docs=ix.optJSONObject("documents");if(docs==null)docs=new JSONObject();docs.put(type,dest.getAbsolutePath());ix.put("documents",docs);lpuSaveIndex(lpuStudentId,ix);
    }
    void lpuPrepareEmail(){
        JSONObject ix=lpuLoadIndex(lpuStudentId);String form=ix.optString("generated_form","");if(!form.isEmpty()&&form.toLowerCase(Locale.ROOT).endsWith(".docx")){try{JSONObject oldData=ix.optJSONObject("form_data");if(oldData==null)oldData=new JSONObject();String photo=ix.optString("photo_path","");Uri photoUri=(!photo.isEmpty()&&new File(photo).exists())?Uri.fromFile(new File(photo)):null;File converted=new File(lpuFolder(lpuStudentId),"LPU Application Form for "+lpuSafe(oldData.optString("Student_Name","Applicant"))+".pdf");lpuCreatePdf(converted,oldData,photoUri);form=converted.getAbsolutePath();ix.put("generated_form",form);ix.put("generated_at",System.currentTimeMillis());lpuSaveIndex(lpuStudentId,ix);}catch(Exception ex){toast("Could not convert the existing LPU form to PDF: "+ex.getMessage());return;}}if(form.isEmpty()||!new File(form).exists()){toast("Generate the LPU Application Form PDF first.");return;}
        JSONObject d=ix.optJSONObject("form_data");if(d==null)d=new JSONObject();String programme=d.optString("Programme_applied","");String student=d.optString("Student_Name","Applicant");
        String level=lpuProgrammeLevel(studentDb.getStudent(lpuStudentId).optString("programme",programme));JSONObject docs=ix.optJSONObject("documents");if(docs==null)docs=new JSONObject();
        boolean hasO=docs.has("O Level Certificate")||("DIPLOMA".equals(level)&&docs.has("O Level Statement of Entry"));
        boolean hasId=docs.has("Passport")||docs.has("National ID");
        boolean hasAcademic=false;
        if("DEGREE".equals(level))hasAcademic=docs.has("A Level Results Slip")||docs.has("A Level Statement of Entry")||docs.has("Diploma Transcript");
        else if("MASTERS".equals(level)||"PHD".equals(level))hasAcademic=docs.has("A Level Results Slip")||docs.has("Diploma Transcript");
        boolean hasDegreeTranscript=docs.has("Degree Transcript");
        if("PHD".equals(level)){new AlertDialog.Builder(this).setTitle("PHD requirements need confirmation").setMessage("The required supporting-document rules for PHD applications have not yet been specified. Please confirm them before submitting this application.").setPositiveButton("OK",null).show();return;}
        ArrayList<String> missing=new ArrayList<>();if(!hasO)missing.add("O Level Certificate"+("DIPLOMA".equals(level)?" or O Level Statement of Entry":""));
        if(("DEGREE".equals(level)||"MASTERS".equals(level)||"PHD".equals(level))&&!hasAcademic)missing.add("the required A Level / Diploma academic document");
        if(("MASTERS".equals(level)||"PHD".equals(level))&&!hasDegreeTranscript)missing.add("Degree Transcript");
        if(!hasId)missing.add("Passport or National ID");
        if(!missing.isEmpty()){new AlertDialog.Builder(this).setTitle("Required documents missing").setMessage("Please upload: "+android.text.TextUtils.join("; ",missing)+" before preparing the email. Optional documents may be left empty.").setPositiveButton("OK",null).show();return;}
        ArrayList<File> files=new ArrayList<>();files.add(new File(form));for(String type:lpuDocTypes){String p=docs.optString(type,"");if(!p.isEmpty()&&new File(p).exists())files.add(new File(p));}
        ArrayList<Uri> uris=new ArrayList<>();for(File file:files){try{File cache=new File(getCacheDir(),file.getName());try(InputStream in=new FileInputStream(file);FileOutputStream o=new FileOutputStream(cache)){byte[] b=new byte[32768];int n;while((n=in.read(b))>0)o.write(b,0,n);}uris.add(Uri.parse("content://com.globalminds.admission.pdfprovider/"+Uri.encode(cache.getName())));}catch(Exception e){toast("Could not prepare attachment: "+file.getName());return;}}
        Intent send=new Intent(Intent.ACTION_SEND_MULTIPLE);send.setType("*/*");send.putParcelableArrayListExtra(Intent.EXTRA_STREAM,uris);send.putExtra(Intent.EXTRA_SUBJECT,"Application for "+student+": "+programme);send.putExtra(Intent.EXTRA_TEXT,"Please find attached the LPU application form and supporting documents for "+student+".");send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);android.content.ClipData clip=android.content.ClipData.newUri(getContentResolver(),"LPU application",uris.get(0));for(int i=1;i<uris.size();i++)clip.addItem(new android.content.ClipData.Item(uris.get(i)));send.setClipData(clip);try{startActivity(Intent.createChooser(send,"Send LPU application"));}catch(Exception e){toast("No compatible email application is available.");}
    }

    void drawCompanyLogoBadge(Canvas c,float cx,float cy,float radius){
        // Invoice/receipt header logo: use the supplied GlobalMinds fingerprint mark directly.
        // No circular frame, no clipping and no distortion. The company name is rendered separately beside it.
        Bitmap bm=BitmapFactory.decodeResource(getResources(),R.drawable.invoice_company_logo);
        if(bm==null)return;
        float maxW=radius*2.0f,maxH=radius*2.0f;
        float scale=Math.min(maxW/bm.getWidth(),maxH/bm.getHeight());
        float w=bm.getWidth()*scale,h=bm.getHeight()*scale;
        RectF dst=new RectF(cx-w/2f,cy-h/2f,cx+w/2f,cy+h/2f);
        Paint bp=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG|Paint.DITHER_FLAG);
        bp.setFilterBitmap(true);
        c.drawBitmap(bm,null,dst,bp);
        bm.recycle();
    }
    void generateSimpleDoc(JSONObject st,String type){if(type.equals("Invoice")||type.equals("Payment Receipt")){generateFinancialDocument(st,type);return;}try{
        PdfDocument doc=new PdfDocument();PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());Canvas c=page.getCanvas();c.drawColor(Color.WHITE);Paint p=new Paint(3);
        p.setColor(purple);c.drawRect(0,0,595,112,p);p.setColor(Color.WHITE);p.setTextSize(12);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));c.drawText("GLOBAL MINDS EDUCATION",38,34,p);p.setTextSize(21);c.drawText(type,38,68,p);p.setTextSize(9);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));c.drawText("STUDENT SUPPORT • INTERNATIONAL EDUCATION",38,91,p);
        p.setColor(Color.rgb(248,246,251));c.drawRoundRect(34,130,561,218,10,10,p);p.setColor(purpleDark);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(9);c.drawText("STUDENT DETAILS",48,150,p);
        p.setColor(Color.DKGRAY);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setTextSize(10);c.drawText("Student",48,170,p);c.drawText("Student ID",330,170,p);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));c.drawText(st.optString("name"),48,187,p);c.drawText(st.optString("student_id"),330,187,p);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));c.drawText("Programme",48,205,p);c.drawText("Current stage",330,205,p);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));c.drawText(clipPdf(st.optString("programme"),43),48,214,p);c.drawText(clipPdf(st.optString("stage"),27),330,214,p);
        JSONObject pay=studentDb.latestPayment(st.optLong("id"));String receiptNumber="";if(type.equals("Payment Receipt")&&pay.has("id")&&"ACTIVE".equals(pay.optString("status","ACTIVE"))){receiptNumber=studentDb.registerReceipt(pay.optLong("id"));studentDb.audit("PAYMENT",String.valueOf(pay.optLong("id")),"Receipt generated", "", receiptNumber, "Receipt generated for payment", auditActorName());}double ex=st.optDouble("expected_amount"),pd=studentDb.paid(st.optLong("id"));ArrayList<String[]> rows=new ArrayList<>();
        if(type.equals("Application Checklist")){String[][] a={{"01","Academic certificates and transcripts","Pending"},{"02","Passport / identity document","Pending"},{"03","Programme prerequisites confirmed","Pending"},{"04","Application form completed","Pending"},{"05","Supporting documents submitted","Pending"},{"06","Submission date recorded","Pending"},{"07","University response followed up","Pending"}};Collections.addAll(rows,a);}
        else if(type.equals("Travel-readiness Checklist")){String[][] a={{"01","Visa decision checked","Pending"},{"02","Flight booking confirmed","Pending"},{"03","Accommodation arrangements confirmed","Pending"},{"04","Airport pickup / arrival plan discussed","Pending"},{"05","Emergency contacts shared","Pending"},{"06","University reporting instructions shared","Pending"},{"07","Registration deadlines checked","Pending"}};Collections.addAll(rows,a);}
        else if(type.equals("Student Arrival and Follow-up Report")){String[][] a={{"01","Arrival date","________________________________"},{"02","Airport arrival confirmed","________________________________"},{"03","Accommodation confirmed","________________________________"},{"04","University reporting date","________________________________"},{"05","Initial welfare check completed","________________________________"},{"06","Follow-up notes","________________________________"},{"07","Next action / responsible staff","________________________________"}};Collections.addAll(rows,a);}
        else if(type.equals("Invoice")){Collections.addAll(rows,new String[][]{{"01","Invoice amount recorded",money(ex)},{"02","Payments recorded to date",money(pd)},{"03","Balance currently outstanding",money(Math.max(0,ex-pd))},{"04","Payment deadline",st.optString("due_date").isEmpty()?"Not set":st.optString("due_date")},{"05","Payment instructions","Use approved instructions from Global Minds Education"}});}
        else if(type.equals("Payment Receipt")){Collections.addAll(rows,new String[][]{{"01","Receipt number",receiptNumber.isEmpty()?"NO ACTIVE PAYMENT":receiptNumber},{"02","Receipt status",pay.has("amount")?"Payment entry recorded":"NO PAYMENT RECORDED"},{"03","Amount recorded",pay.has("amount")?money(pay.optDouble("amount")):"USD 0.00"},{"04","Payment date",pay.has("payment_date")?dateText(pay.optLong("payment_date")):"Not available"},{"05","Payment method / reference",pay.optString("method","Not recorded")+" / "+pay.optString("transaction_reference","Not recorded")},{"06","Transaction note",pay.optString("note","Not recorded")}});}
        else{Collections.addAll(rows,new String[][]{{"01","Expected amount recorded",money(ex)},{"02","Total payments recorded",money(pd)},{"03","Outstanding balance",money(Math.max(0,ex-pd))},{"04","Payment deadline",st.optString("due_date").isEmpty()?"Not set":st.optString("due_date")},{"05","Latest payment",pay.has("amount")?money(pay.optDouble("amount"))+" on "+dateText(pay.optLong("payment_date")):"No payment recorded"},{"06","Payment method / reference",pay.optString("method","Not recorded")}});}
        float y=245;p.setColor(purpleDark);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(10);c.drawText(type.contains("Checklist")?"COMPLETION CHECKLIST":type.equals("Invoice")||type.contains("Payment")?"FINANCIAL DETAILS":"ARRIVAL & FOLLOW-UP RECORD",40,y,p);y+=14;
        p.setTextSize(9);c.drawRect(38,y,557,y+24,new Paint(3){{setColor(purple);}});p.setColor(Color.WHITE);c.drawText("#",48,y+15,p);c.drawText("ITEM / DESCRIPTION",80,y+15,p);c.drawText("STATUS / DETAILS",360,y+15,p);y+=24;
        for(int ri=0;ri<rows.size();ri++){String[] row=rows.get(ri);float h=type.equals("Student Arrival and Follow-up Report")?37:30;p.setColor(ri%2==0?Color.rgb(249,247,251):Color.WHITE);c.drawRect(38,y,557,y+h,p);p.setColor(Color.rgb(225,218,233));c.drawLine(38,y+h,557,y+h,p);c.drawLine(70,y,70,y+h,p);c.drawLine(350,y,350,y+h,p);p.setColor(purpleDark);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(9);c.drawText(row[0],48,y+17,p);p.setColor(Color.DKGRAY);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));c.drawText(clipPdf(row[1],39),80,y+17,p);c.drawText(clipPdf(row[2],30),360,y+17,p);y+=h;}
        if(y>680)y=680;
        p.setColor(purpleDark);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(9);c.drawText("OFFICE AUTHORISATION",40, y+17,p);p.setColor(Color.GRAY);c.drawLine(40,y+62,245,y+62,p);c.drawLine(330,y+62,535,y+62,p);drawBrandingImage(c,"signature_uri",44,y+14,225,y+76);drawBrandingImage(c,"stamp_uri",365,y+8,505,y+82);
        android.content.SharedPreferences brand=getSharedPreferences("gme_document_branding",MODE_PRIVATE);p.setColor(Color.DKGRAY);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(9);c.drawText(clipPdf(brand.getString("signatory_name","Authorised Signatory"),32),40,y+76,p);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));c.drawText(clipPdf(brand.getString("signatory_role","Global Minds Education"),32),40,y+89,p);c.drawText("Date: "+dateText(System.currentTimeMillis()),330,y+82,p);
        p.setColor(Color.GRAY);p.setTextSize(8);c.drawText("Generated: "+dateText(System.currentTimeMillis())+" • Global Minds Education",40,818,p);
        doc.finishPage(page);String documentFileName=safe(st.optString("student_id"))+"_"+safe(type)+(type.equals("Payment Receipt")&&!receiptNumber.isEmpty()?"_"+safe(receiptNumber):"")+".pdf";File f=new File(getCacheDir(),documentFileName);FileOutputStream out=new FileOutputStream(f);doc.writeTo(out);out.close();doc.close();share(f);
    }catch(Exception e){toast("Could not generate document: "+e.getMessage());}}
    void generateFinancialDocument(JSONObject st,String type){
        try{
            boolean invoice=type.equals("Invoice");
            JSONObject pay=studentDb.latestPayment(st.optLong("id"));
            String receiptNumber="";
            if(!invoice&&pay.has("id")&&"ACTIVE".equals(pay.optString("status","ACTIVE"))){
                receiptNumber=studentDb.registerReceipt(pay.optLong("id"));
                studentDb.audit("PAYMENT",String.valueOf(pay.optLong("id")),"Receipt generated", "", receiptNumber, "Receipt generated for payment", auditActorName());
            }
            double amount=invoice?st.optDouble("expected_amount"):pay.optDouble("amount",0);
            String currency=invoice?"USD":pay.optString("currency","USD").toUpperCase(Locale.US);
            String docNumber=invoice?"GME-INV-"+new SimpleDateFormat("yyMMddHHmm",Locale.US).format(new Date()):receiptNumber;
            String docDate=invoice?dateText(System.currentTimeMillis()):(pay.has("payment_date")?dateText(pay.optLong("payment_date")):dateText(System.currentTimeMillis()));
            PdfDocument doc=new PdfDocument();
            PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());
            Canvas c=page.getCanvas(); c.drawColor(Color.WHITE); Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
            int left=42,right=553;
            // Header: clean white business-document style, matching the supplied invoice/receipt reference.
            p.setColor(Color.rgb(57,28,83));p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(13);c.drawText("GLOBALMINDS",left+42,49,p);c.drawText("EDUCATION PVT. LTD",left+42,65,p);
            drawCompanyLogoBadge(c,left+14,55,17);
            p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setTextSize(8.5f);p.setColor(Color.DKGRAY);
            c.drawText("globalmindsstudy.com",left,94,p);c.drawText("globalmindseducation01@gmail.com",left,107,p);c.drawText("6012 New Cearney Park Harare, Zimbabwe",left,120,p);c.drawText("+263 78 277 7659",left,133,p);c.drawText("ZIP/Postal Code: 00000",left,146,p);c.drawText("TIN : 2002125902",left,159,p);
            p.setColor(Color.rgb(35,31,40));p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(15);c.drawText(invoice?"INVOICE":"PAYMENT RECEIPT",365,94,p);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(9.5f);c.drawText(docNumber,365,112,p);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));c.drawText("Date: "+docDate,365,128,p);
            // Billed/received from block.
            p.setColor(Color.rgb(35,31,40));p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(10);c.drawText(invoice?"Billed To:":"Received From:",left,197,p);
            p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(11);c.drawText(clipPdf(st.optString("name","Student"),34),left,216,p);
            p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setTextSize(8.5f);String addr=st.optString("city_province",st.optString("city", ""));if(addr.isEmpty())addr=st.optString("province","");c.drawText("Address: "+clipPdf(addr,58),left,232,p);c.drawText("Phone Number: "+clipPdf(st.optString("phone",""),40),left,246,p);
            // Table.
            float top=278; p.setColor(Color.rgb(228,223,232));c.drawLine(left,top,right,top,p);c.drawLine(left,top+42,right,top+42,p);
            p.setColor(Color.rgb(35,31,40));p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(9.5f);c.drawText("Description",left+8,top+26,p);c.drawText("Amount",right-78,top+26,p);
            String description=invoice?"Tuition fee ("+clipPdf(st.optString("programme","Student programme"),42)+")":"Payment received for "+clipPdf(st.optString("programme","student fees"),38);
            p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setTextSize(9);c.drawText(clipPdf(description,68),left+8,top+72,p);c.drawText(currency+" "+String.format(Locale.US,"%,.2f",amount),right-110,top+72,p);
            p.setColor(Color.rgb(235,232,238));c.drawLine(left,top+92,right,top+92,p);
            p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(10);c.drawText("Total",350,top+122,p);c.drawText(currency+" "+String.format(Locale.US,"%,.2f",amount),right-110,top+122,p);
            if(!invoice){p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setTextSize(8.5f);c.drawText("Payment method: "+clipPdf(pay.optString("method","Not recorded"),34),left,top+122,p);c.drawText("Reference: "+clipPdf(pay.optString("transaction_reference","Not recorded"),36),left,top+138,p);}
            p.setTypeface(Typeface.create("sans-serif",Typeface.ITALIC));p.setTextSize(10);p.setColor(Color.DKGRAY);c.drawText("\"Bridging the gap between Ambition & Opportunity\"",left,top+180,p);
            // Office authorisation with non-distorted signature and stamp.
            float authY=top+250;p.setColor(Color.rgb(35,31,40));p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(9.5f);c.drawText("OFFICE AUTHORISATION",left,authY,p);
            drawBrandingImage(c,"signature_uri",left,authY+8,225,authY+78);drawBrandingImage(c,"stamp_uri",360,authY+2,505,authY+82);
            p.setColor(Color.GRAY);p.setStrokeWidth(1);c.drawLine(left,authY+76,245,authY+76,p);c.drawLine(330,authY+76,535,authY+76,p);
            android.content.SharedPreferences brand=getSharedPreferences("gme_document_branding",MODE_PRIVATE);p.setColor(Color.DKGRAY);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(8.5f);c.drawText(clipPdf(brand.getString("signatory_name","Authorised Signatory"),32),left,authY+91,p);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));c.drawText(clipPdf(brand.getString("signatory_role","Global Minds Education"),32),left,authY+104,p);
            p.setColor(Color.GRAY);p.setTextSize(7.5f);c.drawText("Global Minds Education",left,810,p);c.drawText((invoice?"Invoice":"Receipt")+" • "+docNumber,right-150,810,p);
            doc.finishPage(page);
            String documentFileName=safe(st.optString("student_id"))+"_"+safe(type)+(receiptNumber.isEmpty()?"":"_"+safe(receiptNumber))+".pdf";
            File f=new File(getCacheDir(),documentFileName);FileOutputStream out=new FileOutputStream(f);doc.writeTo(out);out.close();doc.close();share(f);
        }catch(Exception e){toast("Could not generate document: "+e.getMessage());}
    }
    String clipPdf(String value,int max){if(value==null)return "";String v=value.replace('\n',' ').trim();return v.length()>max?v.substring(0,Math.max(0,max-1))+"…":v;}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    void restorePreviousScreen(){
        if(!isUnlocked){finish();return;}
        if(screenHistory.empty()){finish();return;}
        restoringScreen=true;
        try{
            root=screenHistory.pop();
            currentRefreshAction=refreshHistory.empty()?null:refreshHistory.pop();
            setContentView(root);
            LinearLayout header=(LinearLayout)root.getChildAt(0);
            title=(TextView)header.getChildAt(1);
            ScrollView sc=(ScrollView)root.getChildAt(1);
            content=(LinearLayout)sc.getChildAt(0);
        }catch(Exception e){screenHistory.clear();refreshHistory.clear();finish();}
        finally{restoringScreen=false;}
        refreshCurrentScreen();
        if(root!=null){
            root.setAlpha(0f);
            root.setTranslationX(dp(22));
            root.animate().alpha(1f).translationX(0f)
                .setDuration(230)
                .setInterpolator(new android.view.animation.DecelerateInterpolator())
                .start();
        }
    }
    @Override public void onBackPressed(){restorePreviousScreen();}
}
