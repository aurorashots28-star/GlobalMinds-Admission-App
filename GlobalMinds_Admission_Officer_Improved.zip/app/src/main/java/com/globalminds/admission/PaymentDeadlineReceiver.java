package com.globalminds.admission;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;

/** Delivers locally scheduled 7-day and 1-day payment deadline notices. */
public class PaymentDeadlineReceiver extends BroadcastReceiver {
    private static final String CHANNEL = "gme_payment_deadlines";

    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String name = intent.getStringExtra("student_name");
        String code = intent.getStringExtra("student_code");
        String due = intent.getStringExtra("due_date");
        int lead = intent.getIntExtra("lead_days", 0);
        double remaining = intent.getDoubleExtra("remaining", 0d);
        long studentId = intent.getLongExtra("student_id", 0L);
        if (studentId <= 0 || lead <= 0 || (lead != 1 && lead != 7)) return;
        if (name == null || name.trim().isEmpty()) name = "Student";
        if (code == null) code = "";
        if (due == null) due = "the recorded deadline";

        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Payment deadline alerts", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Local reminders for accepted students with outstanding balances");
            manager.createNotificationChannel(channel);
        }
        String title = lead == 1 ? "Payment due tomorrow" : "Payment due in 7 days";
        String body = name + (code.isEmpty() ? "" : " • " + code) + " — deadline " + due + ". Outstanding: USD " + String.format(java.util.Locale.US, "%.2f", remaining);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);
        try { manager.notify((int)((studentId * 37L + lead * 13L) & 0x7fffffff), builder.build()); }
        catch (SecurityException ignored) { }
    }
}
