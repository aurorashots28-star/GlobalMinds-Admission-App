<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/db.php';
$serial = trim((string)($_GET['serial'] ?? ''));
$record = null; $error = '';
if ($serial === '' || !preg_match('/^GME-ARC-[0-9]{4}-[A-F0-9]{16}$/', $serial)) {
    $error = 'The document serial number is missing or invalid.';
} else {
    $stmt = $pdo->prepare('SELECT serial, document_type, student_name, student_id, application_reference, registration_date, status, issued_at FROM gme_documents WHERE serial = ? LIMIT 1');
    $stmt->execute([$serial]); $record = $stmt->fetch();
    if (!$record) $error = 'No document with this serial number was found in the GlobalMinds registry.';
}
$valid = $record && $record['status'] === 'VALID';
$revoked = $record && $record['status'] === 'REVOKED';
$institution = $config['institution'] ?? 'GlobalMinds Education';
$email = $config['email'] ?? 'admissions@globalmindsstudy.com';
$phone = $config['phone'] ?? '+91 90415 74079';
function label(string $s): string { return ucwords(strtolower(str_replace('_',' ',$s))); }
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Document Verification | <?=h($institution)?></title><style>
:root{--purple:#392052;--violet:#673b91;--pale:#f5f0f9;--ink:#292431;--muted:#716b78;--green:#137443;--red:#a32626;--amber:#8a5a00}*{box-sizing:border-box}body{margin:0;background:#f4f2f6;color:var(--ink);font:16px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}.wrap{max-width:720px;margin:34px auto;padding:0 16px}.card{background:#fff;border:1px solid #e6e0eb;border-radius:18px;overflow:hidden;box-shadow:0 10px 32px #24143212}.head{background:var(--purple);color:#fff;padding:25px 26px}.brand{font-weight:800;letter-spacing:.08em;font-size:15px}.tag{font-size:12px;opacity:.82;margin-top:4px}.body{padding:26px}.eyebrow{font-size:12px;letter-spacing:.1em;font-weight:800;color:var(--violet)}h1{font-size:27px;margin:6px 0 18px}.status{display:inline-flex;align-items:center;gap:8px;border-radius:999px;padding:7px 13px;font-size:13px;font-weight:800;margin-bottom:16px}.ok{background:#e8f5ed;color:var(--green)}.bad{background:#fcecec;color:var(--red)}.unknown{background:#fff4db;color:var(--amber)}.intro{color:var(--muted);margin:0 0 20px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px 22px;border-top:1px solid #eee8f2;padding-top:20px}.item small{display:block;color:var(--muted);font-size:11px;font-weight:800;letter-spacing:.06em;margin-bottom:3px}.item strong{overflow-wrap:anywhere}.notice{background:var(--pale);border-radius:12px;padding:14px;margin-top:22px}.foot{color:var(--muted);font-size:13px;text-align:center;padding:18px}.foot a{color:var(--violet)}@media(max-width:520px){.wrap{margin:12px auto}.head,.body{padding:20px}.grid{grid-template-columns:1fr}h1{font-size:23px}}
</style></head><body><main class="wrap"><section class="card"><header class="head"><div class="brand"><?=h($institution)?></div><div class="tag">OFFICIAL DOCUMENT AUTHENTICITY CHECK</div></header><div class="body"><div class="eyebrow">DOCUMENT VERIFICATION</div><h1>Verification Result</h1>
<?php if ($valid): ?><div class="status ok">✓ VALID — OFFICIALLY REGISTERED</div><p class="intro">This document record exists in the official <?=h($institution)?> verification registry. The details below match the record registered by the institution.</p>
<?php elseif ($revoked): ?><div class="status bad">! REVOKED — NOT VALID FOR USE</div><p class="intro">This document was previously registered but has since been revoked by <?=h($institution)?>. Do not rely on it as a valid confirmation.</p>
<?php else: ?><div class="status unknown">? NOT FOUND — NOT VERIFIED</div><p class="intro"><?=h($error)?> This result does not confirm that the document was issued by <?=h($institution)?>.</p><?php endif; ?>
<div class="grid"><div class="item"><small>INSTITUTION</small><strong><?=h($institution)?></strong></div><div class="item"><small>DOCUMENT TYPE</small><strong><?=h($record ? label($record['document_type']) : 'Application Registration Confirmation')?></strong></div><div class="item"><small>DOCUMENT SERIAL</small><strong><?=h($serial)?></strong></div><?php if($record): ?><div class="item"><small>STUDENT NAME</small><strong><?=h($record['student_name'])?></strong></div><div class="item"><small>STUDENT ID</small><strong><?=h($record['student_id'])?></strong></div><div class="item"><small>APPLICATION REFERENCE</small><strong><?=h($record['application_reference'])?></strong></div><div class="item"><small>REGISTRATION DATE</small><strong><?=h($record['registration_date'])?></strong></div><div class="item"><small>DOCUMENT STATUS</small><strong><?=h($record['status'])?></strong></div><?php endif; ?></div>
<div class="notice"><strong>Need assistance?</strong><br>Email: <a href="mailto:<?=h($email)?>"><?=h($email)?></a><br>Phone: <?=h($phone)?></div></div></section><div class="foot">© <?=date('Y')?> <?=h($institution)?> · This page checks the institution's online document registry.</div></main></body></html>
