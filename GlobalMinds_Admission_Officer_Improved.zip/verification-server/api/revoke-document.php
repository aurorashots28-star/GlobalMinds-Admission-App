<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/db.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['success'=>false,'message'=>'POST required.']); exit; }
require_api_key($config);
$input=json_decode(file_get_contents('php://input'),true); $serial=trim((string)($input['serial']??''));
if (!preg_match('/^GME-ARC-[0-9]{4}-[A-F0-9]{16}$/',$serial)) { http_response_code(422); echo json_encode(['success'=>false,'message'=>'Invalid serial.']); exit; }
$stmt=$pdo->prepare("UPDATE gme_documents SET status='REVOKED', revoked_at=CURRENT_TIMESTAMP WHERE serial=?"); $stmt->execute([$serial]);
if ($stmt->rowCount() < 1) { $check=$pdo->prepare('SELECT status FROM gme_documents WHERE serial=?'); $check->execute([$serial]); $row=$check->fetch(); if (!$row) { http_response_code(404); echo json_encode(['success'=>false,'message'=>'Serial not found.']); exit; } }
echo json_encode(['success'=>true,'message'=>'Document marked as revoked.','serial'=>$serial,'status'=>'REVOKED']);
