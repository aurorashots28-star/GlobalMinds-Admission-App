<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/db.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['success'=>false,'message'=>'POST required.']); exit; }
require_api_key($config);
$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) { http_response_code(400); echo json_encode(['success'=>false,'message'=>'Invalid JSON.']); exit; }
$serial = trim((string)($input['serial'] ?? ''));
$type = trim((string)($input['document_type'] ?? ''));
$name = trim((string)($input['student_name'] ?? ''));
$id = trim((string)($input['student_id'] ?? ''));
$ref = trim((string)($input['application_reference'] ?? ''));
$date = trim((string)($input['registration_date'] ?? ''));
if (!preg_match('/^GME-ARC-[0-9]{4}-[A-F0-9]{16}$/', $serial) || $type !== 'APPLICATION_REGISTRATION_CONFIRMATION' || $name === '' || $id === '' || $ref === '' || $date === '') {
    http_response_code(422); echo json_encode(['success'=>false,'message'=>'Required document fields are missing or invalid.']); exit;
}
try {
    $stmt = $pdo->prepare('INSERT INTO gme_documents (serial, document_type, student_name, student_id, application_reference, registration_date, status) VALUES (?, ?, ?, ?, ?, ?, \'VALID\')');
    $stmt->execute([$serial,$type,$name,$id,$ref,$date]);
    echo json_encode(['success'=>true,'message'=>'Document registered.','serial'=>$serial]);
} catch (PDOException $e) {
    if ($e->getCode() === '23000') {
        $check = $pdo->prepare('SELECT student_id, application_reference, status FROM gme_documents WHERE serial=?'); $check->execute([$serial]); $existing=$check->fetch();
        if ($existing && hash_equals((string)$existing['student_id'],$id) && hash_equals((string)$existing['application_reference'],$ref) && $existing['status']==='VALID') {
            echo json_encode(['success'=>true,'message'=>'Document was already registered.','serial'=>$serial]);
        } else { http_response_code(409); echo json_encode(['success'=>false,'message'=>'Serial already exists with a different or revoked record.']); }
    } else { http_response_code(500); echo json_encode(['success'=>false,'message'=>'Could not register document.']); }
}
