CREATE TABLE IF NOT EXISTS gme_documents (
  serial VARCHAR(48) NOT NULL PRIMARY KEY,
  document_type VARCHAR(80) NOT NULL,
  student_name VARCHAR(180) NOT NULL,
  student_id VARCHAR(80) NOT NULL,
  application_reference VARCHAR(100) NOT NULL,
  registration_date VARCHAR(40) NOT NULL,
  status ENUM('VALID','REVOKED') NOT NULL DEFAULT 'VALID',
  issued_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  revoked_at TIMESTAMP NULL DEFAULT NULL,
  INDEX idx_student_id (student_id),
  INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
