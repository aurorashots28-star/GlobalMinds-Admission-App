<?php
// Copy to config.php, fill in the database values and generate a long random API key.
// Keep config.php private; never upload it to a public source-code repository.
return [
    'db_host' => 'localhost',
    'db_name' => 'globalminds_verification',
    'db_user' => 'YOUR_DATABASE_USER',
    'db_pass' => 'YOUR_DATABASE_PASSWORD',
    'api_key' => 'REPLACE_WITH_AT_LEAST_40_RANDOM_CHARACTERS',
    'institution' => 'GlobalMinds Education',
    'email' => 'admissions@globalmindsstudy.com',
    'phone' => '+91 90415 74079',
];
