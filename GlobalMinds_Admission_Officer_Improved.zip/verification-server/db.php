<?php
declare(strict_types=1);
$configFile = __DIR__ . '/config.php';
if (!is_file($configFile)) { http_response_code(503); exit('Verification service setup is incomplete.'); }
$config = require $configFile;
try {
    $pdo = new PDO(
        'mysql:host=' . $config['db_host'] . ';dbname=' . $config['db_name'] . ';charset=utf8mb4',
        $config['db_user'], $config['db_pass'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
} catch (Throwable $e) { http_response_code(503); exit('Verification service is temporarily unavailable.'); }
function h(string $value): string { return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function require_api_key(array $config): void {
    $provided = $_SERVER['HTTP_X_GME_API_KEY'] ?? '';
    if ($provided === '' || empty($config['api_key']) || !hash_equals((string)$config['api_key'], $provided)) {
        http_response_code(401); header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'message' => 'Unauthorised API request.']); exit;
    }
}
