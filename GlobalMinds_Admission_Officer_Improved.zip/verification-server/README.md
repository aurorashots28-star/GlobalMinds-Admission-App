# GlobalMinds online document verification service

This is the server-side companion for Android app v2.35. The QR in each Application Registration Confirmation opens:

`https://globalmindsstudy.com/verify-document/?serial=GME-ARC-YYYY-XXXXXXXXXXXXXXXX`

The page displays **VALID**, **REVOKED**, or **NOT FOUND** based on the MySQL registry. It does not trust the serial by itself.

## Hosting requirements

- PHP 8.1+ with PDO MySQL enabled
- MySQL 5.7+ / MariaDB 10.4+
- HTTPS enabled for `globalmindsstudy.com`

## Deploy

1. Back up the existing website and database.
2. Create a MySQL database and user with least-privilege access.
3. Import `schema.sql` into that database.
4. Copy `config.example.php` to `config.php`; enter DB host/name/user/password and generate a random API key of at least 40 characters. Keep `config.php` private and never commit it to a public repository. The API key must be the same value entered in the Android app's Document Centre → Online Document Verification Settings.
5. Upload the contents of this folder to the website document root, merging folders carefully. The resulting paths must be `/verify-document/index.php`, `/api/register-document.php`, and `/api/revoke-document.php`.
6. Confirm HTTPS works and test `/verify-document/?serial=GME-ARC-2026-0000000000000000` (expected result: NOT FOUND).
7. In the Android app, open Document Centre → Online Document Verification Settings. Set website URL to `https://globalmindsstudy.com` and paste the API key. Save settings.
8. Generate a NEW test registration confirmation while the phone has internet. The app posts the document record to the server. Scan its QR; it should display VALID and the matching record details.

## API

`POST /api/register-document.php` requires `X-GME-API-Key` and JSON fields: `serial`, `document_type`, `student_name`, `student_id`, `application_reference`, `registration_date`, `status`. It only accepts registration-confirmation serials matching `GME-ARC-YYYY-16HEX` and registers them as VALID. Duplicate identical submissions are idempotent; conflicting or revoked serials are rejected.

`POST /api/revoke-document.php` requires the same key and JSON `{ "serial": "..." }`. It marks a known record REVOKED. Keep this endpoint private and rotate the API key if staff access changes.

## Security and privacy notes

- Use HTTPS only. Do not share the API key publicly. Android app settings store the key on the device; an API key embedded in a distributed APK can be extracted, so treat it as a scoped operational credential, rotate it when needed, and restrict server access/rate-limit endpoints at the hosting layer.
- Verification page shows only fields needed to identify the issued document. Do not add phone, passport, date of birth, financial, or other sensitive student information.
- The page shows NOT FOUND until the issuing app successfully registers the serial. Offline PDF generation is still allowed; if registration fails, that document must not be described as online verified. Generate a new confirmation after fixing connectivity/settings or manually register the record through a protected administrative process.
- This package is deployable source, not a website deployment. Website hosting access and database credentials are required to make the public QR verification live.
