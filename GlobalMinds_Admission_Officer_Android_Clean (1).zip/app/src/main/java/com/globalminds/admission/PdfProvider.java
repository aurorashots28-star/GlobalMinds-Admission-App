package com.globalminds.admission;
import android.content.*;import android.database.Cursor;import android.database.MatrixCursor;import android.net.Uri;import android.os.*;import java.io.*;
public class PdfProvider extends ContentProvider{
 public boolean onCreate(){return true;} public String getType(Uri u){return "application/pdf";}
 public android.os.ParcelFileDescriptor openFile(Uri u,String mode)throws FileNotFoundException{return ParcelFileDescriptor.open(new File(getContext().getCacheDir(),u.getLastPathSegment()),ParcelFileDescriptor.MODE_READ_ONLY);}
 public Cursor query(Uri u,String[] p,String a,String[] b,String s){MatrixCursor c=new MatrixCursor(new String[]{"_display_name","_size"});File f=new File(getContext().getCacheDir(),u.getLastPathSegment());c.addRow(new Object[]{f.getName(),f.length()});return c;} public int delete(Uri u,String a,String[] b){return 0;}public int update(Uri u,ContentValues v,String a,String[] b){return 0;}public Uri insert(Uri u,ContentValues v){return null;}
}