# GlobalMinds Admission Officer — Android build

This is a native Android project prepared from the supplied LPU International Programme Guide 2026. It embeds all 323 programme entries for offline browsing.

## Important
The build environment used to prepare this package does not contain the Android SDK/build tools and cannot access the internet, so an APK could not be compiled inside this session. The project therefore includes a GitHub Actions cloud build. You do not need Android Studio.

## Easiest way to get the APK (phone/browser only)
1. Create/sign in to a GitHub account.
2. Create a new empty repository, e.g. `globalminds-admission-officer`.
3. Upload all files from this folder (keep `.github/workflows/build-apk.yml`).
4. Open the repository → **Actions** → **Build Android APK** → **Run workflow**.
5. When it finishes, open the workflow run and download the **GlobalMinds-APK** artifact.
6. Extract the artifact and install the APK on the Android phone.

## Included in v1
- Offline dashboard
- 323 LPU programmes embedded locally
- Search and programme detail pages
- Student records stored locally on the phone
- Automatic local reference IDs
- PDF programme guidance generation
- Android share sheet for WhatsApp/email/etc.
- Student decision section in generated PDF

The source guide itself states that the expanded subject/skills/practical/career descriptions are an informed academic expansion rather than a claim that every item is an official 2026 LPU module list. Current programme/fee/admission details should be checked before final application decisions.
